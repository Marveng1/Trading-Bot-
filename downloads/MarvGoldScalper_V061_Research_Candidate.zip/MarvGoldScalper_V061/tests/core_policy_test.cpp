// Executes the actual pure MQL header, not a Python translation of its formulas.
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
double MathMin(double a,double b) { return std::min(a,b); }
double MathMax(double a,double b) { return std::max(a,b); }
double MathFloor(double x) { return std::floor(x); }
double MathCeil(double x) { return std::ceil(x); }
double MathAbs(double x) { return std::abs(x); }
bool MathIsValidNumber(double x) { return std::isfinite(x); }
#include "../source/MGSCore.mqh"

int checks=0;
void check(bool condition,const char* message) {
    ++checks;
    if(!condition) throw std::runtime_error(message);
}
bool near(double a,double b) { return std::abs(a-b)<1e-8; }
int main() {
  try {
    check(!MGSInZone(101.2,100,101),"ask outside gap even when bid inside");
    check(MGSInZone(100.9,100,101),"executable quote inside zone");
    check(!MGSInZone(100,101,100),"inverted zone invalid");
    check(!MGSFillVolumeMatches(.01,0,0,.01),"absent position cannot prove fill reconciliation");
    check(MGSFillVolumeMatches(.02,.01,.01,.01),"partial fill evidence");
    check(!MGSFillVolumeMatches(.02,0,.01,.01),"incomplete fill snapshot remains quarantined");
    check(MGSFillVolumeMatches(.01,0,.01,.01),"complete fill evidence");
    check(near(MGSRiskBudget(500,15,1.5,485),7.5),"500 account percentage ceiling");
    check(near(MGSRiskBudget(1000,15,1.5,970),15),"1000 account cash ceiling");
    check(near(MGSRiskBudget(1000,15,1.5,997),3),"remaining floor allowance");
    check(MGSRiskBudget(1000,15,1.5,1001)==0,"halt above equity");
    check(MGSRiskBudget(std::numeric_limits<double>::quiet_NaN(),15,1.5,0)==0,"invalid equity");
    check(MGSVolumeFloor(.009,.01,100,.01,.01)==0,"never round up below minimum");
    check(near(MGSVolumeFloor(.019,.01,100,.01,.02),.01),"floor between steps");
    check(near(MGSVolumeFloor(.08,.01,100,.01,.01),.01),"lot cap");
    check(near(MGSVolumeFloor(.74,.25,10,.25,1),.5),"quarter step");
    check(MGSVolumeFloor(.01,.01,100,0,.01)==0,"invalid step");
    check(MGSVolumeFloor(.01,.01,100,.01,.005)==0,"cap below broker minimum");
    check(near(MGSSnapStop(99.999,.05,true),99.95),"buy stop rounds outward");
    check(near(MGSSnapStop(100.001,.05,false),100.05),"sell stop rounds outward");
    check(near(MGSConsiderStop(90,100,true,90,100,.5,.01),90),"illegal cash stop rejected");
    check(near(MGSConsiderStop(90,98,true,90,100,.5,.01),98),"legal ATR alternative retained");
    check(near(MGSConsiderStop(98,97,true,90,100,.5,.01),98),"buy stop cannot loosen");
    check(near(MGSConsiderStop(102,103,false,110,100,.5,.01),102),"sell stop cannot loosen");
    check(near(MGSConsiderStop(90,99.5,true,90,100,.5,.01),99.5),"legal distance equality");

    MGSTenState s; MGSResetTen(s);
    check(!MGSFeedTen(s,10500,100,100.02,.01),"initial partial not published");
    check(!MGSFeedTen(s,19000,101,101.02,.01),"same bucket");
    check(!MGSFeedTen(s,20000,102,102.02,.01),"discard initial bucket");
    check(!MGSFeedTen(s,29999,103,103.02,.01),"millisecond edge remains in bucket");
    check(MGSFeedTen(s,30000,200,200.02,.01),"publish at exact edge");
    check(s.lastDirection==1 && near(s.lastRange,1),"boundary tick excluded from archived bar");
    check(!MGSFeedTen(s,29000,1,1.02,.01) && near(s.open,200.01),"out of order ignored");
    check(!MGSFeedTen(s,39999,201,201.02,.01),"next bar evolves");
    check(MGSFeedTen(s,40000,202,202.02,.01) && s.previousDirection==1 && s.lastDirection==1,"two contiguous directions");
    check(!MGSFeedTen(s,900000,300,300.02,.01),"long gap cannot publish stale signal");
    check(s.lastDirection==0 && s.previousDirection==0,"gap resets continuity");
    check(!MGSFeedTen(s,910000,301,301.02,.01),"reconnect partial bucket discarded");
    check(!MGSFeedTen(s,919999,302,302.02,.01),"reconnect observed bucket evolves");
    check(MGSFeedTen(s,920000,303,303.02,.01) && s.previousDirection==0,"first recovery direction only");
    check(!MGSFeedTen(s,930000,303,302,.01),"crossed quote rejected");
    check(s.lastTickMsc==920000,"invalid quote does not advance state");
    std::cout<<checks<<" shared-policy assertions passed\n";
  } catch(const std::exception& e) { std::cerr<<"FAIL: "<<e.what()<<"\n"; return 1; }
}
