"""Host-compile the exact pure policy header used by the EA; not MetaEditor."""
import pathlib
import shutil
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


@unittest.skipUnless(shutil.which("g++"), "g++ needed for shared policy assertions")
class CorePolicy(unittest.TestCase):
    def test_shared_policy_assertions(self):
        with tempfile.TemporaryDirectory() as folder:
            binary = pathlib.Path(folder) / "core-policy-test"
            result = subprocess.run([
                "g++", "-std=c++17", "-Wall", "-Wextra", "-Werror", "-pedantic",
                str(ROOT / "tests/core_policy_test.cpp"), "-o", str(binary)
            ], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            executed = subprocess.run([str(binary)], capture_output=True, text=True)
            self.assertEqual(executed.returncode, 0, executed.stderr)
            self.assertIn("shared-policy assertions passed", executed.stdout)


if __name__ == "__main__":
    unittest.main()
