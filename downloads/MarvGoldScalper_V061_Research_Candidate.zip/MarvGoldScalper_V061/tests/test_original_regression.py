"""Reproduce a defect by executing the actual archived MQL function in a host stub.

This compiles only UpdateSynthetic10s, not the EA or any MQL broker API.
"""
import pathlib
import shutil
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


@unittest.skipUnless(shutil.which("g++"), "g++ needed for archived-function reproduction")
class OriginalRegression(unittest.TestCase):
    def test_original_publishes_old_direction_after_long_gap(self):
        source = (ROOT / "research/originals/V06/MarvGoldScalper_V06.mq5").read_text()
        start = source.index("void UpdateSynthetic10s()")
        end = source.index("bool FastTenSignal", start)
        body = source[start:end]
        stub = r'''
#include <algorithm>
#include <iostream>
using datetime=long;
struct MqlTick { long time; double bid; double ask; } quote;
const char* _Symbol="GOLD";
bool SymbolInfoTick(const char*,MqlTick& q) {q=quote; return true;}
double TickSize() {return .01;}
double MathMax(double a,double b) {return std::max(a,b);}
double MathMin(double a,double b) {return std::min(a,b);}
datetime gTenBucket=0;
double gTenOpen=0,gTenHigh=0,gTenLow=0,gTenClose=0,gLastTenRange=0;
int gPrevTenDir=0,gLastTenDir=0;
bool gTenBarClosed=false;
'''
        main = r'''
int main() {
 quote={10,100,100.02}; UpdateSynthetic10s();
 quote={19,101,101.02}; UpdateSynthetic10s();
 quote={20,102,102.02}; UpdateSynthetic10s();
 quote={29,103,103.02}; UpdateSynthetic10s();
 quote={900,200,200.02}; UpdateSynthetic10s();
 std::cout<<gTenBarClosed<<" "<<gPrevTenDir<<" "<<gLastTenDir;
}
'''
        with tempfile.TemporaryDirectory() as folder:
            cpp = pathlib.Path(folder) / "original.cpp"
            binary = pathlib.Path(folder) / "original"
            cpp.write_text(stub + body + main)
            compiled = subprocess.run(["g++", "-std=c++17", str(cpp), "-o", str(binary)],
                                      capture_output=True, text=True)
            self.assertEqual(compiled.returncode, 0, compiled.stderr)
            result = subprocess.run([str(binary)], capture_output=True, text=True, check=True)
            # Original publishes a two-bar bullish state after an 871-second
            # observation gap. New MGSFeedTen assertions require no publication.
            self.assertEqual(result.stdout, "1 1 1")


if __name__ == "__main__":
    unittest.main()
