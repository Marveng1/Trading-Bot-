import csv
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "tools" / "evaluate_trades.py"
SPEC = importlib.util.spec_from_file_location("evaluate_trades", MODULE_PATH)
evaluator = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(evaluator)


class EvaluationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.trades = self.root / "trades.csv"
        self.fields = sorted(evaluator.TRADE_FIELDS) + ["initial_risk"]

    def row(self, position_id="1", **overrides):
        value = dict(position_id=position_id, entry_time="2026-01-05T08:00:00Z",
                     exit_time="2026-01-05T08:01:00Z", side="BUY", volume="0.01",
                     gross_profit="10", commission="-1", swap="0", fee="-0.5", initial_risk="5")
        value.update(overrides)
        return value

    def write(self, *rows):
        with self.trades.open("w", newline="") as target:
            writer = csv.DictWriter(target, self.fields)
            writer.writeheader()
            writer.writerows(rows)

    def evaluate(self, **kwargs):
        return evaluator.evaluate(self.trades, currency="GBP", phase="in-sample", **kwargs)

    def test_signed_cost_arithmetic_and_sessions(self):
        self.write(self.row(), self.row("2", gross_profit="-4", commission="-1", fee="0",
                                       entry_time="2026-01-05T14:00:00Z", exit_time="2026-01-05T14:01:00Z"))
        result = self.evaluate()
        summary = result["summary"]
        self.assertEqual(summary["net_profit"], 3.5)
        self.assertEqual(summary["net_expectancy_per_trade"], 1.75)
        self.assertEqual(summary["win_rate"], 0.5)
        self.assertEqual(summary["average_net_win"], 8.5)
        self.assertEqual(summary["average_net_loss"], -5)
        self.assertEqual(summary["profit_factor"], 1.7)
        self.assertEqual(result["average_net_R"], 0.35)
        self.assertEqual(result["by_entry_session_UTC"]["12:00-17:00 UTC"]["trades"], 1)
        self.assertEqual(result["costs"]["commission"], -2)

    def test_equity_is_not_inferred_from_closed_trades(self):
        self.write(self.row())
        self.assertIsNone(self.evaluate()["maximum_equity_drawdown"])

    def test_observed_equity_drawdown(self):
        self.write(self.row())
        equity = self.root / "equity.csv"
        equity.write_text("timestamp,equity\n2026-01-05T07:59:00Z,1000\n"
                          "2026-01-05T08:00:01Z,1100\n2026-01-05T08:00:02Z,880\n"
                          "2026-01-05T08:02:00Z,1008.5\n")
        dd = self.evaluate(equity_path=equity)["maximum_equity_drawdown"]
        self.assertEqual(dd["maximum_cash"], 220)
        self.assertEqual(dd["maximum_fraction"], 0.2)

    def test_duplicate_position_rejected(self):
        self.write(self.row(), self.row())
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.evaluate()

    def test_unknown_commission_is_not_zero(self):
        self.write(self.row(commission=""))
        with self.assertRaisesRegex(ValueError, "unknown is not zero"):
            self.evaluate()

    def test_bad_numeric_timing_and_side_inputs(self):
        for change in [dict(fee="nan"), dict(volume="0"), dict(initial_risk="-1"),
                       dict(side="HOLD"), dict(entry_time="2026-01-05T08:00:00"),
                       dict(exit_time="2026-01-05T07:00:00Z")]:
            with self.subTest(change=change):
                self.write(self.row(**change))
                with self.assertRaises(ValueError):
                    self.evaluate()

    def test_all_winners_profit_factor_is_json_null(self):
        self.write(self.row())
        result = self.evaluate()
        self.assertIsNone(result["summary"]["profit_factor"])
        json.dumps(result, allow_nan=False)

    def test_empty_input_is_no_trades(self):
        self.write()
        result = self.evaluate()
        self.assertEqual(result["status"], "no_trades")
        self.assertEqual(result["summary"]["trades"], 0)
        self.assertIsNone(result["summary"]["net_expectancy_per_trade"])

    def test_timezone_conversion_assigns_utc_entry_date(self):
        self.write(self.row(entry_time="2026-01-06T00:00:00+02:00",
                            exit_time="2026-01-06T00:01:00+02:00", initial_risk=""))
        result = self.evaluate()
        self.assertIn("2026-01-05", result["by_entry_date_UTC"])
        self.assertEqual(result["by_entry_session_UTC"]["17:00-24:00 UTC"]["trades"], 1)
        self.assertIsNone(result["average_net_R"])

    def test_equity_must_be_ordered_and_span_trades(self):
        self.write(self.row())
        equity = self.root / "equity.csv"
        for content in ["timestamp,equity\n2026-01-05T08:00:30Z,1000\n2026-01-05T08:02:00Z,1008\n",
                        "timestamp,equity\n2026-01-05T07:00:00Z,1000\n2026-01-05T06:00:00Z,1008\n"]:
            equity.write_text(content)
            with self.assertRaises(ValueError):
                self.evaluate(equity_path=equity)

    def test_cli_produces_json_and_error_exit(self):
        self.write(self.row())
        output = self.root / "report.json"
        command = [sys.executable, str(MODULE_PATH), str(self.trades), "--currency", "GBP",
                   "--phase", "in-sample", "--output", str(output)]
        valid = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(valid.returncode, 0, valid.stderr)
        self.assertEqual(json.loads(output.read_text())["summary"]["trades"], 1)
        self.write(self.row(fee="unknown"))
        invalid = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(invalid.returncode, 2)
        self.assertIn("fee", invalid.stderr)


if __name__ == "__main__":
    unittest.main()
