# MarvGoldScalper V0.5: rapid exit and monetary profit-lock research

**Status: source-code prototype, NOT compiled or MT5-tested in this environment. Research and DEMO accounts only. No live execution is permitted in the code. No positive expectancy has been demonstrated.**

## What changed since V0.4

The existing **Advanced** entry logic, ATR initial stop, M5 trend / RSI / structure rules, 0.25% account equity risk limit, daily equity guard, and broker-spread/session filters are retained. The default entry mode is now `MGS_ADVANCED` (mode `2`). Entry signals are still evaluated **once on each new M1 bar**, not every second. The EA manages open positions on each tick.

**0.01 lots is the MAXIMUM / preferred order size, not a forced minimum order.** `InpMaxLots=0.01`. If the broker's minimum lot cannot fit the SL-risk budget, the EA *skips*. This is expected for GOLD on an initial £100 or $100 account when `InpRiskPct=0.25`.

Added `InpExitMode`:

| Numeric mode | Name | Mechanism |
|---|---|---|
| 0 | MGS_EXIT_LEGACY_R | The V0.4 break-even / R / ATR trailing control |
| 1 | MGS_EXIT_FIXED_CASH | Close as soon as estimated net floating P/L >= `InpCashTakeProfit` |
| 2 | MGS_EXIT_CASH_LOCK | Attempt money-based trailing SL above `InpCashLockTrigger` profit |
| 3 | MGS_EXIT_HYBRID | Money-based trailing SL PLUS V0.4 R/ATR trailing |

New `InpMaxHoldingSeconds`: 0 disables time exits, 30 / 60 / 120 / 180 seconds are candidate tests. Time exits close at the *current market price*, even in a loss. This is deliberately an experiment, not a profit guarantee.

`InpCashTakeProfit`, `InpCashLockTrigger`, and `InpCashLockMinNet` are **account-currency** amounts, not pips. If tester currency is USD, `1.00` means $1, not £1. The profit estimation subtracts `InpRoundTripFeePerLot` and uses `OrderCalcProfit`. It cannot guarantee a fill or exact net result after actual commissions/slippage. Protective stops can be rejected by the broker's minimum stop/freeze levels, so do not assume all profits can be locked.

**Not added:** martingale, recovery trades, grids, multiple simultaneous positions, automatic economic-news filtering, real-money trading access. Multiple positions at 0.01 could breach the £100 account risk cap. The existing hard-stop logic always applies.

## Install, compile and test (MT5 on Windows)

1. Unzip. Open MetaTrader 5, choose **File > Open Data Folder**, then `MQL5 > Experts`. Copy `MarvGoldScalper_V05.mq5` there.
2. In MT5 press **F4** for MetaEditor. Open the V0.5 file and press **F7** (Compile). Verify **0 errors**. We cannot verify compile results without your local MetaEditor. If compilation fails, share the exact Errors pane.
3. Back in MT5, open **Strategy Tester** with **Ctrl+R**. Click the Expert dropdown and pick `MarvGoldScalper_V05.ex5` (refresh the Navigator if needed). Select symbol `GOLD` and M1, and set **Every tick based on real ticks**.
4. Set `InpEnableDemoOrders=true` **for demo backtests only**. The EA refuses live/contest accounts.
5. Set Deposit to **10,000 USD** for strategy comparison with prior results (same broker and leverage). This is a *research control*, not a claim that you can achieve those trades on £100. Separately repeat the final candidate with **100 GBP** if MT5 supports it, otherwise 100 USD and note the difference. On £100 the EA may correctly open no positions.
6. In the **Inputs** tab, select `InpMode=MGS_ADVANCED` for all runs and change only exit parameters as listed in `TEST_MATRIX.csv`. Keep InpRiskPct=0.25 and InpMaxLots=0.01. Set `InpUseFixedTP=false`, `InpUseSessions=false` unless you are explicitly testing the effect of sessions.
7. Save the baseline `.set` in MT5 via right-click Inputs > Save. Run tests; export both Overview and Deals/history results for each variant; retain the journal.

## 1 month vs 2 months

A week is not enough to establish an edge. Recommended **initial investigation: two months**, from **2026-08-21 to 2026-10-20** (enter tester start `2026.08.21` and end `2026.10.21`; the end date is exclusive). For an initial one-month comparison, `2026.09.21` to `2026.10.21`.

Important: Your October 21 log states real ticks *currently synchronised* from October 12 onward. Trying August/September may trigger downloading older tick history from FxPro. **Do not treat older candles or generated ticks as equivalent real ticks.** Confirm the `Journal` messages about actual tick history, and note any data gaps.

To reduce overfitting, use **Aug 21 - Sep 30** as the research period and **Oct 1 - Oct 20** as a separate, untouched validation period. Choose exit parameters using the earlier period only, then lock them and check the later period. If full real ticks aren't available, choose a different broker's historical ticks for research or clearly label modelled ticks. A second distinct market period, ideally 6-12 months once data permits, and several weeks of forward demo trading are necessary before interpreting short-term results.

Use the same broker symbol, deposit, leverage, spread conditions and fees for every A/B test. Choose a realistically nonzero execution delay in addition to the ideal execution control. For 30-second scalping, differences in spread/slippage can reverse the result.

## Interpretation

* A profitable 10k USD backtest with a 0.01 lot cap **does not establish £100 live feasibility**. At £100 the minimum GOLD stop risk may be 5-40 times the 0.25% ($0.25) allowance, or more, depending on the particular trade, broker, and currency.
* Do not conclude that an exit setting is superior because it has more winning trades. Compare profit factor, net expectancy *after costs*, return on capital, max drawdown, number of actual filled trades, and the risk at minimum broker lot.
* Money-lock uses best **observed** estimated net P/L while the position is open (not future information). It updates the stop only when the broker allows it and never widens the initial SL. Its `InpSlipReserveTicks` is an estimate; gaps can exceed it.
* The V0.5 test changes trade timing, so it will **not** automatically re-run the exact same 127 V0.4 entries. A true identical-entry counterfactual requires a separate historical fill/tick replay using each original entry timestamp and bid/ask path.

## Known limitations to review before any future live EA

1. No economic-news calendar integration, no news blackouts by default beyond any **manually configured** window.
2. Trailing stops require successful broker modifications, may not secure tiny profit targets, and account-currency P/L is approximate until close.
3. Day-start equity tracking on mid-day start is incomplete, deposits/withdrawals and unrelated trading interfere with results. Day-level risk is not a guaranteed execution limit.
4. No external VPS disconnection/execution monitoring, no unit-tested broker-specific margin/stop behaviour, no production reconciliation on rejected / partial order fills.
5. **No compile or actual strategy test has been performed here**, so treat this as an unvalidated draft to compile and verify locally.

The goal for this experiment is not 80% win rate or a fixed daily-income target. It is a positive, repeatable **net** expectancy under realistic execution and out-of-sample testing.
