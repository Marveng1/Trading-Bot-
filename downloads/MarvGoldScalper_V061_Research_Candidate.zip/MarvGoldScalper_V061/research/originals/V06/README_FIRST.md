# MarvGoldScalper V06: DEMO research build

**Status:** Source code delivered; not compiled in MetaEditor and not backtested in this environment. It is NOT approved for live money. A proper code review, broker-specific validation, extended out-of-sample testing and forward demo results are required.

## What V06 contains

This is an extension of the exact V05 prototype from `MarvGoldScalper_V05_Rapid_Exit_Research.zip`, not an unrelated rewrite. V05's four modes and its protective account-currency sizing, once-per-M1 entries, tick-by-tick exit engine, day-level equity/profit lock, slippage/fee estimates, and demo-only hard gate remain available.

**Three new experimental modes:**

- `InpMode=4` `MGS_EMA_PSAR_10S` (default). Builds 10-second mid-price candles from real broker ticks. Once a 10-second candle closes, checks 5/20/40 EMA alignment on CLOSED M1 and M5 candles, CLOSED M1/M5 Parabolic SAR direction, and the last one or two 10-second candle directions. **Not** a full PSAR indicator calculated on 10-second candles. One signal decision per 10-second close; management of open trades continues on every incoming tick. In sparse-tick periods a ten-second candle can span more than ten seconds.
- `InpMode=5` `MGS_FIB_EMA`. Looks for chronological high/low swings on completed M5 candles and retracements to the 38.2%-61.8% zone. Uses EMA bias, optional completed M15 confirmation, completed M1 reversal candle and RSI. Once-per-M1 entries.
- `InpMode=6` `MGS_FVG_OB`. Detects a three-closed-M5-candle FVG with displacement, M5 and H1 EMA bias, and a completed M1 reversal. Enters only when the CURRENT price revisits the gap. Optional rudimentary candle-based "order block overlap" filter is disabled by default. These are chart-pattern proxies, **not** independently verified institutional order flow. Once-per-M1 entries.

V05 modes 0 (EMA), 1 (EMA+RSI+M5), 2 (advanced momentum/structure), and 3 (opening-range breakout) are still selectable for clean control comparisons.

## Your requested risk: GBP 15 maximum

**Only if the Strategy Tester account is denominated in GBP:**

- `InpRiskCash=15.0` means MAX GBP 15 estimated initial risk. If account is USD, it means MAX USD 15 instead.
- `InpRiskPct=1.50` is an independent equity percentage ceiling. Actual budget is **MIN(cash cap, equity×1.5%, remaining room above active daily equity floor)**.
- GBP 500 account: up to GBP 7.50 planned risk per trade. GBP 1,000: up to GBP 15. This is a **cap, not a required loss or fixed stake**.
- `InpMaxLots=0.01` is an upper bound, not an imposed trade size. If the broker's minimum lot or margin is too costly the EA SKIPS; it NEVER increases lots to reach GBP 15.
- `InpDayLossPct=3.0` is an account-level circuit breaker, not a guarantee against gaps, slippage or disconnection. A day with large volatility may lose MORE than the threshold.
- `InpMaxMarginPctFree=35.0`, maximum planned margin as a portion of FREE margin.
- V05's daily peak profit protection is retained. Both it and day-loss protection close V06's OWN positions if triggered and block new trades for the broker day. Account-level P/L can be distorted by external trading and deposits/withdrawals.
- Round-trip fee (`InpRoundTripFeePerLot=7`) and slippage reserve (`InpSlipReserveTicks=10`) are research estimates; adjust them after reviewing real FxPro GOLD specifications and fills.

## Entry / exit safety

- 1 open GOLD position across ALL strategies/EAs, no grid, martingale, recovery positions or hedged basket. Multi-position recovery would multiply total loss and is intentionally omitted.
- DEMO account only even if `InpEnableDemoOrders=true`. V06 will refuse to place trades on a live or contest account.
- InpUseSessions=true by default with broker-server sessions 07:00-11:00 and 13:00-17:00. These are **NOT automatically UK/London times**. To compare around-the-clock scanning use `InpUseSessions=false`; the code still avoids broker rollover and abnormal spread.
- No automatic economic-news feed. Use manual blackout inputs around CPI, NFP and Fed announcements. A spike filter checks the *last completed* M1 candle, but cannot anticipate a news spike.
- For fast exit comparisons, test `InpMaxHoldingSeconds=0` (no forced time exit), `60`, `120` and `180`. The maximum holding time is an experimental MARKET CLOSE, including at a loss.
- `InpExitMode=3` preserves V05's money-based stop protection plus R/ATR break-even/trailing. Broker minimum-stop/freeze rules can reject trailing modifications and tiny cash locks. No guaranteed GBP 0.50/1/2 profits.
- Trading eligibility is conditional on session, cash risk, risk percentage, margin, spread, spike filter, blackout, loss floor, open positions and cooldown.

## Beginner steps: install in YOUR FxPro MT5 on Windows

1. Extract the ZIP. In FxPro MT5 use **File > Open Data Folder** and open `MQL5 > Experts`.
2. Copy `MarvGoldScalper_V06.mq5` to that Experts folder. Do not overwrite V05.
3. Press **F4** to open MetaEditor. In Navigator open `MarvGoldScalper_V06.mq5` and press **F7**. We cannot confirm compilation here. If you see errors, capture the **entire MetaEditor Errors pane** and share it before running the EA.
4. Return to MT5, open **Strategy Tester** via **Ctrl+R**. Choose Expert `MarvGoldScalper_V06`, Symbol **GOLD** (exact FxPro name), Period **M1**, Modelling **Every tick based on real ticks**, Optimization **Disabled**.
5. Select an actual tick-history date range. First do a 2-week **smoke test** to verify mechanics, then run >=6 months for strategy research and a separate untouched period. A short test does not establish performance.
6. Set Deposit **1,000** and currency **GBP** if the tester allows. Match leverage to the account you could realistically open. Repeat with **500 GBP** after baseline checks. If it only allows USD, label results as USD and do not interpret `InpRiskCash=15` as GBP 15.
7. In **Inputs**, set `InpEnableDemoOrders=true`, `InpMode=MGS_EMA_PSAR_10S`, `InpExpectedSymbol=GOLD`, `InpRiskCash=15.00`, `InpRiskPct=1.50`, `InpMaxLots=0.01`, `InpDayLossPct=3.00`. All are code defaults except the DEMO order switch, which intentionally defaults to false.
8. Click **Start**. Check the **Backtest Overview, Graph, History, and Journal** tabs. Find `MGS V06 RESEARCH` in the Journal to confirm you selected V06 rather than V05.
9. If **zero trades**, read the Journal: minimum broker lot may exceed allowed cash risk, the margin cap may exclude trades, historical H1 EMA buffers may not yet exist, or the mode's entries may be too restrictive. Do NOT simply turn off risk guards to make trades appear.
10. Test a second run with `InpMode=MGS_FIB_EMA`, third with `InpMode=MGS_FVG_OB`, and fourth with `InpMode=MGS_ADVANCED` (V05 control). Keep all other parameters identical. Export trades and reports from each run.

### Backtest quality

* Avoid judging an algorithm solely on win rate or total profit. Compare net expectancy after commissions and spreads, trade count, profit factor, maximum EQUITY drawdown, loss tails and performance by session.
* **Change just one parameter/family at a time**, not all seven parameters until you find a pretty result.
* At least 6-12 months of real-tick research with differing market conditions, a separate forward holdout, and several weeks of forward DEMO testing should precede any question of going live.
* MT5's `100% History Quality` is a history/report metric, **not** proof the fills exactly match real broker executions or that an EA is profitable.

## Remaining limitations

1. No MT5 compiler or real tick tester is available here. **Zero compile errors and profitability are not claimed.**
2. Broker sessions are set in BROKER SERVER time; historical daylight-saving transitions may need explicit adjustment.
3. Only the 10s candle CLOSE uses 10-second synthetic data; M1 and M5 PSAR/EMA are calculated on native timeframes.
4. The FVG/OB design is a transparent hypothesis, not proof of predictive market structure. No ML is present.
5. Manual news blackout only, no auto release-calendar integration.
6. Equity-floor accounting remains imperfect if the EA starts mid-session, other account transactions occur, or the broker fills beyond stops.
7. V05's stop/trailing logic is inherited. Commission/slippage are estimates and some protective modifications can be rejected.
8. Do not optimize on the later holdout period. Never assume GBP 15 is the maximum *realized* possible loss in a gap.
9. A GBP 500 or GBP 1,000 account needs actual retail gold margin/contract verification with the **exact FxPro legal entity** and GOLD symbol. The EA uses broker margin calculations rather than a hard-coded leverage assumption.

## References read during development

- Previously built **MarvGoldScalper V05**, source provided in this conversation.
- Open-source [TRILLEX 10S](https://github.com/NadirAliOfficial/trillex-10s-ea), inspiration for hypothesis of 10-second synthetic signals and EMA/PSAR alignment; no performance proof.
- Open-source [FvgGold EA](https://github.com/foeed/FvgGold-EA), reference for FVG detection and filtered entries; published performance unverified and numerically inconsistent with standard contract assumptions.
- Open-source [Gold EA with OpenAI](https://github.com/RobertN1D/GOLD-EA-MT5-WITH-OPENAI), reference for indicator/trailing architecture; AI integration was not included because it introduces unverified latency and errors.
- MetaQuotes `OrderCalcProfit()` and `OrderCalcMargin()` documentation for account currency risk and margin estimates.
