# Marv Gold Scalper V0.4: £100 account research build

**Status: DEMO-ONLY MQL5 source-code prototype, not compiled or backtested by ChatGPT.**
The earlier V0.3 MetaEditor and MT5 results do **not** validate this new V0.4 code. Use MetaEditor to compile, then the MT5 Strategy Tester to verify functionality, safeguards, costs and profitability. No strategy here has demonstrated consistent long-run profitability.

## Read this first: the £100 constraint

FxPro's GOLD contract in your screenshots: **100 oz per 1.00 lot** and minimum **0.01 lot**, equal to **1 oz** of gold exposure. At 0.01 lot, a $3 change in GOLD ordinarily changes gross P&L by roughly **$3**. Your intended **0.25% risk on £100 is only £0.25 per trade**. A useful stop for M1 gold may require far more room than that. Spread, slippage and commissions add cost. Consequently this EA may correctly take **zero trades** on a £100 demo account. That is a safety feature, not a software bug.

`InpMaxLots=0.01` is a **maximum position-size cap**, not a fixed/default order. The EA uses `OrderCalcProfit` in the account currency to estimate loss at the protective SL, including fee and slippage reserves. If the broker minimum lot would exceed either the per-trade budget or the remaining daily/profit-lock budget, **the order is skipped**. Raising lot size, removing the SL, or raising daily loss to 10% is NOT an appropriate way to override this.

**Alternatives for real-world research:** continue demo testing, or investigate whether a broker offers a *genuinely smaller contract/tick value* for the intended instrument. Verify specifications and account eligibility before assuming it is suitable. An actual £100 live deposit is **not recommended on the evidence so far**.

## What's in V0.4

- Demo account only. `InpEnableDemoOrders=false` by default; true is permitted only on MT5 accounts whose trade mode is DEMO.
- Four **independent** experimental entry strategies selected via `InpMode`:
  - `MGS_EMA_BASELINE` (default): original V0.3 EMA9/21 M1 completed-candle pullback breakout.
  - `MGS_EMA_RSI_M5`: the previous EMA + RSI14 and M5 EMA20/50 filter.
  - `MGS_ADVANCED`: previous extra M5 ADX / candle body / prior-range proxy.
  - `MGS_RANGE_BREAKOUT`: NEW, earlier GBPUSD intraday spreadsheet's range principle reinterpreted as a **testable GOLD experiment**. Build high/low only from completed M15 bars of a specified BROKER-time period (default 07:00-09:00), then accept a closed M1 breakout and at most one breakout entry that day. **Not a claim that the original spreadsheet works on gold.**
- Position sizing by estimated stop risk and account currency; cap of 0.01 lot and **0.25% planned equity risk** per trade.
- No fixed take profit by default (`InpUseFixedTP=false`); the initial protective SL is always supplied to the broker. Trailing SL is tightened on price ticks after 1.5R; an estimated-fee breakeven stop can be considered at 1R. SL never loosens. This can cause large profits to be given back before exit.
- **Daily trailing profit lock:** once today's net account-equity profit reaches **0.5% of day-start equity**, remember the day's highest equity profit. If current daily equity profit falls to **70% of that peak**, halt new trades and attempt to close the EA-owned position. For example, a £100 account reaches £1 daily equity profit; the £0.70 profit threshold then applies. This is a **protection trigger, not guaranteed realised profit**.
- **Daily 1.5% equity-loss floor**, checked both before each order and on each new tick, including prospective SL risk and any active profit-lock floor. EA-owned positions are closed if the floor is triggered, but market gaps and execution failures may exceed the thresholds.
- Entry evaluation once per completed M1 candle, SL management every price tick. Across eligible weekday broker hours by default, excluding 20 minutes around broker midnight and the broker's market closures. This is **not** millisecond high-frequency scalping.
- Absolute safety ceiling of 200 entries per day, one position at a time, minimum 120s between entries. A breakout mode caps at one entry daily. The EA doesn't target a specific trade count.
- Manual blackout via `InpManualBlackoutStart/End`. **NO automatic news feed or high-impact calendar filtering in V0.4**, so do not run unattended across economic releases.
- On tester initialization, day-state globals are cleared for a clean run. During continuous demo operation, broker-day start, profit peak and halt status persist through terminal restarts using MT5 Global Variables.

## What this build cannot promise

- No guaranteed 80% win rate, daily income, 70% daily returns, or trailing stops filled at an exact price.
- No reliable automatic detection of news, geopolitical events, smart money, liquidity sweeps, AI learning or predictive market classification.
- No independent code compilation or real historical backtesting performed here. If MetaEditor shows any compile error, stop and share the **error text and line number**.
- Daily performance includes the **whole account equity**, so deposits, withdrawals and trades managed outside this EA can contaminate the profit lock. Keep a dedicated demo account. `InpRequireExclusiveAccount=true` prevents the EA from opening new positions while others are open, but does not reconstruct earlier foreign-account P&L.
- `InpRoundTripFeePerLot=7.0` is an estimate denominated in **account currency**. Confirm the broker's true charges in the account currency and official MT5 Backtest report. It does **not** manually debit commissions from balance: MT5's simulated deal P&L/commission must be checked.

## Install, compile and run a £100 backtest (novice steps)

1. **Keep V0.3.** This is a separate file: `MarvGoldScalper_V04.mq5`.
2. In MT5 desktop: **File > Open Data Folder > MQL5 > Experts**. Paste this `.mq5` source file.
3. Open **MetaEditor** with F4, find `MarvGoldScalper_V04.mq5` under Experts and press **F7**. Note errors or warnings. Until you see 0 errors, do not continue.
4. In MT5, press **Ctrl+R**. Select Expert `MarvGoldScalper_V04`, Symbol **GOLD**, Timeframe **M1**.
5. For a smoke test use the old **12 Oct to 16 Oct 2026** custom range with **Every tick based on real ticks**, **Forward=No**, **Optimization=Disabled**. *This is already-used development data, not proof of performance.*
6. Set the tester deposit to **100 GBP** if the currency dropdown supports it. If only USD is available, you can test 100 USD but must not describe the result as a £100 test.
7. On **Inputs**, select `InpMode=MGS_EMA_BASELINE`, `InpEnableDemoOrders=true`, `InpMaxLots=0.01`, `InpRiskPct=0.25`, `InpDayLossPct=1.5`, `InpProfitKeepPct=70.0`, `InpUseFixedTP=false`. Leave the rest as delivered.
8. Click **Start**. Check **Journal** for `NO TRADE: min lot ... risk ... > allowed ...`. **Zero trades are expected to be possible at this balance.** Do not raise risk to manufacture trades.
9. After the £100 smoke test, repeat on hypothetical **1,000** and **10,000** deposit settings with the *same account currency* and unchanged parameters to learn the minimum capital needed for the given stop distances. These are simulated sizes, **not deposit recommendations**.
10. Save the **Backtest** statistics, **Graph** and **Journal**. Compare fixed TP (`InpUseFixedTP=true`) against trailing-only (`false`) with all else identical. Save inputs and label runs.

## Safety and validation to complete before unattended demo usage

- [ ] Compile in MetaEditor without errors. This file has only had offline/static inspection.
- [ ] Confirm real-tick history quality and download more than the 4-day period. Some earlier FxPro runs had real tick history from only 12 Oct 2026.
- [ ] Confirm 0.01-lot exposure in **the exact FxPro or Moneta account contract**; do not assume GOLD/XAUUSD or commission specifications match.
- [ ] Check a trade never opens if its planned SL loss plus fee/slippage estimate exceeds 0.25% equity. On a £100 account, skip is preferable to violating limits.
- [ ] Force profit-lock activation and giveback in Strategy Tester. Verify no new entries after halt, and audit stop/close order retcodes.
- [ ] Force day-loss threshold and the no-trade preflight, confirm no order opens then immediately triggers protection like the V0.3 journal did.
- [ ] Test resets at broker midnight, terminal restart, missing SL, spread widening, weekend rollovers and broker rejected closes/SL modifications.
- [ ] Test on different historical periods, several months where quality data exists, and a later genuinely untouched period. Assess profit factor, P&L, slippage, win/loss distribution, and worst equity drawdown.
- [ ] Implement a **validated automatic news filter** before considering unattended demo deployment. Manual blackout is not a substitute for this.
- [ ] Keep any funded trading decision separate from demo development; use only money you can afford to lose.

## Suggested immediate ChatGPT follow-up

Compile V0.4 in MetaEditor, send a screenshot of the **Errors** panel. If it compiles, run the £100 demo backtest and send the resulting **Backtest + Journal**. We will diagnose *skipped* trades before touching risk settings or performance optimisations.
