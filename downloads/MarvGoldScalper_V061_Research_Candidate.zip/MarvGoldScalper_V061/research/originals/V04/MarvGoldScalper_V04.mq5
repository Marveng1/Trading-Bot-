//+------------------------------------------------------------------+
//| MarvGoldScalper_V04.mq5                                           |
//| RESEARCH PROTOTYPE ONLY. DEMO ACCOUNTS ONLY. NOT VALIDATED.       |
//| EMA baseline / RSI-M5 / advanced / intraday range breakout       |
//| 0.01 max-lot cap, risk-based sizing, profit lock, trailing stop.  |
//| BEWARE: GBP 100 may be TOO SMALL to trade GOLD at 0.25% risk.     |
//+------------------------------------------------------------------+
#property copyright "Independent demo research"
#property version   "1.040"
#property strict
#include <Trade/Trade.mqh>

enum ENUM_MGS_MODE
{
   MGS_EMA_BASELINE = 0,
   MGS_EMA_RSI_M5 = 1,
   MGS_ADVANCED = 2,
   MGS_RANGE_BREAKOUT = 3
};

// GENERAL: OFF means print candidates only. Real-money accounts are BLOCKED.
input ENUM_MGS_MODE InpMode = MGS_EMA_BASELINE;
input bool   InpEnableDemoOrders = false;
input string InpExpectedSymbol = "GOLD";  // FxPro demo symbol, not necessarily XAUUSD
input ulong  InpMagic = 20261021;
input int    InpDeviationPoints = 30;
input bool   InpLogDecisions = true;

// ACCOUNT PROTECTION: limits are not guarantees under gaps/slippage.
input double InpRiskPct = 0.25;              // planned ACCOUNT EQUITY risk per trade (%)
input double InpMaxLots = 0.01;              // cap, NOT a mandatory order size
input double InpDayLossPct = 1.50;           // hard floor relative to broker-day starting EQUITY
input double InpProfitLockActivatePct = 0.50;// profit lock activates above 0.5% of day-start equity
input double InpProfitKeepPct = 70.0;        // protect 70% of maximum accumulated daily profit
input double InpRoundTripFeePerLot = 7.0;    // fee ESTIMATE in ACCOUNT currency per 1.00 lot
input double InpSlipReserveTicks = 10.0;     // planned adverse SL slippage reserve in ticks
input double InpMaxMarginPctFree = 40.0;
input bool   InpRequireExclusiveAccount = true; // no other open positions while initiating trades
input int    InpMaxTradesPerDay = 200;       // emergency ceiling, not a trade target
input int    InpMinSecondsBetweenEntries = 120;

// ELIGIBLE HOURS: if InpUseSessions=false, trading is still constrained by broker hours,
// weekends, manual news blackouts, spread, and a midnight rollover exclusion.
input bool   InpUseSessions = false;
input int    InpSession1Start = 7;
input int    InpSession1End = 11;
input int    InpSession2Start = 13;
input int    InpSession2End = 17;
input int    InpAvoidRolloverMinutes = 20;    // skip entry 23:40-00:20 server time
input datetime InpManualBlackoutStart = 0;
input datetime InpManualBlackoutEnd = 0;

// TRADE EXECUTION AND TRAILING (NO fixed TP by default)
input double InpMaxSpreadATR = 0.20;
input double InpStopATR = 1.50;
input bool   InpUseFixedTP = false;
input double InpTargetR = 1.80;              // used only when InpUseFixedTP=true
input double InpBreakEvenR = 1.00;
input double InpTrailStartR = 1.50;
input double InpTrailATR = 1.20;
input double InpMinModifyTicks = 20.0;
input int    InpMinModifySeconds = 15;
input double InpBEExtraTicks = 10.0;

// EMA, RSI, M5 and advanced confirmation filters
input double InpRSIBuyAbove = 52.0;
input double InpRSISellBelow = 48.0;
input double InpRSIUpperLimit = 75.0;
input double InpRSILowerLimit = 25.0;
input double InpADXMinimum = 18.0;
input double InpMinCandleBodyFraction = 0.50;
input double InpMinImpulseRangeATR = 0.45;
input int    InpStructureLookback = 12;
input double InpMinRoomToLevelATR = 0.75;
input int    InpRequiredAdvancedExtras = 2;
input bool   InpCheckSRRoom = true;

// INDEPENDENT OPENING RANGE BREAKOUT EXPERIMENT: ALL HOURS BELOW ARE BROKER SERVER TIME.
// Based only on completed M15 bars in a finished range, then M1 close confirms breakout.
input int    InpBORangeStartHour = 7;
input int    InpBORangeEndHour = 9;
input int    InpBOLastEntryHour = 15;
input double InpBOBreakoutBufferATR = 0.10;

CTrade trade;
int hEma9=INVALID_HANDLE, hEma21=INVALID_HANDLE, hEma20M5=INVALID_HANDLE;
int hEma50M5=INVALID_HANDLE, hRsi=INVALID_HANDLE, hAtr=INVALID_HANDLE;
int hAdxM5=INVALID_HANDLE;
datetime lastBar=0;
string gStartKey="", gPeakKey="", gHaltKey="";
string gDay="";

// UTILITIES ---------------------------------------------------------
double TickSize()
{
   double t=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   return (t>0.0?t:_Point);
}

double SnapPrice(double price)
{
   return NormalizeDouble(MathRound(price/TickSize())*TickSize(),_Digits);
}

bool ReadIndicator(int h,int shift,double &out,int buffer=0)
{
   double temp[];
   if(CopyBuffer(h,buffer,shift,1,temp)!=1) return false;
   out=temp[0];
   return MathIsValidNumber(out) && out!=EMPTY_VALUE;
}

bool DemoEnvironment()
{
   return AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_DEMO;
}

string Prefix()
{
   return "MGS04_"+(string)AccountInfoInteger(ACCOUNT_LOGIN)+"_"+
          (string)InpMagic+"_"+_Symbol+"_";
}

string PositionRiskKey()
{
   return Prefix()+"risk_"+(string)PositionGetInteger(POSITION_IDENTIFIER);
}

string PositionModifyKey()
{
   return Prefix()+"mod_"+(string)PositionGetInteger(POSITION_IDENTIFIER);
}

// Persistent terminal global variables preserve the day's thresholds on restart.
// Research caveat: deposits/withdrawals and foreign-account trades distort equity tracking.
void RefreshDay()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(),dt);
   string day=StringFormat("%04d%02d%02d",dt.year,dt.mon,dt.day);
   if(day==gDay) return;
   gDay=day;
   string stem=Prefix()+day;
   gStartKey=stem+"_start";
   gPeakKey=stem+"_peak";
   gHaltKey=stem+"_halt";
   if(!GlobalVariableCheck(gStartKey))
   {
      GlobalVariableSet(gStartKey,AccountInfoDouble(ACCOUNT_EQUITY));
      Print("DAY START EQUITY CAPTURED: ",DoubleToString(GlobalVariableGet(gStartKey),2),
            " ",AccountInfoString(ACCOUNT_CURRENCY),
            ". If EA starts mid-session, earlier P/L is not reconstructed.");
   }
   if(!GlobalVariableCheck(gPeakKey)) GlobalVariableSet(gPeakKey,0.0);
   if(!GlobalVariableCheck(gHaltKey)) GlobalVariableSet(gHaltKey,0.0);
}

double DayStartEquity()
{
   RefreshDay();
   return GlobalVariableGet(gStartKey);
}

// Prospective risk must preserve BOTH the day-loss floor and any active
// profit-lock floor. A new trade must not knowingly spend locked-in profit.
double AccountRiskFloor()
{
   RefreshDay();
   double start=GlobalVariableGet(gStartKey);
   double floor=start*(1.0-InpDayLossPct/100.0);
   double peak=MathMax(0.0,GlobalVariableGet(gPeakKey));
   if(peak>=start*InpProfitLockActivatePct/100.0)
      floor=MathMax(floor,start+peak*InpProfitKeepPct/100.0);
   return floor;
}

bool DailyHalt()
{
   RefreshDay();
   double start=GlobalVariableGet(gStartKey);
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(start<=0.0 || equity<=0.0) return true;
   double today=equity-start;
   double peak=MathMax(0.0,GlobalVariableGet(gPeakKey));
   if(today>peak)
   {
      peak=today;
      GlobalVariableSet(gPeakKey,peak);
   }
   bool hardLoss=(equity<=start*(1.0-InpDayLossPct/100.0));
   bool lockActive=(peak>=start*InpProfitLockActivatePct/100.0);
   bool gaveBack=(lockActive && today<=peak*(InpProfitKeepPct/100.0));
   if((hardLoss || gaveBack) && GlobalVariableGet(gHaltKey)<0.5)
   {
      GlobalVariableSet(gHaltKey,1.0);
      PrintFormat("DAILY HALT %s | start=%.2f peakPnL=%.2f nowPnL=%.2f | trading blocked until next BROKER day",
                  hardLoss?"LOSS LIMIT":"PROFIT LOCK",start,peak,today);
   }
   return GlobalVariableGet(gHaltKey)>=0.5;
}

bool OurPosition(const ulong ticket)
{
   if(!PositionSelectByTicket(ticket)) return false;
   return PositionGetString(POSITION_SYMBOL)==_Symbol &&
          (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic;
}

bool HasAnySymbolPosition()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket>0 && PositionSelectByTicket(ticket) &&
         PositionGetString(POSITION_SYMBOL)==_Symbol) return true;
   }
   return false;
}

bool CanUseAccount()
{
   if(!InpRequireExclusiveAccount) return true;
   // Other positions would make account-level daily equity un-attributable.
   return PositionsTotal()==0;
}

bool InWindow(int hour,int begin,int end)
{
   if(begin==end) return false;
   if(begin<end) return hour>=begin && hour<end;
   return hour>=begin || hour<end;
}

bool SessionOK()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(),dt);
   if(dt.day_of_week==0 || dt.day_of_week==6) return false;
   int mins=dt.hour*60+dt.min;
   if(InpAvoidRolloverMinutes>0 &&
      (mins<InpAvoidRolloverMinutes || mins>=1440-InpAvoidRolloverMinutes)) return false;
   if(InpManualBlackoutStart>0 && InpManualBlackoutEnd>InpManualBlackoutStart &&
      TimeCurrent()>=InpManualBlackoutStart && TimeCurrent()<InpManualBlackoutEnd) return false;
   if(!InpUseSessions) return true;
   return InWindow(dt.hour,InpSession1Start,InpSession1End) ||
          InWindow(dt.hour,InpSession2Start,InpSession2End);
}

int TradesToday()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(),dt);
   dt.hour=0; dt.min=0; dt.sec=0;
   if(!HistorySelect(StructToTime(dt),TimeCurrent())) return InpMaxTradesPerDay;
   int count=0;
   for(int i=HistoryDealsTotal()-1;i>=0;i--)
   {
      ulong d=HistoryDealGetTicket(i);
      if(d==0 || HistoryDealGetString(d,DEAL_SYMBOL)!=_Symbol) continue;
      if((ulong)HistoryDealGetInteger(d,DEAL_MAGIC)!=InpMagic) continue;
      if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(d,DEAL_ENTRY)==DEAL_ENTRY_IN) count++;
   }
   return count;
}

bool CooldownOK()
{
   datetime now=TimeCurrent();
   if(!HistorySelect(now-86400,now)) return false;
   for(int i=HistoryDealsTotal()-1;i>=0;i--)
   {
      ulong d=HistoryDealGetTicket(i);
      if(d==0 || HistoryDealGetString(d,DEAL_SYMBOL)!=_Symbol) continue;
      if((ulong)HistoryDealGetInteger(d,DEAL_MAGIC)!=InpMagic) continue;
      if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(d,DEAL_ENTRY)!=DEAL_ENTRY_IN) continue;
      return (now-(datetime)HistoryDealGetInteger(d,DEAL_TIME))>=InpMinSecondsBetweenEntries;
   }
   return true;
}

// ACCOUNT-CURRENCY RISK using OrderCalcProfit plus slippage/commission allowance.
// Slippage reserve and estimated fees are not guarantees of the eventual loss.
bool ProjectedLoss(ENUM_ORDER_TYPE side,double lots,double entry,double stop,double &risk)
{
   bool buy=(side==ORDER_TYPE_BUY);
   double worstStop=stop+(buy?-1.0:1.0)*InpSlipReserveTicks*TickSize();
   double gross=0.0;
   if(!OrderCalcProfit(side,_Symbol,lots,entry,worstStop,gross)) return false;
   risk=MathMax(0.0,-gross)+lots*InpRoundTripFeePerLot;
   return (risk>0.0 && MathIsValidNumber(risk));
}

double BreakevenPrice(bool buy,double entry,double lots)
{
   ENUM_ORDER_TYPE side=(buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL);
   double tick=TickSize();
   double tickPL=0;
   if(!OrderCalcProfit(side,_Symbol,lots,entry,entry+(buy?tick:-tick),tickPL) || tickPL<=0.0)
      return entry+(buy?1.0:-1.0)*InpBEExtraTicks*tick;
   double feesTicks=lots*InpRoundTripFeePerLot/tickPL;
   return entry+(buy?1.0:-1.0)*(feesTicks+InpBEExtraTicks)*tick;
}

// TRADE MANAGEMENT ---------------------------------------------------
void ManagePositions(bool closeForHalt)
{
   if(!InpEnableDemoOrders || !DemoEnvironment()) return;
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q)) return;
   double atr=0.0;
   if(!closeForHalt && (!ReadIndicator(hAtr,1,atr)||atr<=0.0)) return;
   double minDistance=(MathMax((double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL),
                               (double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL))+2.0)*_Point;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(!OurPosition(ticket)) continue;
      if(closeForHalt)
      {
         if(!trade.PositionClose(ticket) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
            Print("HALT CLOSE FAILED. Investigate IMMEDIATELY: ",trade.ResultRetcodeDescription());
         continue;
      }
      double oldSL=PositionGetDouble(POSITION_SL);
      if(oldSL<=0.0)
      {
         Print("EMERGENCY: owned position without broker SL. Attempting to close ticket ",ticket);
         if(!trade.PositionClose(ticket) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
            Print("EMERGENCY CLOSE FAILED: ",trade.ResultRetcodeDescription());
         continue;
      }
      string riskKey=PositionRiskKey();
      if(!GlobalVariableCheck(riskKey))
      {
         // Never infer original risk from a stop that has already moved.
         if(InpLogDecisions) Print("Missing original initial-risk key for ticket ",ticket,
                                   ". Original protective SL retained; trailing suspended.");
         continue;
      }
      double initialRisk=GlobalVariableGet(riskKey);
      if(initialRisk<=0) continue;
      double entry=PositionGetDouble(POSITION_PRICE_OPEN);
      double tp=PositionGetDouble(POSITION_TP);
      bool buy=((ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY);
      double current=(buy?q.bid:q.ask);
      double favourable=(buy?current-entry:entry-current);
      double candidate=oldSL;
      if(favourable>=InpBreakEvenR*initialRisk)
      {
         double be=BreakevenPrice(buy,entry,PositionGetDouble(POSITION_VOLUME));
         candidate=(buy?MathMax(candidate,be):MathMin(candidate,be));
      }
      if(favourable>=InpTrailStartR*initialRisk)
      {
         double trail=(buy?q.bid-InpTrailATR*atr:q.ask+InpTrailATR*atr);
         candidate=(buy?MathMax(candidate,trail):MathMin(candidate,trail));
      }
      candidate=SnapPrice(candidate);
      double step=InpMinModifyTicks*TickSize();
      bool improved=(buy?candidate>oldSL+step:candidate<oldSL-step);
      bool legal=(buy?candidate<q.bid-minDistance:candidate>q.ask+minDistance);
      string key=PositionModifyKey();
      bool afterCooldown=(!GlobalVariableCheck(key) ||
                          TimeCurrent()-(datetime)GlobalVariableGet(key)>=InpMinModifySeconds);
      if(improved && legal && afterCooldown)
      {
         if(!trade.PositionModify(ticket,candidate,tp) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
            Print("SL update rejected for ticket ",ticket,": ",trade.ResultRetcodeDescription());
         else GlobalVariableSet(key,(double)TimeCurrent());
      }
   }
}

// SIGNALS -----------------------------------------------------------
// Intentionally retains V0.3's completed-M1-bar EMA baseline for A/B tests.
// No claims that these indicators predict winning trades.
bool RangeBreakoutSignal(int &direction,double atr)
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(),dt);
   if(dt.hour<InpBORangeEndHour || dt.hour>=InpBOLastEntryHour) return true;
   dt.hour=0; dt.min=0; dt.sec=0;
   datetime midnight=StructToTime(dt);
   datetime from=midnight+InpBORangeStartHour*3600;
   datetime to=midnight+InpBORangeEndHour*3600-1;
   MqlRates m15[];
   int expected=(InpBORangeEndHour-InpBORangeStartHour)*4;
   int got=CopyRates(_Symbol,PERIOD_M15,from,to,m15);
   if(got!=expected) return false;  // full closed range required, no future OHLC
   double hi=m15[0].high, lo=m15[0].low;
   for(int i=1;i<got;i++)
   {
      hi=MathMax(hi,m15[i].high);
      lo=MathMin(lo,m15[i].low);
   }
   MqlRates m1[];
   ArraySetAsSeries(m1,true);
   if(CopyRates(_Symbol,PERIOD_M1,0,4,m1)!=4) return false;
   double pad=InpBOBreakoutBufferATR*atr;
   if(m1[2].close<=hi+pad && m1[1].close>hi+pad) direction=1;
   if(m1[2].close>=lo-pad && m1[1].close<lo-pad) direction=-1;
   return true;
}

bool Signal(int &direction,double &atr)
{
   direction=0;
   if(!ReadIndicator(hAtr,1,atr)||atr<=0.0) return false;
   if(InpMode==MGS_RANGE_BREAKOUT) return RangeBreakoutSignal(direction,atr);
   int needed=MathMax(InpStructureLookback+4,20);
   MqlRates bars[];
   ArraySetAsSeries(bars,true);
   if(CopyRates(_Symbol,PERIOD_M1,0,needed,bars)<needed) return false;
   double e9_1,e9_2,e21_1,e20_5,e50_5,rsi;
   if(!ReadIndicator(hEma9,1,e9_1) || !ReadIndicator(hEma9,2,e9_2) ||
      !ReadIndicator(hEma21,1,e21_1) || !ReadIndicator(hEma20M5,1,e20_5) ||
      !ReadIndicator(hEma50M5,1,e50_5) || !ReadIndicator(hRsi,1,rsi)) return false;
   bool buy=e9_1>e21_1 && bars[2].low<=e9_2 &&
            bars[1].close>bars[2].high && bars[1].close>e9_1;
   bool sell=e9_1<e21_1 && bars[2].high>=e9_2 &&
             bars[1].close<bars[2].low && bars[1].close<e9_1;
   if(InpMode>=MGS_EMA_RSI_M5)
   {
      buy=buy && e20_5>e50_5 && rsi>=InpRSIBuyAbove && rsi<=InpRSIUpperLimit;
      sell=sell && e20_5<e50_5 && rsi<=InpRSISellBelow && rsi>=InpRSILowerLimit;
   }
   if(InpMode==MGS_ADVANCED && (buy||sell))
   {
      double adx,plusDI,minusDI;
      if(!ReadIndicator(hAdxM5,1,adx,0) ||
         !ReadIndicator(hAdxM5,1,plusDI,1) ||
         !ReadIndicator(hAdxM5,1,minusDI,2)) return false;
      double range=bars[1].high-bars[1].low;
      double body=MathAbs(bars[1].close-bars[1].open);
      bool strong=(range>0 && range>=InpMinImpulseRangeATR*atr &&
                   body/range>=InpMinCandleBodyFraction);
      double pastHigh=bars[3].high, pastLow=bars[3].low;
      for(int i=4;i<InpStructureLookback+3;i++)
      {
         pastHigh=MathMax(pastHigh,bars[i].high);
         pastLow=MathMin(pastLow,bars[i].low);
      }
      bool bosBuy=bars[1].close>pastHigh, bosSell=bars[1].close<pastLow;
      bool roomBuy=(pastHigh<=bars[1].close ||
                    pastHigh-bars[1].close>=InpMinRoomToLevelATR*atr);
      bool roomSell=(pastLow>=bars[1].close ||
                     bars[1].close-pastLow>=InpMinRoomToLevelATR*atr);
      int buyExtras=((adx>=InpADXMinimum && plusDI>minusDI)?1:0)+(strong?1:0)+(bosBuy?1:0);
      int sellExtras=((adx>=InpADXMinimum && minusDI>plusDI)?1:0)+(strong?1:0)+(bosSell?1:0);
      buy=buy && buyExtras>=InpRequiredAdvancedExtras && (!InpCheckSRRoom || roomBuy);
      sell=sell && sellExtras>=InpRequiredAdvancedExtras && (!InpCheckSRRoom || roomSell);
   }
   if(buy) direction=1;
   if(sell) direction=-1;
   return true;
}

// ENTRY: reject entire setup whenever 0.01 lot would risk too much.
void TryEnter(int direction,double atr)
{
   if(direction==0 || DailyHalt() || HasAnySymbolPosition() || !CanUseAccount()) return;
   if(!DemoEnvironment() && InpEnableDemoOrders) return;
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q) || q.ask<=q.bid) return;
   double spread=q.ask-q.bid;
   if(spread>InpMaxSpreadATR*atr) return;
   bool buy=(direction==1);
   ENUM_ORDER_TYPE side=(buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL);
   double entry=(buy?q.ask:q.bid);
   double minDistance=(SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)+3.0)*_Point;
   double stopWidth=MathMax(InpStopATR*atr,spread+3.0*TickSize());
   double sl=SnapPrice(buy?MathMin(entry-stopWidth,q.bid-minDistance)
                           :MathMax(entry+stopWidth,q.ask+minDistance));
   if((buy && sl>=q.bid-minDistance) || (!buy && sl<=q.ask+minDistance)) return;
   double riskAtMin=0.0;
   double minLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double maxLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(minLot<=0 || step<=0 || maxLot<=0 || InpMaxLots<minLot) return;
   if(!ProjectedLoss(side,minLot,entry,sl,riskAtMin)) return;
   double equity=AccountInfoDouble(ACCOUNT_EQUITY);
   double riskFloor=AccountRiskFloor();
   double remainingDailyRisk=equity-riskFloor;
   double budget=MathMin(equity*InpRiskPct/100.0,remainingDailyRisk);
   if(budget<=0 || riskAtMin>budget+1e-7)
   {
      if(InpLogDecisions)
         PrintFormat("NO TRADE: min lot %.3f risk %.3f %s > allowed %.3f; equity %.2f",
                     minLot,riskAtMin,AccountInfoString(ACCOUNT_CURRENCY),budget,equity);
      return;
   }
   double rawLots=minLot*budget/riskAtMin;
   double cap=MathMin(InpMaxLots,maxLot);
   double volume=minLot+MathFloor((MathMin(rawLots,cap)-minLot)/step+1e-9)*step;
   volume=NormalizeDouble(volume,8);
   double risk=0.0;
   if(volume<minLot || volume>cap+1e-8 || !ProjectedLoss(side,volume,entry,sl,risk) ||
      risk>budget+1e-7) return;
   double margin=0.0;
   if(!OrderCalcMargin(side,_Symbol,volume,entry,margin)) return;
   if(margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE)*InpMaxMarginPctFree/100.0) return;
   double tp=0.0; // trailing-only by default; broker-side stop loss is ALWAYS set
   if(InpUseFixedTP)
      tp=SnapPrice(buy?entry+InpTargetR*MathAbs(entry-sl):entry-InpTargetR*MathAbs(entry-sl));
   if(InpLogDecisions)
      PrintFormat("CANDIDATE: %s %s lots=%.3f price=%.*f SL=%.*f TP=%.*f risk<=%.2f %s",
                  _Symbol,buy?"BUY":"SELL",volume,_Digits,entry,_Digits,sl,_Digits,tp,
                  risk,AccountInfoString(ACCOUNT_CURRENCY));
   if(!InpEnableDemoOrders) return;
   if(!DemoEnvironment()) return; // hard live/contest account block
   // Final guard immediately before submitting an order, accounting for prospective SL risk.
   if(DailyHalt() || AccountInfoDouble(ACCOUNT_EQUITY)-risk<=AccountRiskFloor() ||
      HasAnySymbolPosition() || !CanUseAccount()) return;
   bool placed=(buy?trade.Buy(volume,_Symbol,0.0,sl,tp,"MGS V0.4 DEMO")
                   :trade.Sell(volume,_Symbol,0.0,sl,tp,"MGS V0.4 DEMO"));
   if(!placed || (trade.ResultRetcode()!=TRADE_RETCODE_DONE &&
                  trade.ResultRetcode()!=TRADE_RETCODE_DONE_PARTIAL))
   {
      Print("ENTRY REJECTED: ",trade.ResultRetcodeDescription());
      return;
   }
   // Save ORIGINAL price-risk distance across restarts, so trailing never reconstructs it
   // from a stop that has already moved. If execution slips, inspect effective risk.
   if(PositionSelect(_Symbol) && (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic)
   {
      double actualEntry=PositionGetDouble(POSITION_PRICE_OPEN);
      double actualSL=PositionGetDouble(POSITION_SL);
      if(actualSL>0)
      {
         GlobalVariableSet(PositionRiskKey(),MathAbs(actualEntry-actualSL));
         double actualRisk=0.0;
         if(ProjectedLoss(side,volume,actualEntry,actualSL,actualRisk) && actualRisk>budget+0.0001)
         {
            PrintFormat("EMERGENCY: filled estimated risk %.3f exceeds %.3f account-currency budget; closing position.",actualRisk,budget);
            ulong ticket=(ulong)PositionGetInteger(POSITION_TICKET);
            if(!trade.PositionClose(ticket) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
               Print("EMERGENCY CLOSE FAILED: ",trade.ResultRetcodeDescription());
         }
      }
   }
}

int OnInit()
{
   if((int)InpMode<0 || (int)InpMode>3 ||
      InpRiskPct<=0.0 || InpRiskPct>1.0 || InpDayLossPct<=0.0 || InpDayLossPct>3.0 ||
      InpProfitLockActivatePct<=0.0 || InpProfitLockActivatePct>5.0 ||
      InpProfitKeepPct<=0.0 || InpProfitKeepPct>=100.0 ||
      InpMaxLots<=0.0 || InpMaxMarginPctFree<=0.0 || InpMaxMarginPctFree>80.0 ||
      InpMaxTradesPerDay<1 || InpMaxTradesPerDay>300 ||
      InpRoundTripFeePerLot<0.0 || InpSlipReserveTicks<0.0 ||
      InpStopATR<=0 || InpTrailATR<=0 || InpMaxSpreadATR<=0 || InpTargetR<=0 ||
      InpBreakEvenR<=0 || InpTrailStartR<=0 || InpBEExtraTicks<0 ||
      InpMinModifyTicks<0 || InpMinModifySeconds<0 || InpMinSecondsBetweenEntries<0 ||
      InpAvoidRolloverMinutes<0 || InpAvoidRolloverMinutes>60 ||
      InpSession1Start<0 || InpSession1Start>23 || InpSession1End<0 || InpSession1End>24 ||
      InpSession2Start<0 || InpSession2Start>23 || InpSession2End<0 || InpSession2End>24 ||
      InpBORangeStartHour<0 || InpBORangeStartHour>22 ||
      InpBORangeEndHour<=InpBORangeStartHour || InpBORangeEndHour>23 ||
      InpBOLastEntryHour<=InpBORangeEndHour || InpBOLastEntryHour>24 ||
      InpBOBreakoutBufferATR<0 ||
      InpStructureLookback<4 || InpStructureLookback>200 ||
      InpRequiredAdvancedExtras<1 || InpRequiredAdvancedExtras>3 ||
      InpRSIUpperLimit<=InpRSIBuyAbove || InpRSILowerLimit>=InpRSISellBelow ||
      InpMinCandleBodyFraction<0 || InpMinCandleBodyFraction>1 ||
      InpMinRoomToLevelATR<0 || InpMinImpulseRangeATR<0)
      return INIT_PARAMETERS_INCORRECT;
   if(_Symbol!=InpExpectedSymbol)
   {
      Print("SAFETY: Wrong chart symbol: expected ",InpExpectedSymbol," actual ",_Symbol);
      return INIT_FAILED;
   }
   if(InpEnableDemoOrders && !DemoEnvironment())
   {
      Print("SAFETY: LIVE/CONTEST ACCOUNT BLOCKED. DEMO only.");
      return INIT_FAILED;
   }
   hEma9=iMA(_Symbol,PERIOD_M1,9,0,MODE_EMA,PRICE_CLOSE);
   hEma21=iMA(_Symbol,PERIOD_M1,21,0,MODE_EMA,PRICE_CLOSE);
   hEma20M5=iMA(_Symbol,PERIOD_M5,20,0,MODE_EMA,PRICE_CLOSE);
   hEma50M5=iMA(_Symbol,PERIOD_M5,50,0,MODE_EMA,PRICE_CLOSE);
   hRsi=iRSI(_Symbol,PERIOD_M1,14,PRICE_CLOSE);
   hAtr=iATR(_Symbol,PERIOD_M1,14);
   hAdxM5=iADX(_Symbol,PERIOD_M5,14);
   if(hEma9==INVALID_HANDLE || hEma21==INVALID_HANDLE ||
      hEma20M5==INVALID_HANDLE || hEma50M5==INVALID_HANDLE ||
      hRsi==INVALID_HANDLE || hAtr==INVALID_HANDLE || hAdxM5==INVALID_HANDLE)
      return INIT_FAILED;
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.SetAsyncMode(false);
   // Each new tester run must start with independent day/peak/stop state.
   // Non-tester demo restarts retain persistent daily risk state.
   if(MQLInfoInteger(MQL_TESTER)) GlobalVariablesDeleteAll(Prefix());
   RefreshDay();
   PrintFormat("CONTRACT: minLots=%.3f maxLots=%.3f volumeStep=%.3f, tickSize=%.5f",
               SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN),
               SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX),
               SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP),TickSize());
   PrintFormat("MGS V0.4 RESEARCH: %s mode=%d demoOrders=%s equity=%.2f %s; maxLots=%.3f risk=%.2f%% hardDayLoss=%.2f%% keepPeak=%.1f%%",
               _Symbol,(int)InpMode,InpEnableDemoOrders?"ON":"OFF",AccountInfoDouble(ACCOUNT_EQUITY),
               AccountInfoString(ACCOUNT_CURRENCY),InpMaxLots,InpRiskPct,InpDayLossPct,InpProfitKeepPct);
   Print("WARNING: NO AUTOMATIC ECONOMIC NEWS FILTER. Backtest only before code review. 0.01 GOLD may exceed the risk budget on a GBP 100 account.");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hEma9!=INVALID_HANDLE) IndicatorRelease(hEma9);
   if(hEma21!=INVALID_HANDLE) IndicatorRelease(hEma21);
   if(hEma20M5!=INVALID_HANDLE) IndicatorRelease(hEma20M5);
   if(hEma50M5!=INVALID_HANDLE) IndicatorRelease(hEma50M5);
   if(hRsi!=INVALID_HANDLE) IndicatorRelease(hRsi);
   if(hAtr!=INVALID_HANDLE) IndicatorRelease(hAtr);
   if(hAdxM5!=INVALID_HANDLE) IndicatorRelease(hAdxM5);
}

void OnTick()
{
   if(!DemoEnvironment()) return; // hard block all live-account execution
   bool halted=DailyHalt();
   ManagePositions(halted);        // positions handled on every tick, not just M1 closes
   datetime bar=iTime(_Symbol,PERIOD_M1,0);
   if(bar==0 || bar==lastBar) return;
   lastBar=bar;
   if(halted || !SessionOK() || HasAnySymbolPosition() || !CanUseAccount()) return;
   int today=TradesToday();
   if(today>=InpMaxTradesPerDay || (InpMode==MGS_RANGE_BREAKOUT && today>=1) ||
      !CooldownOK()) return;
   int direction=0;
   double atr=0.0;
   if(!Signal(direction,atr) || direction==0) return;
   TryEnter(direction,atr);
}
