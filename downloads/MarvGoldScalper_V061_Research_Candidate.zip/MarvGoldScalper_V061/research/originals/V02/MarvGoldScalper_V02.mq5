//+------------------------------------------------------------------+
//| MarvGoldScalper_V02.mq5                                           |
//| DEMO RESEARCH PROTOTYPE: EMA + RSI momentum, ATR stops            |
//| NOT COMPILED/VALIDATED IN MT5. Never attach to a live account.     |
//+------------------------------------------------------------------+
#property copyright "Research prototype"
#property version   "0.20"
#property strict
#include <Trade/Trade.mqh>

input bool   InpEnableDemoOrders = false; // SAFE DEFAULT: observe/log only
input bool   InpUseRSIFilter    = false; // A=FALSE, B=TRUE
input bool   InpUseM5Filter     = false; // A=FALSE, extra filter if TRUE
input double InpRiskPct          = 0.25;  // Percentage of account equity, not price
input double InpDayLossPct       = 1.50;  // Day loss lock based on equity
input double InpMaxSpreadATR     = 0.20;  // Spread as fraction of M1 ATR
input double InpStopATR          = 1.50;
input double InpTargetR          = 1.80;
input double InpBreakEvenR       = 1.00;
input double InpTrailStartR      = 1.50;
input double InpTrailATR         = 1.20;
input double InpMinModifyTicks   = 3.0;
input int    InpMaxTradesPerDay  = 8;
input int    InpSessionStartHour = 0;     // BROKER SERVER time, 0-23
input int    InpSessionEndHour   = 24;    // exclusive; 24 means midnight
input double InpRSIBuyAbove     = 52.0;
input double InpRSISellBelow    = 48.0;
input double InpRoundTripFeePerLot = 0.0; // ACCOUNT currency, must configure!
input ulong  InpMagic           = 20261020;
input int    InpDeviationPoints = 30;

CTrade trade;
int hEma9=INVALID_HANDLE,hEma21=INVALID_HANDLE,hEma20M5=INVALID_HANDLE;
int hEma50M5=INVALID_HANDLE,hRsi=INVALID_HANDLE,hAtr=INVALID_HANDLE;
datetime lastBar=0;
string dayEquityKey="", dayHaltKey="";

double TickSize()
{
   double sz=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   return sz>0?sz:_Point;
}

double SnapPrice(double p)
{
   double t=TickSize();
   return NormalizeDouble(MathRound(p/t)*t,_Digits);
}

bool ReadIndicator(int handle,int shift,double &value)
{
   double b[];
   if(CopyBuffer(handle,0,shift,1,b)!=1) return false;
   value=b[0];
   return MathIsValidNumber(value) && value!=EMPTY_VALUE;
}

bool DemoEnvironment()
{
   return AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_DEMO;
}

string Prefix()
{
   return "MGS_"+(string)AccountInfoInteger(ACCOUNT_LOGIN)+"_"+(string)InpMagic+"_"+_Symbol+"_";
}

void ResetDailyKeys()
{
   MqlDateTime dt;
   TimeToStruct(TimeTradeServer(),dt);
   string day=StringFormat("%04d%02d%02d",dt.year,dt.mon,dt.day);
   string p=Prefix()+day;
   dayEquityKey=p+"_equity";
   dayHaltKey=p+"_halt";
   if(!GlobalVariableCheck(dayEquityKey))
      GlobalVariableSet(dayEquityKey,AccountInfoDouble(ACCOUNT_EQUITY));
   if(!GlobalVariableCheck(dayHaltKey))
      GlobalVariableSet(dayHaltKey,0.0);
}

bool IsHalted()
{
   ResetDailyKeys();
   double startEquity=GlobalVariableGet(dayEquityKey);
   if(startEquity<=0) return true;
   double nowEquity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(nowEquity<=startEquity*(1.0-InpDayLossPct/100.0))
   {
      if(GlobalVariableGet(dayHaltKey)<0.5)
         Print("DAILY LOSS GUARD TRIGGERED: New entries blocked, closing owned position.");
      GlobalVariableSet(dayHaltKey,1.0);
   }
   return GlobalVariableGet(dayHaltKey)>=0.5;
}

int TradesToday()
{
   MqlDateTime dt;
   TimeToStruct(TimeTradeServer(),dt);
   dt.hour=0; dt.min=0; dt.sec=0;
   datetime from=StructToTime(dt);
   if(!HistorySelect(from,TimeTradeServer())) return InpMaxTradesPerDay;
   int count=0;
   for(int i=HistoryDealsTotal()-1;i>=0;i--)
   {
      ulong id=HistoryDealGetTicket(i);
      if(id==0) continue;
      if(HistoryDealGetString(id,DEAL_SYMBOL)!=_Symbol) continue;
      if((ulong)HistoryDealGetInteger(id,DEAL_MAGIC)!=InpMagic) continue;
      if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(id,DEAL_ENTRY)==DEAL_ENTRY_IN) count++;
   }
   return count;
}

bool HasAnySymbolPosition()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket!=0 && PositionSelectByTicket(ticket) &&
         PositionGetString(POSITION_SYMBOL)==_Symbol) return true;
   }
   return false;
}

bool IsOurPosition(ulong ticket)
{
   if(!PositionSelectByTicket(ticket)) return false;
   return PositionGetString(POSITION_SYMBOL)==_Symbol &&
          (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic;
}

string InitialRiskKey()
{
   return Prefix()+"risk_"+(string)PositionGetInteger(POSITION_IDENTIFIER);
}

void ManageOwnedPosition(bool closeForHalt)
{
   if(!InpEnableDemoOrders || !DemoEnvironment()) return;
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q)) return;
   double atr=0;
   if(!closeForHalt && (!ReadIndicator(hAtr,1,atr)||atr<=0)) return;
   double minDistance=(MathMax((double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL),
                               (double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL))+2.0)*_Point;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(!IsOurPosition(ticket)) continue;
      if(closeForHalt)
      {
         if(!trade.PositionClose(ticket) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
            Print("WARNING: failed to close on daily halt: ",trade.ResultRetcodeDescription());
         continue;
      }
      string riskKey=InitialRiskKey();
      if(!GlobalVariableCheck(riskKey))
      {
         // No guesswork after restart: original stop width is essential.
         Print("Original risk unavailable for position ",ticket,". Leaving broker-side stop unchanged.");
         continue;
      }
      double initialRisk=GlobalVariableGet(riskKey);
      if(initialRisk<=0) continue;
      double entry=PositionGetDouble(POSITION_PRICE_OPEN);
      double oldSL=PositionGetDouble(POSITION_SL);
      double takeProfit=PositionGetDouble(POSITION_TP);
      if(oldSL<=0) continue;
      ENUM_POSITION_TYPE side=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      bool buy=(side==POSITION_TYPE_BUY);
      double exitPrice=buy?q.bid:q.ask;
      double favourable=buy?(exitPrice-entry):(entry-exitPrice);
      double candidate=oldSL;
      double tick=TickSize();
      if(favourable>=InpBreakEvenR*initialRisk)
      {
         // Gross breakeven + minimal tick buffer; NOT a fee-adjusted guarantee.
         double be=entry+(buy?2.0:-2.0)*tick;
         candidate=buy?MathMax(candidate,be):MathMin(candidate,be);
      }
      if(favourable>=InpTrailStartR*initialRisk)
      {
         double trail=buy?(q.bid-InpTrailATR*atr):(q.ask+InpTrailATR*atr);
         candidate=buy?MathMax(candidate,trail):MathMin(candidate,trail);
      }
      candidate=SnapPrice(candidate);
      bool improved=buy?(candidate>oldSL+InpMinModifyTicks*tick)
                       :(candidate<oldSL-InpMinModifyTicks*tick);
      bool legal=buy?(candidate<q.bid-minDistance):(candidate>q.ask+minDistance);
      if(improved && legal)
      {
         if(!trade.PositionModify(ticket,candidate,takeProfit) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
            Print("Stop update rejected: ",trade.ResultRetcodeDescription());
      }
   }
}

bool SessionPermitsTrading()
{
   MqlDateTime dt;
   TimeToStruct(TimeTradeServer(),dt);
   int hour=dt.hour;
   if(InpSessionStartHour==0 && InpSessionEndHour==24) return true;
   if(InpSessionStartHour<InpSessionEndHour)
      return hour>=InpSessionStartHour && hour<InpSessionEndHour;
   if(InpSessionStartHour>InpSessionEndHour)
      return hour>=InpSessionStartHour || hour<InpSessionEndHour;
   return false;
}

bool Signal(int &direction, double &atr)
{
   direction=0;
   MqlRates bars[];
   ArraySetAsSeries(bars,true);
   if(CopyRates(_Symbol,PERIOD_M1,0,5,bars)<5) return false;
   double e9_1,e9_2,e21_1,e20_5,e50_5,rsi;
   if(!ReadIndicator(hEma9,1,e9_1) || !ReadIndicator(hEma9,2,e9_2) ||
      !ReadIndicator(hEma21,1,e21_1) || !ReadIndicator(hEma20M5,1,e20_5) ||
      !ReadIndicator(hEma50M5,1,e50_5) || !ReadIndicator(hRsi,1,rsi) ||
      !ReadIndicator(hAtr,1,atr) || atr<=0) return false;
   // Last completed M1 bar is bars[1]. bars[2] is the pullback candle.
   bool m5Buy = !InpUseM5Filter || e20_5>e50_5;
   bool m5Sell= !InpUseM5Filter || e20_5<e50_5;
   bool rsiBuy= !InpUseRSIFilter || rsi>=InpRSIBuyAbove;
   bool rsiSell= !InpUseRSIFilter || rsi<=InpRSISellBelow;
   bool bullish=m5Buy && e9_1>e21_1 && rsiBuy &&
                bars[2].low<=e9_2 && bars[1].close>bars[2].high &&
                bars[1].close>e9_1;
   bool bearish=m5Sell && e9_1<e21_1 && rsiSell &&
                bars[2].high>=e9_2 && bars[1].close<bars[2].low &&
                bars[1].close<e9_1;
   if(bullish) direction=1;
   if(bearish) direction=-1;
   return true;
}

void TryEnter(int direction,double atr)
{
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q)||q.ask<=q.bid) return;
   double spread=q.ask-q.bid;
   if(spread>InpMaxSpreadATR*atr) return;
   bool buy=(direction==1);
   double entry=buy?q.ask:q.bid;
   double stopDistance=MathMax(InpStopATR*atr,spread+3.0*TickSize());
   double minimum=(SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)+3.0)*_Point;
   double stop=SnapPrice(buy?MathMin(entry-stopDistance,q.bid-minimum)
                            :MathMax(entry+stopDistance,q.ask+minimum));
   double riskDistance=MathAbs(entry-stop);
   if(riskDistance<=0) return;
   double tp=SnapPrice(buy?entry+InpTargetR*riskDistance
                          :entry-InpTargetR*riskDistance);
   double minLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   double maxLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   if(minLot<=0||step<=0||maxLot<=0) return;
   ENUM_ORDER_TYPE type=buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
   double atMinProfit=0;
   if(!OrderCalcProfit(type,_Symbol,minLot,entry,stop,atMinProfit)) return;
   double riskAtMin=-atMinProfit + minLot*InpRoundTripFeePerLot;
   if(riskAtMin<=0) return;
   double budget=AccountInfoDouble(ACCOUNT_EQUITY)*InpRiskPct/100.0;
   if(riskAtMin>budget)
   {
      PrintFormat("SKIP: min volume %.3f risks %.2f, exceeds risk budget %.2f",
                  minLot,riskAtMin,budget);
      return;
   }
   double rawLots=budget/riskAtMin*minLot;
   double volume=MathFloor(rawLots/step+1e-9)*step;
   volume=MathMin(volume,maxLot);
   volume=NormalizeDouble(volume,8);
   if(volume<minLot) return;
   double theoreticalProfit=0;
   if(!OrderCalcProfit(type,_Symbol,volume,entry,stop,theoreticalProfit)) return;
   if(-theoreticalProfit+volume*InpRoundTripFeePerLot > budget+0.0001) return;
   double margin=0;
   if(!OrderCalcMargin(type,_Symbol,volume,entry,margin)) return;
   if(margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE)*0.50)
   {
      Print("SKIP: margin would use over half the available free margin.");
      return;
   }
   PrintFormat("CANDIDATE %s %s lots=%.3f entry=%.*f SL=%.*f TP=%.*f",
               _Symbol,buy?"BUY":"SELL",volume,_Digits,entry,_Digits,stop,_Digits,tp);
   if(!InpEnableDemoOrders) return;
   if(!DemoEnvironment())
   {
      Print("LIVE/CONTEST ACCOUNT BLOCKED. DEMO only.");
      return;
   }
   bool sent=buy?trade.Buy(volume,_Symbol,0.0,stop,tp,"MGS v0.2")
                :trade.Sell(volume,_Symbol,0.0,stop,tp,"MGS v0.2");
   if(!sent || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
   {
      Print("Order not filled: ",trade.ResultRetcodeDescription());
      return;
   }
   if(PositionSelect(_Symbol) && (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic)
   {
      // Use actual fill price, and preserve the original stop distance across restarts.
      double realEntry=PositionGetDouble(POSITION_PRICE_OPEN);
      string key=InitialRiskKey();
      GlobalVariableSet(key,MathAbs(realEntry-PositionGetDouble(POSITION_SL)));
   }
}

int OnInit()
{
   if(InpRiskPct<=0||InpRiskPct>1||InpDayLossPct<=0||InpDayLossPct>5||
      InpStopATR<=0||InpTargetR<=0||InpTrailATR<=0||InpMaxSpreadATR<=0||
      InpSessionStartHour<0||InpSessionStartHour>23||InpSessionEndHour<0||InpSessionEndHour>24||
      InpMaxTradesPerDay<=0||InpRoundTripFeePerLot<0)
      return INIT_PARAMETERS_INCORRECT;
   if(InpEnableDemoOrders && !DemoEnvironment())
   {
      Print("SAFETY STOP: this prototype can execute only in demo accounts.");
      return INIT_FAILED;
   }
   hEma9=iMA(_Symbol,PERIOD_M1,9,0,MODE_EMA,PRICE_CLOSE);
   hEma21=iMA(_Symbol,PERIOD_M1,21,0,MODE_EMA,PRICE_CLOSE);
   hEma20M5=iMA(_Symbol,PERIOD_M5,20,0,MODE_EMA,PRICE_CLOSE);
   hEma50M5=iMA(_Symbol,PERIOD_M5,50,0,MODE_EMA,PRICE_CLOSE);
   hRsi=iRSI(_Symbol,PERIOD_M1,14,PRICE_CLOSE);
   hAtr=iATR(_Symbol,PERIOD_M1,14);
   if(hEma9==INVALID_HANDLE||hEma21==INVALID_HANDLE||hEma20M5==INVALID_HANDLE||
      hEma50M5==INVALID_HANDLE||hRsi==INVALID_HANDLE||hAtr==INVALID_HANDLE)
      return INIT_FAILED;
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.SetAsyncMode(false);
   ResetDailyKeys();
   Print("MGS v0.2 initialized on ",_Symbol,". DEMO orders enabled=",InpEnableDemoOrders,
         ", RSI filter=",InpUseRSIFilter,", M5 filter=",InpUseM5Filter,
         ". Broker server time governs session filters; NO macro news filter yet.");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hEma9!=INVALID_HANDLE) IndicatorRelease(hEma9);
   if(hEma21!=INVALID_HANDLE) IndicatorRelease(hEma21);
   if(hEma20M5!=INVALID_HANDLE) IndicatorRelease(hEma20M5);
   if(hEma50M5!=INVALID_HANDLE) IndicatorRelease(hEma50M5);
   if(hRsi!=INVALID_HANDLE) IndicatorRelease(hRsi);
   if(hAtr!=INVALID_HANDLE) IndicatorRelease(hAtr);
}

void OnTick()
{
   bool halted=IsHalted();
   ManageOwnedPosition(halted); // continue to enforce protections even outside session
   datetime bar=iTime(_Symbol,PERIOD_M1,0);
   if(bar==0||bar==lastBar) return;
   lastBar=bar;
   if(halted||!SessionPermitsTrading()||HasAnySymbolPosition()||
      TradesToday()>=InpMaxTradesPerDay) return;
   int direction=0;
   double atr=0;
   if(!Signal(direction,atr)||direction==0) return;
   TryEnter(direction,atr);
}
