# Marv Gold Scalper V0.2: beginner test package

**Status:** Research prototype. Created and structurally inspected, but **not compiled in the official MetaEditor terminal and not backtested**. Demo ONLY; live accounts are explicitly blocked by the source. No profitability established.

## Strategy switch settings
- **A, EMA-only baseline:** InpUseRSIFilter=false; InpUseM5Filter=false. M1 EMA9 vs EMA21, completed pullback and momentum confirmation; ATR stop.
- **B, EMA + RSI:** InpUseRSIFilter=true; InpUseM5Filter=false. Same entries except M1 RSI >= 52 for buys, <= 48 for sells.
- **Additional M5 short-term trend filter:** set InpUseM5Filter=true in either A or B. Uses M5 EMA20 vs EMA50.
- **C, EMA + RSI + market-condition/CFBI filter:** NOT implemented. Don't call A or B a C test. First obtain a documented, timestamped macro/news dataset and precise scoring rules and then build/test C separately.

## How to begin on Windows
1. Make an **FxPro MT5 demo account**. Do not deposit real money. Select a realistic demo balance and record account base currency.
2. Install desktop MetaTrader 5 from https://www.fxpro.com/trading-platforms/metatrader5. Log into the correct **demo server** with the demo trading login and password (do not share credentials in chats).
3. In MT5 press **Ctrl+M** to show Market Watch, right-click and choose **Show All** if needed. Search for standard gold (XAUUSD or broker-suffixed equivalent). Right-click the actual symbol and open **Specification**. Save min volume, volume step, contract size, tick size/value, stops level, currency, swap and spreads.
4. MT5: **File > Open Data Folder > MQL5 > Experts**. Copy `MarvGoldScalper_V02.mq5` into Experts.
5. Back in MT5 press **F4** to open MetaEditor. Open the EA in Experts, press **F7** (Compile). Verify 0 errors and review warnings. If errors occur, do not assume code works; copy the exact compiler messages for correction.
6. Return to MT5. Press **Ctrl+N** to open Navigator and right-click Expert Advisors > Refresh. Open an XAUUSD **M1** chart. Double click/drag the EA onto the chart. Inputs should show `InpEnableDemoOrders=false` (signals only).
7. Check **Experts** and **Journal** tabs for log messages; new valid entry candidates will appear as `CANDIDATE...`, if strategy and risk filters pass.
8. Run a historical simulation: **Ctrl+R** Strategy Tester > Single test, select EA, symbol, M1, date range and `Every tick based on real ticks` if available. In testing only, set `InpEnableDemoOrders=true`; the EA includes a demo-account block, but test this functionality first. Enable visualization to inspect order entries. Check trade count, max equity drawdown, net return, average win/loss, costs and rejected orders.
9. Compare A and B with **identical** dates, broker symbols, spread/tick data, equity and risk settings, then test M5 toggled on/off. Do not optimize on final evaluation data.
10. After backtests and code review, run on dedicated demo account for 4 to 8 weeks or more. A 1-week demo is a functional smoke test, not validation of profit.

## Safety and testing limitations
- Default `InpEnableDemoOrders=false`; source hard-blocks trade orders when account is not demo, but not production audited. DO NOT DEPLOY TO LIVE.
- Gold minimum lot sizes might exceed the intended account risk; bot *skips* these trades.
- Default `InpSessionStartHour=0`, `InpSessionEndHour=24` means all hours in **broker server time** for data exploration; before forward tests choose explicit session hours, accounting for broker time zone/DST.
- Fees default to zero (`InpRoundTripFeePerLot=0`) and should be calibrated. Risk & nominal breakeven don't guarantee filled prices during volatility.
- Daily loss baseline recorded on first initialization per broker calendar day; use a dedicated demo account and review/reset carefully as appropriate for tests.
- ATR trailing is a proposed hypothesis; not proven better than a fixed exit. The code does NOT yet support a macro/CFBI score, news filter, event logs CSV, proper transaction-reconciliation tests, or Python ML model.
- Fix issues found through compilation, visual testing and simulated broker rejections before testing unattended.
