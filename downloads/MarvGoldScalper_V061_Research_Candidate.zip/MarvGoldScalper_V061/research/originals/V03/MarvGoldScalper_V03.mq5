//+------------------------------------------------------------------+
//| MarvGoldScalper_V03.mq5                                           |
//| DEMO RESEARCH PROTOTYPE: EMA/RSI/M5 + regime/structure momentum, risk controls            |
//| UNCOMPILED RESEARCH PROTOTYPE. DEMO ACCOUNT ONLY.     |
//+------------------------------------------------------------------+
#property copyright "Research prototype"
#property version   "0.30"
#property strict
#include <Trade/Trade.mqh>

// Mode 0 preserves V0.2 ENTRY CONDITIONS, not identical end-to-end behavior:
// V0.3 adds throttled, cost-aware stops, session gating and new loss guards.
// Advanced is NOT proven better; test each mode on the same unseen data.
enum ENUM_MGS_MODE { MGS_EMA_BASELINE=0, MGS_EMA_RSI_M5=1, MGS_ADVANCED=2 };
input ENUM_MGS_MODE InpMode = MGS_ADVANCED;
input bool   InpEnableDemoOrders  = false;  // HARD GATE: default signals only, demo account only
input string InpExpectedSymbol    = "GOLD"; // Exact FxPro symbol, can be changed on another DEMO broker
input double InpRiskPct           = 0.25;
input double InpDayLossPct        = 1.50;
input int    InpMaxTradesPerDay   = 60;     // Backtest research ceiling, not a target
input int    InpMinSecondsBetweenEntries = 120;
input int    InpMaxConsecutiveLosses = 4;
input double InpMaxMarginPctFree  = 40.0;

// Two windows in BROKER SERVER time. Map broker time to UK time before deployment.
input bool   InpUseSessions       = true;
input int    InpSession1Start     = 7;
input int    InpSession1End       = 11;
input int    InpSession2Start     = 13;
input int    InpSession2End       = 17;
// MANUAL high-impact news blackout, no automatic calendar integration in V0.3.
input datetime InpManualBlackoutStart = 0;
input datetime InpManualBlackoutEnd   = 0;

input double InpMaxSpreadATR      = 0.20;
input double InpStopATR           = 1.50;
input double InpTargetR           = 1.80;
input double InpBreakEvenR        = 1.00;
input double InpTrailStartR       = 1.50;
input double InpTrailATR          = 1.20;
input double InpMinModifyTicks    = 20.0; // avoid excessive repeated broker stop updates
input int    InpMinModifySeconds  = 15;
input double InpRSIBuyAbove      = 52.0;
input double InpRSISellBelow     = 48.0;
input double InpRSIUpperLimit    = 75.0;
input double InpRSILowerLimit    = 25.0;
input double InpADXMinimum       = 18.0;
input double InpMinCandleBodyFraction = 0.50;
input double InpMinImpulseRangeATR = 0.45;
input int    InpStructureLookback = 12;
input double InpMinRoomToLevelATR = 0.75;
input int    InpRequiredAdvancedExtras = 2; // of 3: ADX, candle strength, prior-range break
input bool   InpCheckSRRoom      = true;
input bool   InpLogDecisions     = false;
input double InpRoundTripFeePerLot = 7.0; // ACCOUNT currency estimate for RISK and BE only;
                                            // does NOT subtract broker commissions from MT5 P/L
input double InpBEExtraTicks    = 10.0; // extra room for tiny slippage, not a guarantee
input ulong  InpMagic           = 20261020;
input int    InpDeviationPoints = 30;
CTrade trade;
int hEma9=INVALID_HANDLE,hEma21=INVALID_HANDLE,hEma20M5=INVALID_HANDLE;
int hEma50M5=INVALID_HANDLE,hRsi=INVALID_HANDLE,hAtr=INVALID_HANDLE,hAdxM5=INVALID_HANDLE;
datetime lastBar=0;
string dayEquityKey="", dayHaltKey="";

double TickSize()
{
   double sz=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   return sz>0?sz:_Point;
}

double SnapPrice(double p)
{
   double t=TickSize();
   return NormalizeDouble(MathRound(p/t)*t,_Digits);
}

bool ReadIndicator(int handle,int shift,double &value,int bufferIndex=0)
{
   double b[];
   if(CopyBuffer(handle,bufferIndex,shift,1,b)!=1) return false;
   value=b[0];
   return MathIsValidNumber(value) && value!=EMPTY_VALUE;
}

bool DemoEnvironment()
{
   return AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_DEMO;
}

string Prefix()
{
   return "MGS_"+(string)AccountInfoInteger(ACCOUNT_LOGIN)+"_"+(string)InpMagic+"_"+_Symbol+"_";
}

void ResetDailyKeys()
{
   MqlDateTime dt;
   TimeToStruct(TimeTradeServer(),dt);
   string day=StringFormat("%04d%02d%02d",dt.year,dt.mon,dt.day);
   string p=Prefix()+day;
   dayEquityKey=p+"_equity";
   dayHaltKey=p+"_halt";
   if(!GlobalVariableCheck(dayEquityKey))
      GlobalVariableSet(dayEquityKey,AccountInfoDouble(ACCOUNT_EQUITY));
   if(!GlobalVariableCheck(dayHaltKey))
      GlobalVariableSet(dayHaltKey,0.0);
}

bool IsHalted()
{
   ResetDailyKeys();
   double startEquity=GlobalVariableGet(dayEquityKey);
   if(startEquity<=0) return true;
   double nowEquity=AccountInfoDouble(ACCOUNT_EQUITY);
   if(nowEquity<=startEquity*(1.0-InpDayLossPct/100.0))
   {
      if(GlobalVariableGet(dayHaltKey)<0.5)
         Print("DAILY LOSS GUARD TRIGGERED: New entries blocked, closing owned position.");
      GlobalVariableSet(dayHaltKey,1.0);
   }
   return GlobalVariableGet(dayHaltKey)>=0.5;
}

int TradesToday()
{
   MqlDateTime dt;
   TimeToStruct(TimeTradeServer(),dt);
   dt.hour=0; dt.min=0; dt.sec=0;
   datetime from=StructToTime(dt);
   if(!HistorySelect(from,TimeTradeServer())) return InpMaxTradesPerDay;
   int count=0;
   for(int i=HistoryDealsTotal()-1;i>=0;i--)
   {
      ulong id=HistoryDealGetTicket(i);
      if(id==0) continue;
      if(HistoryDealGetString(id,DEAL_SYMBOL)!=_Symbol) continue;
      if((ulong)HistoryDealGetInteger(id,DEAL_MAGIC)!=InpMagic) continue;
      if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(id,DEAL_ENTRY)==DEAL_ENTRY_IN) count++;
   }
   return count;
}

bool HasAnySymbolPosition()
{
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(ticket!=0 && PositionSelectByTicket(ticket) &&
         PositionGetString(POSITION_SYMBOL)==_Symbol) return true;
   }
   return false;
}

bool IsOurPosition(ulong ticket)
{
   if(!PositionSelectByTicket(ticket)) return false;
   return PositionGetString(POSITION_SYMBOL)==_Symbol &&
          (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic;
}

string InitialRiskKey()
{
   return Prefix()+"risk_"+(string)PositionGetInteger(POSITION_IDENTIFIER);
}

// Inputs are in account currency; this calculates a conservative price move
// that might cover an estimated round-trip fee plus a tick buffer.
double BreakevenPrice(const bool buy,const double entry,const double volume)
{
   ENUM_ORDER_TYPE type=buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
   double tick=TickSize();
   double oneTickPL=0.0;
   if(!OrderCalcProfit(type,_Symbol,volume,entry,
                       entry+(buy?tick:-tick),oneTickPL) || oneTickPL<=0.0)
      return entry+(buy?1:-1)*InpBEExtraTicks*tick;
   double ticksForFees=(InpRoundTripFeePerLot*volume)/oneTickPL;
   return entry+(buy?1:-1)*(ticksForFees+InpBEExtraTicks)*tick;
}

string LastModifyKey()
{
   return Prefix()+"modified_"+(string)PositionGetInteger(POSITION_IDENTIFIER);
}

bool InHourWindow(const int hour,const int begin,const int finish)
{
   if(begin==finish) return false;
   if(begin<finish) return hour>=begin && hour<finish;
   return hour>=begin || hour<finish;
}

bool InManualBlackout()
{
   if(InpManualBlackoutStart<=0 || InpManualBlackoutEnd<=InpManualBlackoutStart)
      return false;
   datetime now=TimeTradeServer();
   return now>=InpManualBlackoutStart && now<InpManualBlackoutEnd;
}

int RecentLossStreak()
{
   datetime now=TimeTradeServer();
   MqlDateTime stamp;
   TimeToStruct(now,stamp);
   stamp.hour=0; stamp.min=0; stamp.sec=0;
   // Reset the loss streak at broker midnight. Otherwise a halted EA could
   // stay locked indefinitely without any chance to create a winning trade.
   if(!HistorySelect(StructToTime(stamp),now)) return InpMaxConsecutiveLosses;
   int lossCount=0;
   for(int i=HistoryDealsTotal()-1;i>=0;i--)
   {
      ulong deal=HistoryDealGetTicket(i);
      if(deal==0 || HistoryDealGetString(deal,DEAL_SYMBOL)!=_Symbol) continue;
      if((ulong)HistoryDealGetInteger(deal,DEAL_MAGIC)!=InpMagic) continue;
      ENUM_DEAL_ENTRY entry=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY);
      if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY && entry!=DEAL_ENTRY_INOUT)
         continue;
      double net=HistoryDealGetDouble(deal,DEAL_PROFIT)+
                 HistoryDealGetDouble(deal,DEAL_COMMISSION)+
                 HistoryDealGetDouble(deal,DEAL_SWAP)+
                 HistoryDealGetDouble(deal,DEAL_FEE);
      if(net<0.0) lossCount++;
      else if(net>0.0) break;
      // Flat exit considered neutral. We do not claim exact full round-trip
      // net profit here because some brokers apply commission on entry.
   }
   return lossCount;
}

bool CooldownElapsed()
{
   datetime now=TimeTradeServer();
   if(!HistorySelect(now-86400,now)) return false;
   for(int i=HistoryDealsTotal()-1;i>=0;i--)
   {
      ulong deal=HistoryDealGetTicket(i);
      if(deal==0 || HistoryDealGetString(deal,DEAL_SYMBOL)!=_Symbol) continue;
      if((ulong)HistoryDealGetInteger(deal,DEAL_MAGIC)!=InpMagic) continue;
      if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(deal,DEAL_ENTRY)!=DEAL_ENTRY_IN) continue;
      datetime opened=(datetime)HistoryDealGetInteger(deal,DEAL_TIME);
      return (now-opened>=InpMinSecondsBetweenEntries);
   }
   return true;
}

void ManageOwnedPosition(bool closeForHalt)
{
   if(!InpEnableDemoOrders || !DemoEnvironment()) return;
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q)) return;
   double atr=0;
   if(!closeForHalt && (!ReadIndicator(hAtr,1,atr)||atr<=0)) return;
   double minDistance=(MathMax((double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL),
                               (double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_FREEZE_LEVEL))+2.0)*_Point;
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      ulong ticket=PositionGetTicket(i);
      if(!IsOurPosition(ticket)) continue;
      if(closeForHalt)
      {
         if(!trade.PositionClose(ticket) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
            Print("WARNING: failed to close on daily halt: ",trade.ResultRetcodeDescription());
         continue;
      }
      string riskKey=InitialRiskKey();
      if(!GlobalVariableCheck(riskKey))
      {
         // No guesswork after restart: original stop width is essential.
         Print("Original risk unavailable for position ",ticket,". Leaving broker-side stop unchanged.");
         continue;
      }
      double initialRisk=GlobalVariableGet(riskKey);
      if(initialRisk<=0) continue;
      double entry=PositionGetDouble(POSITION_PRICE_OPEN);
      double oldSL=PositionGetDouble(POSITION_SL);
      double takeProfit=PositionGetDouble(POSITION_TP);
      if(oldSL<=0) continue;
      ENUM_POSITION_TYPE side=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      bool buy=(side==POSITION_TYPE_BUY);
      double exitPrice=buy?q.bid:q.ask;
      double favourable=buy?(exitPrice-entry):(entry-exitPrice);
      double candidate=oldSL;
      double tick=TickSize();
      if(favourable>=InpBreakEvenR*initialRisk)
      {
         // Gross breakeven + minimal tick buffer; NOT a fee-adjusted guarantee.
         double be=BreakevenPrice(buy,entry,PositionGetDouble(POSITION_VOLUME));
         candidate=buy?MathMax(candidate,be):MathMin(candidate,be);
      }
      if(favourable>=InpTrailStartR*initialRisk)
      {
         double trail=buy?(q.bid-InpTrailATR*atr):(q.ask+InpTrailATR*atr);
         candidate=buy?MathMax(candidate,trail):MathMin(candidate,trail);
      }
      candidate=SnapPrice(candidate);
      bool improved=buy?(candidate>oldSL+InpMinModifyTicks*tick)
                       :(candidate<oldSL-InpMinModifyTicks*tick);
      bool legal=buy?(candidate<q.bid-minDistance):(candidate>q.ask+minDistance);
      string modifyKey=LastModifyKey();
      datetime now=TimeTradeServer();
      bool throttle=!GlobalVariableCheck(modifyKey) ||
                     now-(datetime)GlobalVariableGet(modifyKey)>=InpMinModifySeconds;
      if(improved && legal && throttle)
      {
         if(!trade.PositionModify(ticket,candidate,takeProfit) || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
            Print("Stop update rejected: ",trade.ResultRetcodeDescription());
         else
            GlobalVariableSet(modifyKey,(double)now);
      }
   }
}

bool SessionPermitsTrading()
{
   if(!InpUseSessions) return true;
   MqlDateTime dt;
   TimeToStruct(TimeTradeServer(),dt);
   return InHourWindow(dt.hour,InpSession1Start,InpSession1End) ||
          InHourWindow(dt.hour,InpSession2Start,InpSession2End);
}

// All pattern comparisons use closed M1 and M5 candles only. There is no
// pivot-fractal future-bar access or hindsight repainting.
bool Signal(int &direction,double &atr)
{
   direction=0;
   int needed=MathMax(InpStructureLookback+4,20);
   MqlRates bars[];
   ArraySetAsSeries(bars,true);
   if(CopyRates(_Symbol,PERIOD_M1,0,needed,bars)<needed) return false;
   double e9_1,e9_2,e21_1,e20_5,e50_5,rsi;
   if(!ReadIndicator(hEma9,1,e9_1) || !ReadIndicator(hEma9,2,e9_2) ||
      !ReadIndicator(hEma21,1,e21_1) || !ReadIndicator(hEma20M5,1,e20_5) ||
      !ReadIndicator(hEma50M5,1,e50_5) || !ReadIndicator(hRsi,1,rsi) ||
      !ReadIndicator(hAtr,1,atr) || atr<=0) return false;

   bool m5Buy=e20_5>e50_5;
   bool m5Sell=e20_5<e50_5;
   bool rsiBuy=(rsi>=InpRSIBuyAbove && rsi<=InpRSIUpperLimit);
   bool rsiSell=(rsi<=InpRSISellBelow && rsi>=InpRSILowerLimit);

   bool buy=e9_1>e21_1 && bars[2].low<=e9_2 &&
            bars[1].close>bars[2].high && bars[1].close>e9_1;
   bool sell=e9_1<e21_1 && bars[2].high>=e9_2 &&
             bars[1].close<bars[2].low && bars[1].close<e9_1;
   if(InpMode>=MGS_EMA_RSI_M5)
   {
      buy=buy && m5Buy && rsiBuy;
      sell=sell && m5Sell && rsiSell;
   }

   if(InpMode==MGS_ADVANCED && (buy||sell))
   {
      double adx,plusDI,minusDI;
      if(!ReadIndicator(hAdxM5,1,adx,0) ||
         !ReadIndicator(hAdxM5,1,plusDI,1) ||
         !ReadIndicator(hAdxM5,1,minusDI,2)) return false;
      bool adxBuy=adx>=InpADXMinimum && plusDI>minusDI;
      bool adxSell=adx>=InpADXMinimum && minusDI>plusDI;
      double range=bars[1].high-bars[1].low;
      double body=MathAbs(bars[1].close-bars[1].open);
      bool bodyStrong=(range>0 && range>=InpMinImpulseRangeATR*atr &&
                       body/range>=InpMinCandleBodyFraction);
      // Resistance and support = high/low of N earlier fully closed M1 bars.
      // BOS is a simple prior-range close break, NOT full ICT/SMC structure.
      double pastHigh=bars[3].high;
      double pastLow=bars[3].low;
      for(int i=4;i<InpStructureLookback+3;i++)
      {
         pastHigh=MathMax(pastHigh,bars[i].high);
         pastLow=MathMin(pastLow,bars[i].low);
      }
      bool bosBuy=bars[1].close>pastHigh;
      bool bosSell=bars[1].close<pastLow;
      bool roomBuy=(pastHigh<=bars[1].close ||
                    pastHigh-bars[1].close>=InpMinRoomToLevelATR*atr);
      bool roomSell=(pastLow>=bars[1].close ||
                     bars[1].close-pastLow>=InpMinRoomToLevelATR*atr);
      int buyExtras=(adxBuy?1:0)+(bodyStrong?1:0)+(bosBuy?1:0);
      int sellExtras=(adxSell?1:0)+(bodyStrong?1:0)+(bosSell?1:0);
      if(InpLogDecisions)
         PrintFormat("ADV signal: RSI %.1f ADX %.1f +DI %.1f -DI %.1f candle=%s BOSbuy=%s BOSsell=%s extras B/S=%d/%d",
                     rsi,adx,plusDI,minusDI,bodyStrong?"Y":"N",bosBuy?"Y":"N",
                     bosSell?"Y":"N",buyExtras,sellExtras);
      buy=buy && buyExtras>=InpRequiredAdvancedExtras &&
          (!InpCheckSRRoom || roomBuy);
      sell=sell && sellExtras>=InpRequiredAdvancedExtras &&
           (!InpCheckSRRoom || roomSell);
   }
   if(buy) direction=1;
   if(sell) direction=-1;
   return true;
}

void TryEnter(int direction,double atr)
{
   MqlTick q;
   if(!SymbolInfoTick(_Symbol,q)||q.ask<=q.bid) return;
   double spread=q.ask-q.bid;
   if(spread>InpMaxSpreadATR*atr) return;
   bool buy=(direction==1);
   double entry=buy?q.ask:q.bid;
   double stopDistance=MathMax(InpStopATR*atr,spread+3.0*TickSize());
   double minimum=(SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)+3.0)*_Point;
   double stop=SnapPrice(buy?MathMin(entry-stopDistance,q.bid-minimum)
                            :MathMax(entry+stopDistance,q.ask+minimum));
   double riskDistance=MathAbs(entry-stop);
   if(riskDistance<=0) return;
   double tp=SnapPrice(buy?entry+InpTargetR*riskDistance
                          :entry-InpTargetR*riskDistance);
   double minLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   double maxLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   if(minLot<=0||step<=0||maxLot<=0) return;
   ENUM_ORDER_TYPE type=buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
   double atMinProfit=0;
   if(!OrderCalcProfit(type,_Symbol,minLot,entry,stop,atMinProfit)) return;
   double riskAtMin=-atMinProfit + minLot*InpRoundTripFeePerLot;
   if(riskAtMin<=0) return;
   double budget=AccountInfoDouble(ACCOUNT_EQUITY)*InpRiskPct/100.0;
   if(riskAtMin>budget)
   {
      PrintFormat("SKIP: min volume %.3f risks %.2f, exceeds risk budget %.2f",
                  minLot,riskAtMin,budget);
      return;
   }
   double rawLots=budget/riskAtMin*minLot;
   double volume=MathFloor(rawLots/step+1e-9)*step;
   volume=MathMin(volume,maxLot);
   volume=NormalizeDouble(volume,8);
   if(volume<minLot) return;
   double theoreticalProfit=0;
   if(!OrderCalcProfit(type,_Symbol,volume,entry,stop,theoreticalProfit)) return;
   if(-theoreticalProfit+volume*InpRoundTripFeePerLot > budget+0.0001) return;
   double margin=0;
   if(!OrderCalcMargin(type,_Symbol,volume,entry,margin)) return;
   if(margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE)*InpMaxMarginPctFree/100.0)
   {
      Print("SKIP: margin would exceed maximum allowed free margin usage.");
      return;
   }
   PrintFormat("CANDIDATE %s %s lots=%.3f entry=%.*f SL=%.*f TP=%.*f",
               _Symbol,buy?"BUY":"SELL",volume,_Digits,entry,_Digits,stop,_Digits,tp);
   if(!InpEnableDemoOrders) return;
   if(!DemoEnvironment())
   {
      Print("LIVE/CONTEST ACCOUNT BLOCKED. DEMO only.");
      return;
   }
   bool sent=buy?trade.Buy(volume,_Symbol,0.0,stop,tp,"MGS v0.3")
                :trade.Sell(volume,_Symbol,0.0,stop,tp,"MGS v0.3");
   if(!sent || trade.ResultRetcode()!=TRADE_RETCODE_DONE)
   {
      Print("Order not filled: ",trade.ResultRetcodeDescription());
      return;
   }
   if(PositionSelect(_Symbol) && (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic)
   {
      // Use actual fill price, and preserve the original stop distance across restarts.
      double realEntry=PositionGetDouble(POSITION_PRICE_OPEN);
      string key=InitialRiskKey();
      GlobalVariableSet(key,MathAbs(realEntry-PositionGetDouble(POSITION_SL)));
   }
}

int OnInit()
{
   if((int)InpMode<0||(int)InpMode>2||
      InpRiskPct<=0||InpRiskPct>1||InpDayLossPct<=0||InpDayLossPct>5||
      InpStopATR<=0||InpTargetR<=0||InpTrailATR<=0||InpMaxSpreadATR<=0||
      InpSession1Start<0||InpSession1Start>23||InpSession1End<0||InpSession1End>24||
      InpSession2Start<0||InpSession2Start>23||InpSession2End<0||InpSession2End>24||
      InpMaxTradesPerDay<=0||InpMaxTradesPerDay>500||InpRoundTripFeePerLot<0||
      InpMinModifySeconds<0||InpMinModifyTicks<0||InpMinSecondsBetweenEntries<0||
      InpMaxConsecutiveLosses<1||InpMaxMarginPctFree<=0||InpMaxMarginPctFree>80||
      InpStructureLookback<4||InpStructureLookback>200||
      InpRequiredAdvancedExtras<1||InpRequiredAdvancedExtras>3||
      InpRSIUpperLimit<=InpRSIBuyAbove||InpRSILowerLimit>=InpRSISellBelow||
      InpMinCandleBodyFraction<0||InpMinCandleBodyFraction>1||
      InpMinRoomToLevelATR<0||InpMinImpulseRangeATR<0)

      return INIT_PARAMETERS_INCORRECT;
   if(_Symbol!=InpExpectedSymbol)
   {
      Print("SAFETY STOP: symbol mismatch. Expected ",InpExpectedSymbol," but chart is ",_Symbol);
      return INIT_FAILED;
   }
   if(InpEnableDemoOrders && !DemoEnvironment())
   {
      Print("SAFETY STOP: this prototype can execute only in demo accounts.");
      return INIT_FAILED;
   }
   hEma9=iMA(_Symbol,PERIOD_M1,9,0,MODE_EMA,PRICE_CLOSE);
   hEma21=iMA(_Symbol,PERIOD_M1,21,0,MODE_EMA,PRICE_CLOSE);
   hEma20M5=iMA(_Symbol,PERIOD_M5,20,0,MODE_EMA,PRICE_CLOSE);
   hEma50M5=iMA(_Symbol,PERIOD_M5,50,0,MODE_EMA,PRICE_CLOSE);
   hRsi=iRSI(_Symbol,PERIOD_M1,14,PRICE_CLOSE);
   hAtr=iATR(_Symbol,PERIOD_M1,14);
   hAdxM5=iADX(_Symbol,PERIOD_M5,14);
   if(hEma9==INVALID_HANDLE||hEma21==INVALID_HANDLE||hEma20M5==INVALID_HANDLE||
      hEma50M5==INVALID_HANDLE||hRsi==INVALID_HANDLE||hAtr==INVALID_HANDLE||
      hAdxM5==INVALID_HANDLE)
      return INIT_FAILED;
   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.SetAsyncMode(false);
   ResetDailyKeys();
   if(InpManualBlackoutStart<=0 || InpManualBlackoutEnd<=InpManualBlackoutStart)
      Print("WARNING: NO high-impact economic release exclusion is active. This is not a news-safe EA.");
   Print("MGS v0.3 initialized on ",_Symbol,". DEMO orders enabled=",InpEnableDemoOrders,
         ", mode=",(int)InpMode,", sessions=",InpUseSessions,
         ". Times are BROKER SERVER TIME. NO automatic macro news filter.");
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(hEma9!=INVALID_HANDLE) IndicatorRelease(hEma9);
   if(hEma21!=INVALID_HANDLE) IndicatorRelease(hEma21);
   if(hEma20M5!=INVALID_HANDLE) IndicatorRelease(hEma20M5);
   if(hEma50M5!=INVALID_HANDLE) IndicatorRelease(hEma50M5);
   if(hRsi!=INVALID_HANDLE) IndicatorRelease(hRsi);
   if(hAtr!=INVALID_HANDLE) IndicatorRelease(hAtr);
   if(hAdxM5!=INVALID_HANDLE) IndicatorRelease(hAdxM5);
}

void OnTick()
{
   bool halted=IsHalted();
   ManageOwnedPosition(halted); // continue to enforce protections even outside session
   datetime bar=iTime(_Symbol,PERIOD_M1,0);
   if(bar==0||bar==lastBar) return;
   lastBar=bar;
   if(halted||!SessionPermitsTrading()||InManualBlackout()||
      HasAnySymbolPosition()||TradesToday()>=InpMaxTradesPerDay||
      !CooldownElapsed()||RecentLossStreak()>=InpMaxConsecutiveLosses) return;
   int direction=0;
   double atr=0;
   if(!Signal(direction,atr)||direction==0) return;
   TryEnter(direction,atr);
}
