# Marv Gold Scalper V0.3 | Beginner setup and experimental protocol

## Status and safety

**This MQL5 source is an experimental, UNCOMPILED prototype.** It extends the V0.2 source used in earlier MT5 Strategy Tester runs. It has not been compiled on your Windows computer, run against FxPro's historical data, independently validated, or shown to be profitable. Never connect it to a funded account. Live-account execution is deliberately blocked in code and the default order setting is OFF.

MT5 Android / iOS cannot compile or run an EA. MT5 Desktop and the Strategy Tester are required. A Windows PC or compatible hosted MT5 environment can operate an EA; the phone can monitor the same demo account.

**Important:** your FxPro demo password appeared in an earlier screenshot. Change it before any forward demo testing. Do not include passwords in screenshots.

## What changed from V0.2

Modes are switchable and **must be tested separately**:

| InpMode | Entry requirements | Research purpose |
|---|---|---|
| 0, MGS_EMA_BASELINE | V0.2-style EMA9/21 M1 pullback/re-entry | Baseline ENTRY CONDITIONS. V0.3 execution/risk behavior has changed, so P/L will NOT necessarily match earlier V0.2 runs. |
| 1, MGS_EMA_RSI_M5 | Mode 0 plus M1 RSI14 and M5 EMA20/50 direction | Does simple confirmation help? |
| 2, MGS_ADVANCED | Mode 1 plus at least 2 of 3: M5 ADX/DI directional strength, M1 strong candle, close past earlier N-bar high/low (a simple BOS proxy). Can exclude trades too near prior range boundaries. | More selective multi-confirmation model. Not AI/ML. |

**None of these indicators, thresholds or structure definitions is proven profitable.** The BOS proxy is a break of an earlier completed-candle range, *not* a full implementation of smart money concepts or change-of-character analysis.

Other additions:
* Two configurable trade windows in **FxPro BROKER SERVER TIME** (`InpUseSessions=true`). Defaults: 07:00-11:00 and 13:00-17:00 **server time**, not verified as UK hours. Check server-vs-UK offset including daylight-saving rules.
* Market spread must be less than a configured fraction of M1 ATR, with broker stops/freeze constraints.
* Risk-based volume uses `OrderCalcProfit`, checks minimum lot and free margin, allows only one symbol position, and attaches an initial protective stop.
* `InpRiskPct=0.25`, `InpDayLossPct=1.5`; loss-streak block and 2-minute cooldown. Limit 60 trades/day is a research safety ceiling, **not a target**.
* Breakeven adjustment **estimates** commission costs and adds a tick buffer; not guaranteed breakeven after slippage. ATR trailing tightens stops only. Requests throttled to minimum 15 seconds and 20 price ticks, configurable.
* Manual blackout window available via `InpManualBlackoutStart` and `InpManualBlackoutEnd`. **No automatic news calendar**, no geopolitical analysis, no Forquity/CFBI integration, and no AI predictive model in this version. Do not run unattended across important news releases without a properly tested news safeguard.
* Stops and daily loss limits can still be exceeded due to slippage, gaps, and broker execution. All operations are on demo only.

## Install on your Windows MT5

1. Save your existing compiled and source V0.2 files, do not overwrite them.
2. In MT5: **File > Open Data Folder > MQL5 > Experts**.
3. Copy `MarvGoldScalper_V03.mq5` into `Experts`.
4. Press **F4** to open MetaEditor. In Navigator open the V0.3 `.mq5` file and press **F7** to compile.
5. **If there are any errors, stop**. Copy the compilation errors, with line numbers, into ChatGPT. Do not enable Algo Trading.
6. If compilation succeeds, use **Ctrl+R > Strategy Tester**, select `MarvGoldScalper_V03`, Symbol `GOLD`, Period `M1`, model **Every tick based on real ticks**, a funded-simulation capital balance, Optimization disabled.
7. Run **inside the Strategy Tester** with `InpEnableDemoOrders=true`. Do not turn it on for a normal demo chart until the source has been reviewed and risk guards verified.
8. Save Tester Backtest, Graph, and Journal screenshots or report. Compare three modes **with identical data, dates, risk, execution assumptions, and windows**.

## Suggested scientific comparison

* First rerun the old 12-15 October 2026 period for smoke tests. This is a *development period*, not independent validation.
* Then acquire sufficient verified real-tick GOLD history. Your earlier log showed the tick data available to that terminal *began* 12 October 2026. More data must be downloaded or obtained before claiming a 2025-26 real-tick backtest.
* Compare Modes 0, 1, 2 with sessions OFF for clean entry-filter comparison, then separately test each session filter.
* Use multiple months and market regimes, reserve untouched dates for out-of-sample validation, and run worse-than-observed spread/slippage sensitivity tests.
* Collect net P/L, number of trades, win/loss size, profit factor, max **equity** drawdown, expectancy net of costs, session breakdown, rejected orders, and stop-execution errors. Inspect individual deals and commissions in MT5 reports.
* Do not cherry-pick parameters with the largest 4-day profit. A one-week demo is an execution smoke test, not evidence of a statistical edge.
* Choose future changes via one-at-a-time ablation tests. More filters can reduce profits or cause zero trades.

## Requested next iteration, only after initial validation

Research independently: a second strategy engine for **liquidity sweep and range rejection** with explicit closed-bar definitions, a *separate* momentum breakout engine, a verified economics-calendar-based news filter, dynamic market regime classification, and a Python-only offline machine learning experiment. These must be comparable separately. Never use AI-model confidence to override the trading risk layer.

## Notes

This release is not true sub-second high-frequency trading: it checks possible *entries on each completed M1 candle*, manages existing positions on ticks. Trying 20 trades in 20 seconds is a different execution technology and economics problem.

Read official MQL5 docs for `iADX`, `OrderCalcProfit`, `CopyRates` and `CTrade.PositionModify` before changing code. Broker symbol specification is authoritative for lot, point, commission and stop levels.
