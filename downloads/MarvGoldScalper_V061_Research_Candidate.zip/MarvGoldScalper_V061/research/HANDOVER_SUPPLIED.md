# CODEX HANDOVER: MarvGoldScalper, full project history and test evidence

**Prepared:** 25 October 2026  
**Project:** Research and development of a retail MetaTrader 5 Expert Advisor (EA) for gold (`GOLD`, the FxPro name for spot Gold vs USD).  
**Current code version:** `MarvGoldScalper_V06.mq5`, 1,004 source lines.  
**Status:** Experimental, demo-only. Not validated for funded accounts. No version has demonstrated robust positive expectancy out of sample.

> **For Codex:** Read this handover, then inspect the six included `.mq5` files, with particular attention to the V04, V05 and V06 code. Read `evidence/BACKTEST_RUNS.csv` and `evidence/SELECTED_JOURNAL_EXTRACTS.txt`. Distinguish a delivered or compiled EA from a backtested EA. Do not manufacture tests, infer results for untested modes, or declare the algorithm profitable. The priority is correctness, repeatability and realistic risk, not more indicators or higher trading frequency.

## 1. Intent and project decisions

- The user previously lost money trading gold/forex and wants a possible additional income stream. They are interested in automated short-term scalping, capturing occasional small profits while allowing strong winners to run with an improving stop-loss.
- The user's wife, Mary, is a developer with C# and Python experience. MQL5 on Windows desktop MT5 was ultimately chosen because the user already has FxPro and Moneta Markets accounts, and the source can be compiled and backtested with MT5 Strategy Tester. A phone can monitor MT5 but **cannot independently host an MQL5 EA**.
- Research ideas: M1 momentum pullbacks, M5 confirmation, EMA9/21, EMA20/50, RSI14, ADX, simple prior-bar structure breakouts, intraday range breakout, 10-second synthetic-candle momentum with EMA5/20/40 and Parabolic SAR, Fibonacci 38.2–61.8% retracements, three-candle FVGs, optional basic Order Block overlap, money-denominated profit locking and adaptive trailing exits.
- The user at one stage wanted 24-hour monitoring, unrestricted trading frequency, several 0.01-lot simultaneous trades, holding losing trades until reversal, recovery trades and even a daily 10% loss budget. These are **ideas discussed, not requirements to implement**. We repeatedly rejected automatic loss averaging/martingale and arbitrary high daily drawdown. Trading opportunities should be gated by quality and aggregate risk, not manufactured to reach a trade count.
- Earlier desired live capital: £100; later revised to possible **£500 or £1,000**. Latest discussed risk is **£15 maximum planned initial loss per trade, constrained independently to 1.5% of account equity**. Thus £500 permits at most £7.50 planned risk initially and £1,000 permits at most £15, subject to daily floor, free margin, stop distance, commission and execution checks. This is a cap, not a fixed order stake; realised loss can exceed it.
- `0.01` is a **maximum lot** in V04–V06, not a forced lot. The broker minimum lot can make trades impossible at the intended risk; the EA must **skip** those trades. No code should weaken protections merely to force orders.
- **No real account execution:** user requested an EA to experiment with, not a profitable strategy already validated. V01–V06 deliberately have demo-only gates.

## 2. Platform and symbol discoveries

1. Installed FxPro MetaTrader 5 desktop, MetaEditor and a demo account (MT5 hedge mode). Initially a stale/wrong `VantageInternational-Live` login produced invalid-account/black-chart confusion. Correct FxPro demo server/login resolved it.
2. The regular FxPro gold symbol was **`GOLD`**, not literally `XAUUSD`. User found it using Market Watch and confirmed `SPOT Gold Ounce vs US Dollar`.
3. Screenshot of FxPro symbol specs: contract size **100 ounces per 1.00 lot**; tick size **0.01 USD**; tick value **1 USD per tick at 1.00 lot**; minimum volume **0.01 lots**; step **0.01 lots**; floating spread; broker-defined stop/freeze requirements; listed commission **3.5 USD per lot** under in/out deal conditions. Check exact cost/side convention rather than assuming.
4. Screenshot demo leverage **1:100**. Do **not** assume this reflects permitted UK retail leverage or the eventual live account legal entity, commission and margin conditions. In the tester, deposit currency was frequently **USD**; `InpRiskCash=15` means $15 there, not £15.
5. Earlier V03 source compilation showed a non-fatal MQL5 Market version-number warning for `#property version "0.30"`. It was changed to `"1.030"`, resulting in **0 errors and 0 warnings** in the user's MetaEditor screenshot. Successful compilation does not prove runtime correctness.
6. User installed and selected the later V04, V05 and V06 in the MT5 UI. In the **latest V06 Strategy Tester screenshots**, V06 is selected with mode `MGS_EMA_PSAR_10S`, but `InpEnableDemoOrders=false`, tester timeframe `M5`, deposit `1,000 USD`, leverage `1:100`, zero execution delay, and a March–October 2026 date range. **No V06 performance report has been supplied.** The chart visible above Tester in these screenshots is not proof V06 traded.

## 3. Source-code version history

| Version | What was built | Status / main lesson |
|---|---|---|
| **V01** | First MQL5 M1 EMA9/21 momentum pullback prototype, RSI14/M5 EMA20/50 confirmation, ATR stop, 1.8R target, 1R BE, 1.5R ATR trailing, 0.25% risk, 1.5% daily loss, at most 8 trades/day. | Source delivered only. No confirmed V01 backtest. |
| **V02** | Beginner-configurable EMA-only baseline with optional RSI and optional M5 trend filter; max 8 trades/day initially, later manually raised to 20; 0.25% risk. | Compiled and tested. Early apparent gains used **much larger lot sizes than later V04** (e.g. 0.08 lots in the journal), and `InpRoundTripFeePerLot=0` estimate. Results cannot be compared directly with 0.01-lot V04. |
| **V03** | Separate `InpMode`: 0 EMA baseline, 1 EMA+RSI+M5, 2 Advanced (ADX/DI, candle impulse, simple range-break proxy, optional space-to-resistance); added session, spread/ATR, cooldown and improved trailing request throttles; risk 0.25%, daily 1.5%, max 60/day. | Compiled and tested for all three modes on same four days. Results mixed: one positive mode, two negative. |
| **V04** | Added fourth `MGS_RANGE_BREAKOUT` mode; capped lots at 0.01, kept % risk; disabled fixed TP by default; daily 0.5%-activation profit peak lock with 70% retention; daily 1.5% loss floor; optional 24-hour scanning subject to market/rollover filters; up to 200/day safety ceiling and 120s entry cooldown. | **£100 test placed zero orders, appropriately.** Three modes tested with $10,000 simulation, all lost money. Breakout mode not evidenced as tested. |
| **V05** | V04 entry modes retained; new exit enum: 0 legacy R/ATR, 1 fixed estimated net-cash market exit, 2 money-based stop locking, 3 hybrid cash plus ATR/R; optional forced time exit after 30/60/120/180 seconds. Default `InpExitMode=3`, default holding ceiling 120s; cap 0.01, risk 0.25%. | Code delivered and user installed/selected it; **no verified completed V05 backtest** in supplied material. |
| **V06** | Extends V05; adds 4 EMA/PSAR + synthetic 10s momentum, 5 Fib/EMA pullback, 6 FVG/OB proxy. Preserves modes 0–3 and V05 exit modes; `InpRiskCash=15`, `InpRiskPct=1.5`, `InpMaxLots=0.01`, daily loss=3%, free-margin cap 35%, 100 entries/day emergency ceiling, optional 07–11 and 13–17 broker-server sessions ON by default; default `InpMaxHoldingSeconds=0`. | Source delivered and selected in UI. **Not evidenced as tested.** Detailed source audit identified execution and market-structure weaknesses. |

### Version naming traps

- The original conversation sometimes used informal labels “option A / C”. The early `CFBI` composite fundamental bias concept (macro, DXY, interest rates, yields, NFP/CPI, 24h/7d/30d weighting) **was discussed but never coded as a verified predictive engine**.
- **V03 mode 2** (Advanced) is not **V04 mode 2** plus identical execution: execution, costs, sizing and protections changed. Identical mode labels do not mean cross-version P&L is directly comparable.
- V06 **10-second** refers to its entry-signal aggregation, **not** automatic closure after 10 seconds. With `InpMaxHoldingSeconds=0`, the position has no time-based forced exit.
- “One trade per second”, “AI robot”, “Fibonacci always wins” and “80–90% win rate” were ideas/vendor claims, not features or validated results.

## 4. Verified/reported MT5 backtest history: 12–15 October 2026

The terminal reports use `GOLD,M1 (FxPro-MT5 Demo)` with tester interval `2026.10.12 00:00` to `2026.10.16 00:00` (end exclusive). The journal explicitly states `GOLD : real ticks begin from 2026.10.12 00:00:00`. Most runs used $10,000 USD and demo leverage 1:100; **not real or forward earnings**. Profitability has been assessed on only four historical trading days that were repeatedly reused during development, so these are in-sample.

| EA | Exact mode / variant | Deposit | Trades | Net P&L | Win % | Profit factor | Additional notes |
|---|---|---:|---:|---:|---:|---:|---|
| V02 | EMA-only, **8** max entries/day | $10,000 | **32** | **+$143.02** | **40.62%** | **1.46** | Terminal journal confirms fee input `0.0`; screenshot supports win rate/PF. |
| V02 | EMA-only, **20** max entries/day | $10,000 | **80** | **+$237.82** | Not established | Not established | Journal confirms 80 entry candidates and final balance $10,237.82. |
| V03 | Mode **0**, EMA baseline | $10,000 | **126** | **+$156.25** | **53.17%** | **1.11** | Among V03 modes this was most positive net. |
| V03 | Mode **1**, EMA + RSI + M5 | $10,000 | **98** | **−$325.76** | **41.84%** | **0.74** | Confirmation reduced entries but greatly worsened outcome. |
| V03 | Mode **2**, Advanced | $10,000 | **77** | **−$60.00** | **45.45%** | **0.93** | More selective but still negative. |
| V04 | Mode **0**, £100-style viability test **in USD** | **$100** | **0** | **$0.00** | N/A | N/A | Safety: 0.01 minimum lot exceeded $0.25 per-trade risk. |
| V04 | Mode **0**, EMA baseline | $10,000 | **324** | **−$103.63** | **44.14%** | **0.79** | Max equity drawdown **1.26%**. |
| V04 | Mode **1**, EMA + RSI + M5 | $10,000 | **178** | **−$60.71** | **41.01%** | **0.79** | Max equity drawdown **0.76%**. |
| V04 | Mode **2**, Advanced | $10,000 | **127** | **−$47.85** | **42.52%** | **0.77** | Max equity drawdown **0.76%**. |
| V04 | Mode **3**, range breakout | — | — | **NOT TESTED** | — | — | Implementation exists; no conclusive tester output. |
| V05 | Entry/exit experiments | — | — | **NOT TESTED** | — | — | Source/inputs seen, but no completed outcome. |
| V06 | Modes 4, 5, 6 and inherited controls | — | — | **NOT TESTED** | — | — | Selected/configured only, no completed tester results. |

**Evidence basis:** Screenshots in the conversation supplied MT5 Overview statistics for trades, win rate, profit factor and equity drawdown; original UTF-16 MT5 journals `20261020(4).log` and `20261021(3).log` verify source versions, settings and ending balances. Selected, account-redacted journal extracts are included in the handoff. The V02 80-trade figure was reconstructed by counting journal `CANDIDATE GOLD` entries rather than a separately provided Overview table; treat it as such, not independently reconciled fills.

**Do not conclude V02 or V03 is profitable from these four days.** The early positive figures are especially not an apples-to-apples comparison: V02 risk-based lots included sizes greater than the later V04 0.01 maximum, with different fee and stop/exit arrangements. V03 used a cost estimate (`InpRoundTripFeePerLot=7.0`) absent in V02; a fee estimate for sizing is **not necessarily an additional commission posted to the tester P&L**. Reconcile actual deal commissions in MT5 History.

### Deeper V04 analysis (same dates, 0.01 lots)

- V04 baseline: **143 winning / 181 losing** trades; avg winner **$2.65**, avg loser **−$2.59**.
- V04 EMA+RSI+M5: **73 winning / 105 losing**; avg winner **$3.08**, avg loser **−$2.65**.
- V04 Advanced: **54 winning / 73 losing**; avg winner **$2.94**, avg loser **−$2.76**.
- RSI mode cut frequency from 324 to 178 (**−45%**); net loss fell in absolute dollars but **profit factor remained 0.79**, so reduced losses largely reflected reduced exposure, not a better per-trade edge.
- Advanced mode cut frequency further to 127; absolute loss fell to −$47.85 but **profit factor slipped to 0.77**. It did not create a positive expectancy.
- From a prior exported-trade reconstruction reported during discussion, 163/178 V04 RSI-filter trades had matching entry times/outcomes in the V04 baseline, 15 were newly timed (path dependence). Approximately 55% of V04 RSI positions showed no stop-loss modification before exit. Treat these reconstruction statistics as **secondary analysis requiring reproduction from raw deals**, not official tester Overview fields.
- From a prior reconstruction of the 127 Advanced trades, median holding time was ~7 minutes and mean ~8m32s; 7 trades closed within 60s, all losing; median winning hold ~10m and median losing hold ~4m. This describes **existing exit logic** and does **not** disprove a redesigned short-duration strategy. Counterfactual 30/60-second exits require exact timestamped bid/ask tick replay.
- Four-day breakdown of V04 RSI mode was previously **estimated** as Mon −$26.30, Tue −$2.61, Wed +$0.01, Thu −$31.81. This is an allocated-cost reconstruction, not an official daily broker statement. Reproduce or exclude before making conclusions.
- From the screenshots, V04 repeatedly showed strategy balance curves with intraday rallies followed by reversal and negative final P&L; many tiny gains and stop-loss exits. This motivated testing alternative exits in V05 but did **not** establish the source of edge failure.

## 5. Broker minimum-lot / small-account failure, observed not hypothetical

An actual V04 tester run on **$100 USD** with `InpRiskPct=0.25`, max 0.01 lots and day-loss 1.5% took **zero trades**. The original Journal contains many samples such as:

```
NO TRADE: min lot 0.010 risk 3.250 USD > allowed 0.250; equity 100.00
NO TRADE: min lot 0.010 risk 2.090 USD > allowed 0.250; equity 100.00
NO TRADE: min lot 0.010 risk 3.540 USD > allowed 0.250; equity 100.00
```

**This is a correct protective rejection, not a bug to “fix” by forcing an order.** With GOLD 100 oz/lot, 0.01 lot is approximately one ounce of gold exposure. Minimum lot, spread, structural stop and commission make ultra-small monetary risk infeasible on small balances. Account currency and margin must also be checked. V06 therefore tests potential £500/£1,000 account sizes with `MIN(15 account currency, 1.5% equity, remaining daily room)` and the same 0.01 lot ceiling. In USD backtests, the 15 means **$15**, not £15.

## 6. Failed setup, workflow and configuration issues encountered

1. **MT5 connection:** initially wrong/stale login, wrong broker server, apparently black charts; corrected login to FxPro MT5 Demo. Do not bundle/share historical password; it was accidentally exposed in a screenshot. Advise rotating it.
2. **Symbol mismatch:** search for `XAUUSD` failed because FxPro chart uses `GOLD`; source must not hard-code `XAUUSD` blindly. Check exact broker symbol and any suffix on Moneta.
3. **MetaEditor compiler warning:** early V03 `#property version "0.30"` incompatible with MQL5 Market format; changed to `"1.030"`; screenshot then showed 0 errors/0 warnings.
4. **EA not appearing in MT5:** code copied/compiled but Navigator needed refreshing and correct Experts data folder; user subsequently saw V04, V05 and V06 in EA list and Strategy Tester. Do not confuse a chart title overlay from V04 with the EA currently selected in Strategy Tester.
5. **Tester mode vs live chart:** `InpEnableDemoOrders=false` intentionally means signals only. It must be **true** to place test orders and stay on a demo account; the guard must not be removed. V06 latest screenshots still show false.
6. **Data availability:** journal says real tick history began 12 October for the initial tests even while bar history reached earlier years. The tester's 100% History Quality is not execution fidelity proof. A long date range in Settings does not mean a long completed real-tick test exists.
7. **Entry-count confusion:** user understandably considered 8 trades/day too few; V02 switched to 20, V03 safety max 60, V04 200/120s cooldown, V06 100/45s cooldown. These are ceilings and throttles, **not target quotas**; extra trades without edge can magnify losses/costs.
8. **Risk misconception:** requested extremely tight trailing SL and £0.50 locks, but MQL5 broker minimum stop/freeze distance and Bid/Ask mechanics can forbid meaningful locking at those amounts. Stop execution is not guaranteed at the chosen price.
9. **Currency and leverage:** USD tester deposits vs target GBP live account; code's risk cash and fee estimates are in account currency. Demo 1:100 assumptions may not translate to the user's live FCA-regulated retail account.
10. **Backtest overfitting:** the same 12–15 October four-day interval was reused many times to react to losses. It is development data, **never an untouched validation set**. Some intermediate tests initially profitable and others lost, demonstrating regime and implementation sensitivity.

## 7. Known unresolved V06 design/implementation weaknesses from source review

**Treat these as issues to verify directly in the current code, write failing tests for, then fix. Do not assume they have already been repaired.**

### P0, reliability and execution

- **10-second synthetic candles are imperfect:** `UpdateSynthetic10s()` advances when a tick is observed, not necessarily on exact 10-second boundaries; inactive/sparse intervals may be missing. Potential dropped `OnTick` events mean it is not assured that every source tick is processed. Design consistent tick replay/candle aggregation, define empty-bucket treatment and prove no future-data leakage.
- **Order lifecycle:** no comprehensive `OrderCheck()` before submission, no robust `OnTradeTransaction()` reconciliation/partial-fill handler, and incomplete consideration of **pending orders** from other EAs when enforcing total one-position/aggregate exposure. Include return-code checks on open, modify, close and retry throttles.
- **Execution realism:** stop/freeze levels, spread, slippage, actual contract tick value and commissions can make low cash profit locks impossible. `InpRoundTripFeePerLot=7`, `InpSlipReserveTicks=10` are estimates; reconcile broker deals and actual fee currency rather than double counting or omitting costs.
- **Risk circuit breakers:** day-start equity is captured on EA start (potentially mid-day); manual positions, deposits and withdrawals can contaminate profit peak and daily floors. Loss-limit close can fail, be delayed or slip; no guarantee of 3% maximum realised loss.
- **News/event risk:** manual time blackout and last completed M1 spike detection only; no dependable automated economic-calendar feed for NFP, CPI, FOMC etc. The spike check is reactive, not anticipatory.

### P1, trading signal correctness

- **10s EMA/PSAR model:** M1/M5 EMA5/20/40 and PSAR are lagging; by the time they align alongside 10s candles, short move may be exhausted. No evidence that continuation after costs is positive. Synthetic 10s signals do **not** calculate Parabolic SAR on 10s candles.
- **Fibonacci:** `FibSignal()` uses recent M5 highest-high/lowest-low in a lookback (~48 bars), not necessarily a confirmed directional swing. Selection may be arbitrary in choppy markets; closed M1 candle may be inside the zone while current BUY Ask/SELL Bid already left it. Require confirmed pivots, ordered swing structure and marketable-price checks; benchmark against non-Fibonacci zones.
- **FVG/OB:** three closed M5 candles and current touch are merely price-pattern proxies. The gap may be stale, previously mitigated or invalidated; the reversal candle need not have formed *after* gap touch; bullish BUY detection uses Bid while order executes at Ask. Optional OB overlap is a rudimentary candle proxy and OFF by default, not institutional order flow.
- **Trade direction/reversals:** do not copy Telegram bots' automatic flip-to-opposite-position. Only reverse on independent fresh confirmation. No martingale, averaging-down, or hedged recovery baskets.
- **Session clock:** `07–11` and `13–17` are broker-server times, not automatically UK times; handle broker server timezone and EU/US DST transition weeks. Test 24/5 market-open scanning against London/NY windows without assuming either is best.
- **Default holding ceiling:** V06 `InpMaxHoldingSeconds=0`, meaning OFF; its 10-second engine does **not** exit automatically after seconds. Tiny net targets ($0.50/$1/$2) vs possible $10+ losses require very high break-even win rates, to be computed from realised net losses.

### P2, test and maintainability

- Separate pure signal computation from broker adapter, position-sizing policy, stop management and EA event callbacks. Build deterministic unit tests for volume rounding, FX conversion, sessions, stop monotonicity, clock gaps, rejected modifications and news fallback.
- Make every rejected entry explainable using structured reasons. Journal raw broker retcodes, order/deal/position IDs, signal timestamps (UTC), spread, latency, ATR, desired/actual stop, MFE/MAE, total costs and missed-tick flags.
- Store exact code SHA, `.set` inputs, broker symbol specs, deposit currency, margin assumptions and tick data range with each backtest result. Avoid inferring a result from an old chart overlay.

## 8. Third-party inspiration and Telegram research, **not validated bots**

### Social-media marketing / Wayne

- A TikTok seller offered a `Scalpin AI` gold bot for about $150, claiming ~89% wins and ~8% drawdown. Marketing screenshots showing $25k balance and numerous overlapping gold trades **do not establish audited profitability**. Vendor's true results and code not independently verified.
- Friend **Wayne** described an RSI + EMA scalping EA, said it was “83% profitable over a month”, charged ~£200 for script and £150 for an indicator. No complete verifiable live broker statement or implementation details provided. Treat 83% as an **unverified claim**, not a target.
- An approximately 39-minute TradeSimpleBot Telegram export had 298 messages, many error notifications (~236), 11 positive and 12 negative closing P/L notifications with sum **+$30.31 / −$36.96 = −$6.65**. This is *not proven to be Wayne's exact EA* and is not a full account ledger.
- Other Telegram channels (Elevating Forex Premium, Charting Society, FXTV) posted gold signal entries/targets; many initial targets had low reward versus SL size and winners were selectively publicised. Posted signal outcomes are not independently validated fills. Do not incorporate them as labelled profitable training data without reconstructing trades against tick prices.

### Examined external GitHub models, **not independently backtested**

1. `NadirAliOfficial/trillex-10s-ea`: a 10-second synthetic-candle/EMA/PSAR entry idea. Source defaults included aggressively large/compounding lot configurations; **do not copy its money management**. V06's experimental 10s hypothesis draws inspiration from this project, not proven performance.
2. `foeed/FvgGold-EA`: M5 FVG/OB, H1 EMA trend, session filters and trailing/breakeven. Published return claims could not be reconciled straightforwardly with example published 0.01-lot and $ stop distances; treat as unverified.
3. `RobertN1D/GOLD-EA-MT5-WITH-OPENAI`: API-driven AI/indicator EA with fallback behaviour. WebRequest/Strategy Tester restrictions mean its live API decision path is not automatically tested by standard MT5 replay; no AI trading logic was integrated into V06.
4. Commercial robots found on Etsy, MQL5, eBay, Fiverr and a Udemy course were investigated for ideas, **not bought or demonstrated profitable**. No evidence to prefer a purchased black-box EA over auditable source.

## 9. Statistical lessons already learned

- A high **win rate is not net profitability**. At £1 average net win and £15 average net loss, break-even win rate is 93.75%. At £2 vs £15 it is 88.24%. Scalp exits can generate many tiny wins yet lose overall.
- V04 RSI and Advanced filtered **more** trades but did not improve net expectancy: profit factors 0.79, 0.79, 0.77. This is a concrete warning against indiscriminately stacking indicators.
- Shorter trade duration is not automatically safer or profitable. We need per-tick **maximum favourable and adverse excursion** (MFE/MAE) and exit counterfactuals using same original entries. Changing exits in full EA simulation can change later entry opportunities through the one-position and cooldown constraints.
- A forward-looking 6–12 months of tick data is not the same as a single 6–12 month training segment. Use train/research, validation, untouched out-of-sample and forward-demo phases; account for multiple-testing and parameter search bias.
- Two FX/Gold backtests are not comparable when contract, lot sizes, account currency, fees, spreads, leverage, timeframe, sessions or exits differ. Always control these variables.
- `100% History Quality` ≠ live-fill fidelity. The earlier real ticks begin Oct 12 despite older historical bars.

## 10. Requested next actions for Codex, in priority order

**Phase A: technical integrity first, deliver `V06.1` not `V07` feature overload.**

1. Inspect `source/MarvGoldScalper_V06.mq5` and the V05/V04 diffs. Produce a checklist of behaviour against code, note every mismatch, identify broker/execution and mathematical hazards.
2. Compile in actual MetaEditor/MetaTrader 5 if available; if not, mark compilation **UNVERIFIED** rather than claiming success. Provide compile-ready isolated fixes and instructions for F7 on user PC.
3. Add deterministic tests for 10s tick/candle reconstruction, standard/fractional candle boundary, missing ticks and missed events; ensure all decision features use information available at decision time.
4. Fix trade request preflight, server return-code handling, position/order/deal reconciliation (including pending orders/partial fills), throttled retries, terminal restarts, SL rejection and monotonic stop rules.
5. Correct/recheck account-currency cash risk, cap 1.5% and £15, broker min lot/volume step, margin, fee/slippage reserve and daily equity stop. Preserve demo-only gate, one-position aggregate-risk policy and no martingale. Do not permit a £500/$500 account to “force” a 0.01 lot above approved risk.
6. Add structured trade/skip logs to CSV for offline analysis, plus a paper/demo mechanical test suite with forced bad spreads, stop-level rejection and disconnections.

**Phase B: research experiments, only when mechanically correct.**

7. Reproduce at least one **V04** test against the exact Oct 12–15 control using the archived V04 code before comparing a revised build. Record whether differences come from test settings, real ticks, costs or source changes.
8. Run modes separately: EMA baseline, EMA+RSI/M5, Advanced, range breakout, 10s EMA/PSAR, Fib/EMA and FVG/OB with common exit method and broker realistic risk/execution. Afterwards run independent exit ablations (legacy, fixed cash, cash-lock, hybrid, 30/60/120/180-second forced close). Do not tune all signals and exits at once.
9. Obtain and validate **6–12+ months** of genuine tick data spanning diverse regimes; report actual data coverage. Reserve later dates not used in development as holdout; **Oct 12–15 is already contaminated**. Use nonzero execution delay and worse-cost stress tests.
10. Measure net P&L, profit factor, net expectancy, confidence bounds, win/loss distribution, worst losing streak, max **equity** drawdown, return vs risk, trading frequency per session, latency/rejections, MFE/MAE, time-to-first-profit and robustness by date/regime. Compare across £500 and £1,000 GBP using **actual intended account terms**. If strategies are unprofitable, say so and diagnose before adding more indicators.
11. Only consider forward demo trading for a sustained period once a candidate meets precommitted out-of-sample criteria; never route code to funded accounts at this stage.

**Deliverables from Codex:**
- A concise code audit with severity, function/line references and reproducible defects.
- Minimal `MarvGoldScalper_V061.mq5` source changes, clean diff and plain-English explanation.
- Unit and strategy-test plan with clear pass/fail assertions.
- Ready-to-use MT5 `.set` files for each controlled test, with currency, dates, time zone, execution assumptions and version pinned.
- Repeatable trade/deal export format and Python evaluation script.
- Honest result table clearly labelling `not tested`, `compile failed`, `no trades`, `in-sample`, `out-of-sample`, and `forward demo`.

## 11. Files supplied in this handover bundle

- `CODEX_HANDOVER.md`: this report.
- `source/MarvGoldScalper_V01.mq5` to `source/MarvGoldScalper_V06.mq5`: original source as delivered, for review and controlled diffs. Do not overwrite versions.
- `reference_guides/`: version-specific README documents and V05/V06 test matrices from original ZIPs.
- `evidence/BACKTEST_RUNS.csv`: chronological run manifest with values, unknowns and labels.
- `evidence/SELECTED_JOURNAL_EXTRACTS.txt`: compact evidence transcribed from selected original FxPro terminal tester logs, without account credentials.
- `SOURCE_SHA256.txt`: checksums to pin the source versions; not evidence they are safe or profitable.

## 12. Non-negotiable conclusions

1. **No currently tested MarvGoldScalper variant has a validated durable edge.** Some four-day V02/V03 runs were positive, other V03/V04 runs negative.
2. **V05 and V06 have not provided confirmed performance backtests**, even though they were installed/configured in MT5.
3. **The 0.01 minimum GOLD position can be too risky for £100** even with a sound signal; skip is the correct outcome.
4. **£15 is a maximum planned risk amount, not a guaranteed worst loss or profit target**. Currency and overall equity caps take precedence.
5. **Do not add recovery grids or force multiple simultaneous positions.** One independent valid trade signal is not four independent trades.
6. **Fix correctness and execution controls before strategy sophistication.** There is no sound basis for advertising “80–90% profitability”, consistent daily income, or automatic wealth creation.

**Please begin by reading the V06 code, validating the above backtest manifest against source and evidence, and returning a prioritized, reproducible `V06.1` repair plan.**
