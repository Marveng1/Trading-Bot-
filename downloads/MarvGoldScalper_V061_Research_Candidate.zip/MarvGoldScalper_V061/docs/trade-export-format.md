# Closed-position export and evaluation

`tools/evaluate_trades.py` analyzes normalized CSV exports using Python 3. It
does not connect to MT5, place orders, invent transaction costs, replay ticks or
validate a strategy. Its unit tests use synthetic fixtures, not broker results.

## Trade CSV

Use UTF-8 comma-delimited CSV with a header. Every row must represent one fully
closed position, aggregating all related entry/exit deals and partial closes.
Raw MT5 deals or order exports must first be reconciled by position identifier;
they are not interchangeable with this format. A reversal on a netting account
needs allocation to economically separate position episodes before evaluation.
Evaluate one account currency, strategy and experiment per file.

| Column | Required meaning |
| --- | --- |
| `position_id` | Unique identifier for the closed position/episode; never one row per partial fill |
| `entry_time` | First entry timestamp in ISO 8601 with `Z` or an explicit UTC offset |
| `exit_time` | Final close timestamp, with timezone; must not precede entry |
| `side` | `BUY` or `SELL` |
| `volume` | Positive total opened lots; must reconcile to final closed volume |
| `gross_profit` | Realized deal profit before commission, swap and separate fees, in account currency |
| `commission` | Signed sum of entry and exit commissions; negative for expense, positive for rebate |
| `swap` | Signed swap total; zero only when verified as zero |
| `fee` | Signed separate fee total, excluding costs already recorded as commission |
| `initial_risk` | Optional positive initial planned cash risk, in account currency |

All required monetary fields must contain known finite numbers. Blank,
`unknown`, `NaN` and infinite values are errors. Missing costs never default to
zero. Keep `initial_risk` blank when unavailable; mean net R is withheld unless
every included position has a recorded initial risk. Additional columns are
permitted and ignored. Duplicate position IDs and duplicate headers are rejected.

Net position profit is `gross_profit + commission + swap + fee`. Do not subtract
spread again if it is already reflected in executable bid/ask fills. Allocate
separate account-level charges explicitly before comparison and document their
allocation; do not silently omit them. Preserve an untouched raw export beside
the normalized file and retain a reconciliation to its totals.

Example synthetic fixture only:

```csv
position_id,entry_time,exit_time,side,volume,gross_profit,commission,swap,fee,initial_risk
example-1,2026-01-05T08:00:00Z,2026-01-05T08:01:00Z,BUY,0.01,10,-1,0,-0.5,5
example-2,2026-01-05T14:00:00Z,2026-01-05T14:01:00Z,SELL,0.01,-4,-1,0,0,5
```

## Optional equity CSV

Provide independently recorded account equity, including floating P/L:

```csv
timestamp,equity
2026-01-05T07:59:00Z,1000
2026-01-05T08:00:01Z,990
2026-01-05T14:02:00Z,1003.5
```

At least two finite observations are required; timestamps must strictly
increase, initial equity must be positive, and observations must span the full
entry-to-final-exit range of the trade file. Drawdown is the maximum observed
peak-to-trough loss and fraction of the preceding equity peak. Cash maximum
and fractional maximum can arise at different times. Sparse samples can miss
intratrade losses: the reported value is observed sample drawdown, not proof of
the true maximum. Deposits/withdrawals are not adjusted; use a dedicated account
without external cash flows or an independently adjusted series and document it.
Closed-position P/L is never substituted for account equity.

## Run

```bash
python tools/evaluate_trades.py closed_positions.csv --currency GBP --phase in-sample --equity equity.csv --output report.json
python -m unittest discover -s tests -p 'test_evaluate_trades.py' -v
```

Omit `--equity` when unavailable; drawdown is then JSON `null`. Omit `--output`
to print JSON. CLI validation errors return exit code 2 and do not generate a
new report. A previous output file may remain after a failed invocation: verify
the command exit status and do not treat an older report as a new result.

`--phase` must be explicitly supplied as `in-sample`, `validation`,
`out-of-sample`, `forward-demo` or `unspecified`. This is a user-provided label,
not a claim that the evaluator has verified chronological separation. `--currency`
must name the actual account currency; the evaluator performs no FX conversion.

Outputs include count, wins/losses/breakeven, win rate as a fraction, average net
win, average net loss as a negative number, net expectancy per closed position,
and profit factor as total positive net position P/L divided by the absolute
negative net position P/L. Profit factor is `null` without losses, even when all
trades won. Zero-trade files are labeled `no_trades`; expectancy and win rate are
`null`, not a successful strategy result.

Frequency and outcome tables group positions by **entry** date and fixed UTC
buckets: 00:00–07:00, 07:00–12:00, 12:00–17:00 and 17:00–24:00, left inclusive.
They are research buckets, not DST-adjusted London/New York sessions. Their net
P/L includes each position's entire life, even when it exits in another bucket.
Dates without entries are not inferred, so the tool does not claim an average
trade rate over the full calendar study. These groupings are descriptive and
must not be optimized against an untouched holdout.

This first evaluator does not infer missing trades, correct broker errors,
calculate statistical confidence intervals, MFE/MAE, execution latency or
counterfactual exits. Those require additional raw events, tick data and
separately validated methods. Four reused October 2026 days remain development
data; labeling their CSV `out-of-sample` would not make them untouched.

## Read-only raw MT5 deal exporter

`tools/ExportMGSDeals.mq5` is a separate MT5 **script**, not an EA. It reads
account history and writes CSV; it contains no order-placement, modification or
closing calls. **It has not been compiled or run in MetaEditor/MT5 here.** Its
output is raw deals, not the normalized closed-position input above.

1. Copy the script to the terminal data folder's `MQL5/Scripts` directory.
2. Open it in MetaEditor and press F7. Check the full errors/warnings log before
   running it; a successful compilation is not a history-reconciliation test.
3. Run the script from Navigator on the intended FxPro demo terminal. It does
   not require enabling automated order execution.
4. Set `InpSymbol` to the exact symbol, default `GOLD`. `InpFilterMagic=true`
   and `InpMagicNumber=20261023` are the defaults; match the actual EA inputs.
   **Magic filtering can miss manual closes and related deals with other magic
   values.** Export with the filter false when reconciling complete position IDs.
5. `InpFrom=0` selects the earliest history available to the terminal;
   `InpTo=0` selects through `TimeCurrent()` at execution. Explicit dates use
   broker-server time and must satisfy from ≤ to. These defaults do not prove
   all account history has been downloaded or retained by the broker.
6. Choose a new `InpOutputFile` per run. Files are written as UTF-8 comma CSV
   beneath `MQL5/Files`, accessible through File → Open Data Folder. Existing
   files are preserved unless `InpOverwrite=true` is explicitly selected.
7. Check the Experts log for `EXPORT FINISHED`, row counts and errors. An empty
   file is not proof there were no trades. `EXPORT INCOMPLETE` or any failure
   requires investigation; do not analyze a partial export as complete history.

The exported columns are:

```text
deal_id,order_id,position_id,time_msc,broker_time,symbol,magic,type,entry,reason,volume,price,profit,commission,swap,fee,account_currency
```

Ticket IDs retain integer text. Enum fields use their MQL enum names. Monetary
values retain their reported sign; the script does not convert currencies or
estimate costs. Free-form text replaces commas, quotes, newlines and tabs to
preserve the delimiter structure. Account logins, passwords and credentials are
not exported.

`broker_time` and raw `time_msc` retain the broker/platform timestamp convention;
they are **not labeled or assumed to be UTC**. Determine the broker's historical
UTC offset and DST schedule, then convert each timestamp to explicit ISO 8601
UTC/offset form for normalization. Never attach `Z` without verifying the
offset. Retain raw timestamps so the conversion is auditable.

Group raw deals by `position_id`, reconcile entry/exit volume and direction,
and include all related commissions, swap and fees before producing a closed
position row. Keep partial/open positions out of the closed-position evaluator
and report their exposure separately. Symbol filtering can omit account-level
charges with an empty symbol; reconcile those from account statements and
document any allocation. Zero-date selection, history request success and a
successful file write establish neither full historical coverage nor complete
position episodes. This exporter does not generate an equity series.
