# Initial EA source review

Reviewed 25 October 2026. Target: FxPro, MetaTrader 5, GOLD/XAUUSD.
Broker legal entity, account currency, exact symbol specifications and history remain unconfirmed.

This is an initial shortlist, not an internet-wide ranking or evidence of profitability.
GitHub repositories were retrieved using the existing Git proxy. Direct GitHub API,
MetaQuotes documentation and Google documentation requests received proxy 403 responses.
No third-party code was executed, compiled or incorporated into this project.

## Sources actually inspected

| Project | Pinned commit | Useful material | Decision |
| --- | --- | --- | --- |
| [EA31337](https://github.com/EA31337/EA31337) | `9b9bd38c4e49dd6916f4fe3936e50e97fca7a692` | MT4/MT5 framework, strategy separation, checked-in test/backtest infrastructure; README says defaults are optimized for EURUSD | Architecture reference; not a gold performance recommendation |
| [EA31337 classes](https://github.com/EA31337/EA31337-classes) | `a723dd7768f4b1cfb97b2be2216d1aa951565bda` | Account, trade, indicator and test abstractions | Engineering reference; broad dependency surface; GPLv3 licensing requires review before reuse/distribution |
| [TRILLEX 10S](https://github.com/NadirAliOfficial/trillex-10s-ea) | `006b39d7ce9a8c278d79ea71c0f5d4877660f226` | Synthetic bars and EMA/PSAR signals | Signal hypothesis only; reject defaults for this small-account research project |
| [FvgGold](https://github.com/foeed/FvgGold-EA) | `4fa57db95d8af5bbcf52849b8e2128776febe562` | Explicit gap rules, scoring and limit-order entries | Pattern hypothesis only; repair/test risk handling before considering reuse |

EA31337 findings above concern documentation and the presence of infrastructure, not a complete code audit or successful execution. The two smaller EAs received targeted source inspection. Neither supplied independently validated broker-specific performance in this review.

## Source findings

Line numbers below refer only to these pinned commits.

### TRILLEX

- `TRILLEX_10S_BASIC.mq5:47–54`: dynamic lots default on, base lot 1.0 per balance tier, multiplier 10.0, and total-lot upper bound 10,000. Lot allocation is capital-tier based, not a stop-distance cash-risk budget. These defaults do not implement the proposed £7.50/£15 cap.
- `:121–142`: volume normalization clamps a request upward to minimum lot. Requests below minimum should instead be rejected when minimum-lot loss exceeds the risk budget.
- `:902–928`: session and spread checks return before synthetic-bar updates and signal-exit processing. A wide spread or session boundary suppresses those local exits; broker-side stops are a separate protection.
- `:669–672`: inspected native EMA/SAR reads use shift 1, a useful closed-bar convention. This does not establish causality throughout the EA.
- The MIT license permits reuse subject to its terms. The README's “Live-Ready” label is an author claim, not a finding of this review.

### FvgGold

- `FvgGold.mq5:150–154`: higher-timeframe EMA bias reads shift 0. This is a changing current-bar signal, not automatically lookahead, but it differs from a closed-H1 specification and must be reproduced tick by tick.
- `:597–658`: risk-based sizing uses balance and tick value; normalization then clamps below-minimum results upward. Final minimum-lot risk can exceed the requested percentage.
- `:847–865`: daily P/L sums historical profit, swap and commission. It excludes floating P/L and `DEAL_FEE`; the daily threshold therefore is not an account-equity loss floor.
- `:917–926`: hitting that threshold blocks new entry logic but does not itself flatten positions or cancel existing pending orders. A pending order can still become exposure.
- `:220–242` and `:712–714`: exposure counting is symbol-and-magic specific. It does not enforce one gold position across unrelated EAs or synchronize concurrent instances.
- README reports +48.7% over 64 trades using 0.01 lots and a fixed 1.5 reward/risk configuration. Treat this as an unverified author claim until raw reports, contract specifications, variable trade risks, costs and the equity curve reconcile. A README table is insufficient.
- MIT license; retain attribution if code is reused.

## Strategy candidates to compare

These are testable hypotheses, not strategies established to work on FxPro gold:

1. Closed-bar trend/pullback baseline with a fixed cash-risk budget and ATR-scaled stop.
2. Session opening-range or Donchian breakout with explicit spread and volatility gates.
3. Closed-bar FVG revisit with causal zone creation, expiry and invalidation.
4. Ten-second EMA/PSAR trigger as an experimental comparison, only after execution costs are measured.

Keep the original V06 modes separate. Start with one baseline and one challenger;
record every additional mode and parameter trial to account for selection bias.
Do not combine all signals simply because each has an appealing chart example.

## Research still blocked

- Updated after source upload: V02–V06 are now preserved under `research/originals/`; see `v061-audit.md`. V01 and raw historical reports/journals remain absent.
- No MT5/MetaEditor runtime or broker tick history is available on this machine.
- Broader web/API research needs the saved network-domain changes applied through environment settings.
- No candidate has been compiled, backtested or forward-tested here.
