# V06 source audit and V06.1 repair roadmap

Audit date: 25 October 2026. Target: FxPro MT5 demo, exact `GOLD` symbol.
Original inspected source: `research/originals/V06/MarvGoldScalper_V06.mq5`,
SHA-256 `9c33c2dd6886d8aee61ff2be80be5b95f9fc3e71eac0af3b71d657e3394a2074`.
All line references below refer to that original, not the revised V06.1 source.

## Scope and evidence limits

The uploaded V02, V03, V04, V05 and V06 source files were read, along with the
technical handover. Preserve these original files for controlled comparisons.
The upload does not contain V01, `evidence/BACKTEST_RUNS.csv`,
`evidence/SELECTED_JOURNAL_EXTRACTS.txt`, raw MT5 reports, deals or tick history.
The handover describes them, but those descriptions do not establish that the
underlying evidence is present or independently verified.

No MT5 compiler, tester or connected FxPro terminal is available here. Compilation,
broker execution, historical performance and forward demo results remain unverified.
The pure policy header can be exercised using a C++ harness, but that does not
compile the EA in MetaEditor or verify MQL5 event, broker and indicator behavior.

The revised source is a research repair candidate. The table below diagnoses
original V06; implemented repairs and unresolved items are listed separately
in `v061-install-and-test.md`. All broker-dependent repairs await MT5 validation. No profitable edge,
funded-account readiness or guaranteed loss ceiling is claimed. AI integration
is deferred while mechanics and deterministic baselines are established.

## Prioritized original-source findings

P0 means protective/exposure integrity; P1 means material execution or signal
correctness; P2 means dependencies, model clarity or research reproducibility.

| Priority | Original location | Reproducible finding and required response |
| --- | --- | --- |
| P0 | `HasAnySymbolPosition` 262–277; final entry guards 779, 833–836 | Guards inspect positions but not pending orders and do not atomically reserve exposure across instances. Two instances can pass the same pre-submit checks. Include pending exposure and coordinate allocation; same-terminal protection does not coordinate separate terminals. |
| P0 | `RefreshDay` 189–208; `Prefix` 166–170 | Day-start equity is first-attachment equity, not reconstructed midnight equity; state is keyed by magic/symbol, although the stated floor is account-wide. Changing identity can create another floor. Preserve state and document dedicated-account/restart restrictions; cash flows and foreign trades need an explicit policy. |
| P0 | `TryEnter` 835–861 | Post-fill state is obtained with symbol selection rather than complete order/deal reconciliation. There is no `OnTradeTransaction` handler or comprehensive preflight; partial fills, pending/unknown outcomes and actual ownership require reconciliation before retry. |
| P1 | `ManagePositions` 445–456 | P/L estimation failure causes `continue` before the time-exit check. Enforce holding-time exit independently of fee/currency valuation. |
| P1 | `ManagePositions` 459–460 | ATR unavailability skips hybrid cash tracking/protection even though the cash component needs no ATR. Gate only the dependent R/ATR branch. |
| P1 | `ManagePositions` 478–514 | The tightest cash/BE/ATR candidate is checked for legality only after combination. An illegal tight stop suppresses a valid weaker improvement. Select the best legal candidate independently; do not report a weaker stop as achieving the desired cash lock. |
| P1 | `ManagePositions` 518–525; `CloseWithReason` 400–410 | Modification timestamps update only on success; repeated failures can generate a request every tick. Partial close success is logged as an exit without proving the position is flat. Throttle attempts and reconcile residual exposure. |
| P1 | `UpdateSynthetic10s` 538–565 | Any newer bucket publishes the last observed bucket and preserves previous direction, even after a long tick gap. Require continuity and suppress stale/initial partial buckets. Never fabricate executable quotes for empty buckets. |
| P1 | `FibSignal` 608–621 | Zone membership tests the previous M1 close; the current buy Ask/sell Bid may already be outside. Retain and recheck the executable entry zone at submission. |
| P1 | `FVGSignal` 675, 682 | Buy touch checks Bid and sell touch checks Ask. Example: gap `[100,101]`, Bid `100.9`, Ask `101.2` passes the buy test while entry is outside. Use Ask for buy entry and Bid for sell entry. |
| P1 | `FVGSignal` 658–684 | No explicit gap lifecycle or prior mitigation/invalidation checks. A reversal candle may precede the touch; old gaps can be reused after closing a trade. Define lifecycle and sequencing; a quote-side correction alone is insufficient. |
| P1 | `TryEnter` 791–795; `SnapPrice` 148–150 | Nearest-tick snapping can put a protective price on the wrong side of the desired broker boundary; equality is then rejected. Use side-aware tick rounding and verify the final risk and stop distances. |
| P2 | `Signal` 733–735 | Baseline mode still requires M5/RSI reads even when those filters are unused. Read only dependencies required by the selected mode. |
| P2 | `FibSignal` 605–607 | M15 EMA must be readable even when optional M15 confirmation is off. Gate this dependency by its input. |
| P2 | Advanced signal 751–754 | Absolute body strength is direction-neutral. A bearish candle can earn a buy strength point. Clarify intent before a strategy-changing fix. |
| P2 | `HasOBOverlap` 630–639 | Includes the FVG's oldest candle, and simple boundary equality can count as overlap. This is a rudimentary candle proxy, not measured institutional order flow. |
| P2 | `OnTick` 992–1003 | Except mode 4, decisions occur on the first tick of a new M1 candle. Intraminute FVG revisits are not evaluated. This matches the stated once-M1 model; do not describe it as continuous touch detection. |

Protective elements worth retaining: demo account gate, disabled order switch by
default, mandatory server-side initial stop, minimum-lot risk rejection,
`MIN(cash, equity percentage, daily room)` budget, maximum-lot cap and no recovery
grid. These are intended controls, not proof their execution is complete.

## Signal causality and strategy assessments

Inspected native EMA/RSI/ADX/SAR/ATR reads use closed bars (shift 1/2). Opening-range
bounds are finished before entry, with an expected M15 bar count. FVG uses three
closed M5 candles. No direct future-bar indexing was found in those paths. This
does not replace timestamped replay or establish indicator synchronization.

The synthetic engine already uses fixed timestamp buckets (`q.time/10*10`). A
missing tick delays publication; it does not literally extend the bucket's
timestamp interval. Mid-price still moves if only one quote side widens, so it
does not remove all spread-induced movement.

| Mode | What it actually tests | Assessment and next experiment |
| --- | --- | --- |
| 0 EMA baseline | EMA9/21 alignment, prior pullback and completed-M1 continuation | Best simple control; remove unused indicator dependencies and compare net expectancy under common sizing/exits. |
| 1 EMA+RSI+M5 | Baseline plus bounded RSI and closed-M5 EMA20/50 | Additional filters are correlated price transformations. Measure incremental expectancy and turnover, not just fewer losses in aggregate. |
| 2 Advanced | Mode 1 plus ADX/DI, body/range and prior-range breakout extras | Not full market structure. Separate extra filters in ablations; avoid changing their meaning while fixing execution. |
| 3 Opening range | Completed 07:00–09:00 server-time M15 range and subsequent M1 close crossing | Causal range construction; test DST/server time, full data coverage and one-entry-per-day behavior. Not evidenced as backtested in the supplied files. |
| 4 EMA/PSAR 10s | Native closed-M1/M5 alignment plus synthetic 10s candle direction | Not a synthetic-10s PSAR indicator. Fix continuity; measure latency, spread and re-entry costs against the slower baseline. |
| 5 Fib/EMA | Chronological rolling M5 extrema, 38.2–61.8% zone, M1 reversal/RSI | Chronology is correctly oriented, but extrema are not confirmed pivots. Fix executable-zone checks; pivot redesign and non-Fib-zone comparisons remain separate experiments. |
| 6 FVG/OB | Closed-M5 gap proxy, displacement, M5/H1 bias and M1 reversal | Fix executable side and stale-zone handling first. Full touch/reversal lifecycle and any order-block benefit require explicit independent tests. |

## Development history and reported results

| Version | Source evolution | Evidence status |
| --- | --- | --- |
| V01 | Described in handover as EMA momentum prototype | Source absent; cannot audit or reproduce. |
| V02 | EMA9/21 baseline; optional RSI/M5; 0.25% equity risk, fee estimate zero, fixed 1.8R TP; 8/day default | Handover reports +$143.02/32 trades and +$237.82/80 candidate entries over four days. Not independently verified here. |
| V03 | Three modes, bounded RSI, ADX/candle/range extras, session/cooldown, cost-aware stops, loss-streak gate | Handover reports mode 0 +$156.25, mode 1 −$325.76, mode 2 −$60.00. Archived source version is `0.30`; described compiled revision was `1.030`, so exact tested-source identity is unresolved. |
| V04 | Adds 0.01 lot maximum, daily peak protection, range breakout, trailing-only default, 200/day cap; removes V03 loss-streak gate | Handover reports modes 0/1/2 −$103.63/−$60.71/−$47.85; $100 test zero trades. These are reported historical figures, not this audit's tests. |
| V05 | Retains V04 signal families; adds fixed-cash/cash-lock/hybrid exits, 120s holding default | No verified completed backtest supplied. |
| V06 | Adds modes 4/5/6; cash15/1.5% risk, 3% daily loss, 0.01 cap, sessions on, cooldown45, holding cap off | Source inspected; no verified completed backtest supplied. |

Reported V02/V03 gains and V04 losses concern 12–15 October 2026, repeatedly reused
development data. They are not independent holdout evidence. Larger V02 sizes,
different cost estimates, exits and protections prevent direct P/L comparison
with 0.01-lot V04. A sizing fee estimate does not post a commission to tester P/L.
Minimum-lot rejection on a $100 account is protective behavior, not an entry bug.

## Prioritized roadmap and acceptance evidence

1. **Mechanics:** repair exposure allocation, preflight/reconciliation, persistent
   risk state, retry throttles, stop selection, synthetic continuity and executable
   signal prices. Preserve original source and produce a clean V06-to-V06.1 diff.
2. **Policy tests and compilation:** exercise the actual shared pure policy header
   using deterministic C++ fixtures; separately compile V06.1 and its includes in
   MetaEditor. Neither syntax inspection nor C++ results substitutes for MT5.
3. **Historical control:** obtain original reports/settings/data and reproduce a
   V04 run over 12–15 October before comparing revised behavior. Explain any
   mismatch; do not optimize it away. Treat that interval as development data.
4. **Real ticks and chronology:** verify genuine 6–12+ month coverage, exact FxPro
   contract/currency/costs and execution assumptions. Freeze training/validation/
   untouched-holdout dates and every parameter trial before inspecting results.
5. **Signal then exit ablations:** compare all seven modes using one common exit;
   then compare legacy/cash/cash-lock/hybrid and holding caps independently.
   Distinguish same-entry counterfactuals from full EA reruns with path dependence.
   Partial profit-taking at a 0.01 minimum may be impossible without raising
   exposure; never enlarge a trade merely to enable a partial exit.
6. **Robustness:** nearby parameters, sessions, volatility regimes and adverse
   costs/fills. Report net expectancy, average win/loss, trade frequency, win rate,
   profit factor, maximum equity drawdown, loss tails and uncertainty.
7. **Forward demo:** prospectively reconcile every signal, skip, order, fill and
   exit, including restart/disconnection drills. Only then assess whether evidence
   supports further research. Live deployment and AI remain deferred.

See `validation-plan.md` and `trade-export-format.md` for the evidence contract.
