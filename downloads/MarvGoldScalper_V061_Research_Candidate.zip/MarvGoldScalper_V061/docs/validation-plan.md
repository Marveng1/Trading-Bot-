# FxPro MT5 gold validation protocol

Status: source reviewed and local policy/evaluator fixtures executed; all MT5 execution checks pending runtime/data. See `v061-install-and-test.md`.
This document is not a passing test report. Preserve the demo-only gate.

## Evidence package

Collect V06 source and includes, source hash, MT5/MetaEditor build, compile log,
complete `.set` inputs, broker legal entity/server, demo account currency and
leverage. Export exact symbol name, contract size, tick size, profit/loss tick
values, min/max/step volume, execution/filling modes, stops/freeze levels,
margin model, session schedule, swaps and commission schedule. Do not include
passwords or API keys in exports.

For each run retain date bounds, tick source and gaps, server UTC/DST mapping,
tester mode, deposit/currency, model/version identifiers, report, journal and
deals/orders exports. Distinguish zero-trade runs from completed trading tests.

## 1. Mechanical acceptance tests

| Area | Cases | Acceptance evidence |
| --- | --- | --- |
| Compilation | Exact source and includes in MetaEditor | Zero errors; investigate every warning; retain original compiler log |
| Indicator causality | Startup, bar boundaries, M1/M5/H1 warmup, insufficient buffers, swing confirmation | Log input timestamps and shifts; no source event after decision time; no trade on invalid data |
| Synthetic bars | Boundary tick, no ticks, out-of-order/duplicate tick, reconnect | Explicit fixed timestamp buckets; never fabricate executable quotes; documented empty-bar rule |
| Volume | Raw size below minimum, between steps, nondecimal steps, maximum and margin cap | Round down; skip if minimum breaches budget; recompute cash loss and margin for final size |
| Stops | Long/short, spread widening, tick-size versus digit precision, stops/freeze restrictions | Valid server-side stop on confirmed entry; final risk includes costs and entry/stop prices; rejected protection escalates |
| Orders | Rejection, requote, partial fill, timeout with unknown outcome | Inspect trade-server return codes and actual deals; reconcile before retry; no duplicate exposure |
| Restart/reconnect | Restart with position, pending order, daily halt, stale quote | Reconstruct broker state; preserve day floor and lockout; no entry until synchronized |
| Daily accounting | Broker midnight, DST, restart, floating loss, fees, swaps, deposits/withdrawals | Documented account-equity policy; no reset by reattachment; withdrawals do not masquerade as trading losses |
| Concurrency | Two charts, same/different magic, pending orders and simultaneous ticks | Atomic allocation within one terminal; include pending exposure; multiple terminals need a shared coordinator or must be prohibited |
| Position ownership | Hedging versus netting accounts; other EAs | Explicit supported account model; netting must not merge untracked ownership silently |
| AI outage | Timeout, malformed response, stale response, quota failure | Block AI-required new entries; existing stop/exit management continues independently |

Initial planned cash risk is the minimum of cash cap, equity percentage cap and
remaining daily floor allowance. GBP 500 at 1.5% permits at most GBP 7.50; GBP
1,000 permits at most GBP 15, before other caps. Account currency must be verified.
Include reserved aggregate risk; do not promise a maximum realized loss through gaps.

## 2. Executable-cost backtests

Use FxPro's exact symbol and “Every tick based on real ticks.” Verify available
coverage and compare sample bid/ask observations to tester trades. Actual buy
entries use ask and long exits bid; sells use bid and short exits ask.

Confirm commissions are charged in deal results; a risk-sizing fee reserve is
not a performance expense. Include swaps for any rollover exposure. Avoid adding
spread twice when it is already represented by bid/ask execution.

Run a short mechanics smoke test, then the predeclared chronological study.
Stress spread, commission, latency, adverse slippage, missed fills, gaps and
stop-modification rejection. MT5 delay settings do not model all live execution
effects; label unsupported scenarios and use a validated custom-symbol or
execution-replay harness where needed. Do not call a simple P/L fee deduction a
full spread/slippage simulation: altered quotes can change triggers and stops.

## 3. Chronological validation

Before inspecting performance, freeze available date bounds and allocate the
first 60% to training, next 20% to validation and last 20% to untouched holdout.
These proportions are a starting design, not a universal standard. Extend data
if trade counts or regime coverage are inadequate; never silently reuse holdout.

Use only earlier data for indicator warmup. Purge overlapping trade/label
outcomes at boundaries and document treatment of carried positions. Fit scalers,
feature thresholds and model selections only on training data.

Record every strategy/mode/parameter trial, including failed experiments. Select
using validation, freeze source/settings/cost assumptions, then open the holdout
once. A material change requires fresh future evidence. Within training and
validation, walk-forward folds can assess stability without consuming holdout.

LLMs may know later historical events from training: historical news prompts
can introduce hindsight even when supplied documents are timestamp-correct.
Treat historical Gemini comparisons as exploratory; use prospective shadow
evaluation for stronger evidence.

## 4. Robustness

- Predeclare a small search budget; perturb selected periods/thresholds around
  the chosen configuration (for example ±10% and ±20%, rounded to valid inputs).
- Compare baseline costs with 1.5x and 2x spread/commission scenarios and
  broker-relevant execution delays. These are exploratory scenarios, not claimed
  FxPro distributions; calibrate later to demo observations.
- Report by session, direction, volatility bucket, news window and chronological
  subperiod; define buckets without future outcomes.
- Examine parameter neighborhoods rather than a single peak. Include months
  with no trades and losses; assess dependence using day/week block resampling.
- Report net expectancy with uncertainty, trade count, turnover, profit factor,
  maximum equity drawdown, worst day/trade and cost per trade. Show return and
  drawdown in account currency and percentages. No universal profit-factor or
  win-rate threshold establishes viability.
- Predeclare acceptable drawdown and loss-tail limits before choosing a winner.
  If uncertainty includes no edge, label evidence inconclusive rather than pass.

## 5. Prospective demo and reconciliation

First run deterministic baseline with AI in shadow mode. Record each potential
entry and skip, not just executed trades. After a frozen evaluation rule is met,
compare AI-veto and baseline decisions without increasing size.

Each event should include UTC and broker timestamps, source/settings hash,
symbol, signal ID, closed-bar timestamps, bid/ask, requested entry/stop/target,
volume, planned risk, order/deal/position IDs, server return code, actual fill,
commission/swap/fees, exit reason and expected versus observed action.

AI records additionally need model identifier, prompt/schema version, input
availability timestamps, response, receipt timestamp, latency and expiry. Redact
credentials and unnecessary account identifiers.

Reconcile every signal to an order, a documented skip or a rejection. Distinguish
partial fills, cancellation, server-side stop fills and manual intervention.
Investigate unexplained mismatches before enabling entries again.

Use a dedicated demo account so external activity does not obscure accounting.
Several weeks is an initial observation window, not a pass criterion; sufficient
opportunities and varied conditions are required. Review daily; preserve restart
and outage drills. Live deployment is a separate decision after evidence review.
