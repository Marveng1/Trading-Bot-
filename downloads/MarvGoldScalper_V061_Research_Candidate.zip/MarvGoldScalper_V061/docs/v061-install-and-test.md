# V06.1 research candidate: installation and test status

This is a source repair candidate, not a compiled or profitable EA. Use only a
dedicated FxPro **hedging demo** account. It refuses live, contest and netting
accounts. All seven signal modes remain research hypotheses. No AI integration
or additional indicators were added in this repair pass.

## Files and installation

1. Keep the existing V02–V06 files. In FxPro MT5 choose **File > Open Data Folder**.
2. Create `MQL5/Experts/MarvGoldScalper_V061/` and copy BOTH
   `source/MarvGoldScalper_V061.mq5` and `source/MGSCore.mqh` into it.
3. Open the new `.mq5` in MetaEditor and press **F7**. Compilation is **UNVERIFIED**
   in this cloud machine. Retain the entire compiler output; investigate every
   error/warning before permitting demo orders. Do not rename an old `.ex5`.
4. Refresh Navigator. Open Strategy Tester and select the V061 expert, exact
   FxPro `GOLD` symbol, M1, **Every tick based on real ticks**, optimization OFF.
   Check hedging account mode. If your tester cannot supply it, report that
   compatibility constraint rather than removing the account gate.
5. Check broker legal entity, account currency, leverage, gold contract and
   actual commission schedule. Handover figures (100 oz/lot, min/step 0.01,
   tick size 0.01, demo 1:100) are historical observations, not fresh verification.
6. Start with a short mechanics smoke test. Source defaults have
   `InpEnableDemoOrders=false`: this is observation only, not a trading test.
   The supplied `DEMO_TESTER_*.set` files deliberately enable DEMO/tester orders.
   They do not permit live accounts. Confirm the `MGS V061 RESEARCH` journal line.
7. Set tester deposit/currency explicitly, first GBP 1,000 then GBP 500 when
   supported. A USD test remains USD; do not relabel it GBP. Use realistic margin
   and verify commission in actual deals. Never weaken risk guards to get trades.
8. Save report, journal, `.set`, raw deals, event/equity logs, source checksum,
   tester build, data bounds and execution assumptions for each run.

The 7-per-lot round-trip fee and 10-tick stop-slippage reserve remain estimates
in ACCOUNT currency. They do not debit the tester's balance. Supply broker deal
costs separately and check their currency. Stops do not guarantee realized risk.

## Important changes in operation

- Cash-risk input cannot exceed 15 account-currency units; equity percentage
  cannot exceed 1.5%. Lot-cap input cannot exceed 0.01 in this repair candidate. Smaller-than-minimum
  affordable volume is rejected rather than rounded up.
- One V061 instance per account per terminal. Exclusive-account mode is required,
  and positions AND pending orders block entry. The lock does not coordinate
  V06/third-party EAs or another terminal/VPS. Do not run them on this account.
- Daily state is account/server scoped. Matching V06 day state is migrated when
  available. Without saved day state, the first non-tester attachment blocks new
  entries until the next broker day; it does not invent midnight equity.
- A broker-day baseline is still a first-observed equity snapshot. Offline gaps,
  external trades and cash movements cannot be reconstructed reliably. Stop
  trading and reconcile the account after these events; use a dedicated demo.
- Entry quarantine is persisted BEFORE order submission. A timeout, uncertain
  outcome or restart under unresolved submission blocks further orders. Unknown
  submission state causes owned exposure to be closed when order handling is
  enabled. Confirmed fills require matching order/position identity, observed
  volume and stop-risk evidence before quarantine clears automatically.
- This deliberately favors stopping for review over submitting a duplicate.
  A fill and immediate stop-out before a position snapshot may stay quarantined.
  After a restart, order/budget details are not automatically restored; the
  marker stays set for operator reconciliation. This is a conservative interim
  policy, not complete automated recovery.
- Do not blindly delete terminal globals or change magic to resume trading.
  Reconcile raw broker orders/deals/positions, resolve any working order and
  exposure, and retain logs before reviewing a reset of the specific
  `MGS061_<login>_<server-hash>_inflight` marker in MT5's global variables.
  Keep daily-loss/peak state intact. If uncertain, leave entries blocked.
- Time exits run before profit valuation. Failed close attempts retain close
  intent and retry no more often than every three seconds. Failed stop updates
  are throttled too. No tick or connection means local actions can be delayed.
- Cash protection no longer requires ATR availability. Each proposed cash/BE/ATR
  stop is checked independently, so an illegal tighter candidate cannot suppress
  a legal weaker improvement. A weaker stop is not a claimed cash-profit lock.
- Synthetic bars retain fixed ten-second boundaries; gaps reset direction.
  Initial/reconnect partial buckets are discarded. This is observed-tick
  aggregation, not proof that MT5 delivered every broker tick.
- Fib and FVG use executable buy Ask/sell Bid zone checks, repeated in entry.
  Fib still uses rolling extrema rather than confirmed pivots. FVG still lacks
  a full first-touch/mitigation/invalidation/reversal-after-touch lifecycle;
  its mode is experimental, not a repaired institutional-order-flow model.

## Logs and evaluation

`InpCSVLog=true` writes `MGS061_events_<login>_<magic>_<symbol>_<run-id>.csv` in the MT5
Files sandbox (tester agents use their own sandbox). Logging failure blocks new
entries when logging is enabled, while existing position management remains
active. Events cover initialized state, eligibility skips, candidates, preflight,
entry results, transactions, modifications and close attempts/results. Equity
is sampled at most once per broker second on incoming ticks. Each initialization receives a distinct run ID in its filename and rows; an
existing filename collision blocks new entries rather than mixing runs. Keep
the matching journal and exact settings/source manifest alongside the log.

CSV times are BROKER SERVER time; record the UTC/DST mapping before normalization.
The log is an audit aid, not a complete raw tick archive or closed-position
ledger. Some early mathematical/broker-data rejection paths remain journal-only
or lack a detailed skip reason. No MFE/MAE or latency completeness is claimed.
Observed equity samples can miss intrasecond drawdowns. Transaction callbacks
are asynchronous; a callback row is not a substitute for raw deal history.

See `trade-export-format.md` for the raw-history exporter, closed-position
normalization and Python analysis. It never substitutes balance for equity or
unknown commission for zero.

## Controlled presets and research sequence

`presets/experiment_manifest.csv` lists unrun experiments. Presets contain every
EA input and a pinned source hash; tester currency, deposit, dates, delay and tick
model must be set separately. They are not optimized recommendations.

1. Reproduce an archived V04 control with matching source/settings/history.
   The handover's October 12–15, 2026 interval is development data, not holdout.
2. Compare modes 0–6 using legacy R/ATR exits, no fixed TP, holding cap off and
   identical execution/risk settings. Mode 6 retains the disclosed lifecycle
   limitation. A zero-trade run is not passing performance evidence.
3. Hold mode 0 fixed; compare cash target, cash lock and hybrid against legacy.
4. Hold mode 0/legacy fixed; compare 30/60/120/180-second caps against no cap.
   Do not select a winner before recording the total trial count.
5. Verify 6–12+ months real-tick coverage; freeze chronological development,
   validation and untouched holdout bounds before assessing results. Do not
   reuse contaminated October data as independent validation.
6. Run execution/cost stresses and parameter-neighborhood checks, then a
   prospective demo with daily reconciliation. Partial exits remain deferred:
   at broker minimum 0.01, a valid smaller partial close may be impossible.

## What has actually been tested here

- Shared pure-policy MQL header compiled/executed with a C++ host harness:
  cash/percentage/floor budgets, volume floor, price rounding, legal monotonic
  stop selection, executable-zone checks, partial-fill volume evidence and
  ten-second boundary/gap/invalid-quote behavior.
- Archived V06 ten-second function executed under a broker-free host stub to
  reproduce its stale-gap defect. This compiles that function, NOT the EA.
- Python evaluator fixtures exercise signed costs, duplicate/invalid inputs,
  timezone grouping, absent equity, drawdown and CLI behavior.

Run `python -m unittest discover -s tests -p 'test_*.py' -v` from the repository.
Python 3 and g++ are needed for all tests; missing g++ produces explicit skips.
No MetaEditor compilation, MT5 backtest, broker rejection/reconnect drill,
out-of-sample study or forward demo has executed here. Those remain required.
