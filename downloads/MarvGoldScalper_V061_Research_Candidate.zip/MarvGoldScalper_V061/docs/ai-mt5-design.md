# Proposed MT5 and Gemini architecture

Status: design only. No API calls, order placement, compiled EA or deployment.
Target confirmed: FxPro MT5, GOLD/XAUUSD. V02–V06 source has now been supplied. The latest request prioritizes a V06.1 mechanical repair; AI remains deferred until deterministic baseline validation.

## Responsibilities

`Broker ticks -> deterministic MQL5 strategy -> risk/execution engine -> broker`

`Timestamped market snapshot -> separate Gemini service -> expiring veto -> strategy`

MQL5 owns entry eligibility, cash-risk sizing, margin, server-side stops,
position/pending-order reconciliation, loss floors and all exits. Gemini cannot
increase risk, move a stop farther away, bypass a halt or issue executable code.
Begin with AI disabled, then shadow logging; only later test a veto on otherwise
valid deterministic signals. A model's self-reported confidence is not a
calibrated probability of profit.

## Why keep Gemini off OnTick

MT5 WebRequest is synchronous and is not available in the Strategy Tester;
verify these platform constraints against the official documentation when web
access is enabled: https://www.mql5.com/en/docs/network/webrequest .
Blocking an EA event handler on a model response can delay local trade
management. A separate service performs network work and publishes cached,
timestamped results through a bounded, nonblocking adapter to be selected and
tested on the deployment host. Do not implement an unbounded network wait in
OnTick or OnTimer and assume timers solve the blocking problem.

Ten-second entry logic should not depend on a fresh large-language-model call
every ten seconds. Measure latency first. A slower context veto may be useful;
it still needs an incremental benefit after latency, API costs and missed trades.

## Response contract

Proposed fields: schema version, request ID, symbol, input-as-of timestamp,
decision (`ALLOW` or `VETO`), reason code, and requested validity duration.
The trusted service stamps receipt time and caps validity; do not trust the
model to declare a recent timestamp or extend its own expiry.

Validate field types, enum values, size limits and request/symbol matching.
Reject malformed, missing, expired or out-of-order responses. If AI is required
and unavailable, block new entries. Existing positions retain deterministic
management. An explicit baseline mode remains available for controlled tests.

Official Gemini structured-output documentation to verify before implementation:
https://ai.google.dev/gemini-api/docs/structured-output . Structured JSON does
not establish factual accuracy or signal quality. Pin the model identifier and
record prompt/schema versions; model changes require renewed evaluation.

## Credentials and service boundary

Keep the Gemini key on the service host, outside source code, EA inputs, `.set`
files and logs. Do not paste it into chat. In a future cloud integration, bind
`GEMINI_API_KEY` securely for `generativelanguage.googleapis.com` using environment
settings; local Windows deployment needs its own secure service configuration.
No key is present in this cloud instance and none has been requested or used.

Authenticate the EA-to-service channel; bind local services to loopback where
appropriate. Use TLS and scoped authentication for remote access. Limit request
rate, payload size, retention, API spend and retries. Do not forward credentials
or unnecessary account details to the model. Treat retrieved news text as data,
never instructions capable of changing execution rules.

## Evaluation and deployment

1. Verify V06 without AI on broker data, including mechanical failure cases.
2. Use recorded deterministic fixtures to test the response adapter. Do not claim
   live HTTP Gemini integration has been backtested inside MT5.
3. Start prospective shadow logging, then compare baseline versus the frozen
   AI veto policy. Include all rejected signals and API costs.
4. Deploy compiled demo-only EA and service on a Windows machine/VPS running
   FxPro MT5. Verify permissions, symbol/account configuration and server stops.
5. Test terminal, EA and service restart independently. Inspect logs and reconcile
   existing positions before permitting new entries. Add health alerts and an
   operator kill switch. Deployment here is not yet possible without that host.

AI is an experiment whose benefit must be measured; no AI component is required
to keep a position protected or to establish the baseline strategy's edge.
