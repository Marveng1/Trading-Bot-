#!/usr/bin/env python3
"""Generate complete, unoptimized DEMO tester inputs and a pinned run manifest."""
import csv
import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    source_path = ROOT / "source/MarvGoldScalper_V061.mq5"
    source = source_path.read_text()
    enums = dict(re.findall(r"^\s*(MGS_\w+)\s*=\s*(\d+)", source, re.M))
    defaults = {}
    for name, value in re.findall(r"^input\s+\w+\s+(\w+)\s*=\s*([^;]+);", source, re.M):
        value = value.strip()
        defaults[name] = enums.get(value, value.strip('"'))
    if len(defaults) < 60 or len(defaults) != len(re.findall(r"^input\s", source, re.M)):
        raise RuntimeError("Input discovery incomplete; inspect source instead of generating partial settings")
    common = dict(defaults, InpEnableDemoOrders="true", InpMode="0", InpExitMode="0",
                  InpUseFixedTP="false", InpMaxHoldingSeconds="0", InpCSVLog="true")
    experiments = [(f"mode{mode}_legacy", {"InpMode": str(mode)}) for mode in range(7)]
    experiments += [(f"mode0_exit{exit_mode}", {"InpExitMode": str(exit_mode)}) for exit_mode in range(1, 4)]
    experiments += [(f"mode0_hold{seconds}", {"InpMaxHoldingSeconds": str(seconds)})
                    for seconds in (30, 60, 120, 180)]
    destination = ROOT / "presets"
    destination.mkdir(exist_ok=True)
    source_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
    core_hash = hashlib.sha256((ROOT / "source/MGSCore.mqh").read_bytes()).hexdigest()
    records = []
    for name, changes in experiments:
        values = dict(common, **changes)
        filename = f"DEMO_TESTER_{name}.set"
        text = ("; V061 uncompiled research candidate; DEMO TESTER orders enabled\r\n"
                "; Set GBP deposit/currency/dates/real-ticks/delay separately in MT5\r\n"
                f"; Source SHA256 {source_hash}\r\n"
                f"; Core SHA256 {core_hash}\r\n")
        text += "".join(f"{key}={value}\r\n" for key, value in values.items())
        path = destination / filename
        path.write_bytes(text.encode("utf-16"))
        records.append(dict(experiment=name, preset=filename, status="not_tested",
                            mode=values["InpMode"], exit_mode=values["InpExitMode"],
                            max_hold_seconds=values["InpMaxHoldingSeconds"],
                            source_sha256=source_hash, core_sha256=core_hash,
                            preset_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                            account_currency="GBP_REQUESTED_VERIFY_TESTER", deposits="500;1000",
                            date_bounds="UNASSIGNED_DATA_REQUIRED", phase="unassigned",
                            costs="BROKER_COSTS_REQUIRED;INPUT_RESERVES_ARE_ESTIMATES",
                            notes="FVG lifecycle incomplete" if values["InpMode"] == "6" else "unoptimized control"))
    with (destination / "experiment_manifest.csv").open("w", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    print(f"Generated {len(records)} unrun presets with {len(defaults)} inputs each")


if __name__ == "__main__":
    main()
