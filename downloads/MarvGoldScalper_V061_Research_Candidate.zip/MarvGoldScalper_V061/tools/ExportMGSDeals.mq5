// Read-only history exporter. UNCOMPILED in this environment.
// Never submits, modifies or closes orders/positions.
// Magic filtering can omit manual closes or other deals linked to a position.
// Disable the filter and reconcile position IDs when building complete episodes.
// HistorySelect success and zero errors do NOT prove broker history completeness.
#property strict
#property script_show_inputs
#property version "1.061"

input string   InpSymbol          = "GOLD";             // Exact broker symbol
input bool     InpFilterMagic     = true;
input long     InpMagicNumber     = 20261023;
input datetime InpFrom            = 0;                  // 0: earliest available
input datetime InpTo              = 0;                  // 0: TimeCurrent()
input string   InpOutputFile      = "MGS_raw_deals.csv"; // MQL5/Files sandbox
input bool     InpOverwrite       = false;              // Preserve existing exports

string CSVText(string value)
{
   // FileWrite uses comma separators; sanitize free-form cells rather than
   // relying on quoting behavior. Ticket IDs and numeric fields are unchanged.
   StringReplace(value, ",", ";");
   StringReplace(value, "\"", "'");
   StringReplace(value, "\r", " ");
   StringReplace(value, "\n", " ");
   StringReplace(value, "\t", " ");
   return value;
}

string TicketText(ulong value)
{
   return StringFormat("%I64u", value);
}

string MoneyText(double value)
{
   // No sign reversal, currency conversion or cost estimation.
   return DoubleToString(value, 16);
}

void OnStart()
{
   if(StringLen(InpSymbol) == 0 || StringLen(InpOutputFile) == 0)
   {
      Print("EXPORT FAILED: symbol and output filename must be nonempty.");
      return;
   }
   datetime until = (InpTo == 0 ? TimeCurrent() : InpTo);
   if(until <= 0 || InpFrom < 0 || until < InpFrom)
   {
      Print("EXPORT FAILED: invalid history interval; connect to the broker and check dates.");
      return;
   }
   if(!InpOverwrite && FileIsExist(InpOutputFile))
   {
      Print("EXPORT FAILED: file exists; choose a new filename or explicitly enable overwrite.");
      return;
   }
   ResetLastError();
   if(!HistorySelect(InpFrom, until))
   {
      PrintFormat("EXPORT FAILED: HistorySelect error %d.", GetLastError());
      return;
   }
   int total = HistoryDealsTotal();
   ResetLastError();
   int file = FileOpen(InpOutputFile, FILE_WRITE | FILE_CSV | FILE_ANSI, ',', CP_UTF8);
   if(file == INVALID_HANDLE)
   {
      PrintFormat("EXPORT FAILED: FileOpen error %d.", GetLastError());
      return;
   }
   if(FileWrite(file, "deal_id", "order_id", "position_id", "time_msc",
                "broker_time", "symbol", "magic", "type", "entry", "reason",
                "volume", "price", "profit", "commission", "swap", "fee",
                "account_currency") == 0)
   {
      PrintFormat("EXPORT FAILED: writing header, error %d.", GetLastError());
      FileClose(file);
      return;
   }

   string currency = CSVText(AccountInfoString(ACCOUNT_CURRENCY));
   int exported = 0;
   bool complete = true;
   for(int i = 0; i < total; i++)
   {
      ResetLastError();
      ulong ticket = HistoryDealGetTicket(i);
      if(ticket == 0)
      {
         PrintFormat("EXPORT FAILED: reading history index %d, error %d.", i, GetLastError());
         complete = false;
         break;
      }
      string symbol = HistoryDealGetString(ticket, DEAL_SYMBOL);
      long magic = HistoryDealGetInteger(ticket, DEAL_MAGIC);
      if(GetLastError() != 0)
      {
         PrintFormat("EXPORT FAILED: reading deal %s filter fields, error %d.",
                     TicketText(ticket), GetLastError());
         complete = false;
         break;
      }
      if(symbol != InpSymbol || (InpFilterMagic && magic != InpMagicNumber))
         continue;

      ResetLastError();
      ulong order_id = (ulong)HistoryDealGetInteger(ticket, DEAL_ORDER);
      ulong position_id = (ulong)HistoryDealGetInteger(ticket, DEAL_POSITION_ID);
      long time_msc = HistoryDealGetInteger(ticket, DEAL_TIME_MSC);
      datetime broker_time = (datetime)HistoryDealGetInteger(ticket, DEAL_TIME);
      string type = EnumToString((ENUM_DEAL_TYPE)HistoryDealGetInteger(ticket, DEAL_TYPE));
      string entry = EnumToString((ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket, DEAL_ENTRY));
      string reason = EnumToString((ENUM_DEAL_REASON)HistoryDealGetInteger(ticket, DEAL_REASON));
      double volume = HistoryDealGetDouble(ticket, DEAL_VOLUME);
      double price = HistoryDealGetDouble(ticket, DEAL_PRICE);
      double profit = HistoryDealGetDouble(ticket, DEAL_PROFIT);
      double commission = HistoryDealGetDouble(ticket, DEAL_COMMISSION);
      double swap = HistoryDealGetDouble(ticket, DEAL_SWAP);
      double fee = HistoryDealGetDouble(ticket, DEAL_FEE);
      if(GetLastError() != 0)
      {
         PrintFormat("EXPORT FAILED: reading deal %s properties, error %d.",
                     TicketText(ticket), GetLastError());
         complete = false;
         break;
      }
      ResetLastError();
      uint written = FileWrite(file, TicketText(ticket), TicketText(order_id),
                     TicketText(position_id), StringFormat("%I64d", time_msc),
                     CSVText(TimeToString(broker_time, TIME_DATE | TIME_SECONDS)),
                     CSVText(symbol), StringFormat("%I64d", magic), CSVText(type),
                     CSVText(entry), CSVText(reason), MoneyText(volume), MoneyText(price),
                     MoneyText(profit), MoneyText(commission), MoneyText(swap), MoneyText(fee),
                     currency);
      if(written == 0)
      {
         PrintFormat("EXPORT FAILED: writing deal %s, error %d.", TicketText(ticket), GetLastError());
         complete = false;
         break;
      }
      exported++;
   }
   ResetLastError();
   FileFlush(file);
   int flush_error = GetLastError();
   FileClose(file);
   if(flush_error != 0)
   {
      PrintFormat("EXPORT FAILED: flush error %d; file may be incomplete.", flush_error);
      complete = false;
   }
   if(complete)
      PrintFormat("EXPORT FINISHED: %d matching deals from %d selected history deals; file %s. "
                  "History coverage and complete positions remain UNVERIFIED.",
                  exported, total, InpOutputFile);
   else
      PrintFormat("EXPORT INCOMPLETE: %d matching rows written; do not treat %s as complete history.",
                  exported, InpOutputFile);
}
