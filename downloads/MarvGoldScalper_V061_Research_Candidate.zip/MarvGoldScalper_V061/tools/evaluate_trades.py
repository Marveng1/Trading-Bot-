#!/usr/bin/env python3
"""Evaluate normalized, closed MT5 positions; no trading or cost estimation."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

TRADE_FIELDS = {
    "position_id", "entry_time", "exit_time", "side", "volume",
    "gross_profit", "commission", "swap", "fee",
}
PHASES = ("in-sample", "validation", "out-of-sample", "forward-demo", "unspecified")
SESSIONS = {
    "00:00-07:00 UTC": (0, 7),
    "07:00-12:00 UTC": (7, 12),
    "12:00-17:00 UTC": (12, 17),
    "17:00-24:00 UTC": (17, 24),
}


def number(value: str | None, field: str, positive: bool = False) -> float:
    if value is None or not value.strip():
        raise ValueError(f"{field}: a known numeric value is required; unknown is not zero")
    try:
        result = float(value)
    except ValueError as exc:
        raise ValueError(f"{field}: invalid number") from exc
    if not math.isfinite(result) or (positive and result <= 0):
        raise ValueError(f"{field}: expected a finite {'positive ' if positive else ''}number")
    return result


def timestamp(value: str | None, field: str) -> datetime:
    try:
        parsed = datetime.fromisoformat((value or "").strip().replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field}: expected ISO 8601 timestamp with UTC offset") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{field}: timezone offset is required")
    return parsed.astimezone(timezone.utc)


def rows(path: Path, required: set[str]) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as source:
        reader = csv.DictReader(source)
        names = reader.fieldnames or []
        if len(names) != len(set(names)):
            raise ValueError(f"{path}: duplicate CSV column names")
        missing = required - set(names)
        if missing:
            raise ValueError(f"{path}: missing columns: {', '.join(sorted(missing))}")
        result = list(reader)
        if any(None in row for row in result):
            raise ValueError(f"{path}: row contains more values than the header")
        return result


def load_trades(path: Path) -> list[dict]:
    trades, seen = [], set()
    for line, row in enumerate(rows(path, TRADE_FIELDS), start=2):
        prefix = f"{path}:{line}"
        position_id = (row["position_id"] or "").strip()
        if not position_id or position_id in seen:
            raise ValueError(f"{prefix}: empty or duplicate position_id")
        seen.add(position_id)
        entry = timestamp(row["entry_time"], f"{prefix} entry_time")
        exit_time = timestamp(row["exit_time"], f"{prefix} exit_time")
        if exit_time < entry:
            raise ValueError(f"{prefix}: exit_time precedes entry_time")
        side = (row["side"] or "").strip().upper()
        if side not in ("BUY", "SELL"):
            raise ValueError(f"{prefix}: side must be BUY or SELL")
        volume = number(row["volume"], f"{prefix} volume", positive=True)
        money = {key: number(row[key], f"{prefix} {key}")
                 for key in ("gross_profit", "commission", "swap", "fee")}
        net = math.fsum(money.values())
        if not math.isfinite(net):
            raise ValueError(f"{prefix}: net profit is not finite")
        risk_text = row.get("initial_risk")
        risk = number(risk_text, f"{prefix} initial_risk", positive=True) if risk_text and risk_text.strip() else None
        trades.append(dict(position_id=position_id, entry_time=entry,
                           exit_time=exit_time, side=side, volume=volume,
                           net_profit=net, initial_risk=risk, **money))
    return sorted(trades, key=lambda t: (t["exit_time"], t["position_id"]))


def summary(trades: list[dict]) -> dict:
    outcomes = [t["net_profit"] for t in trades]
    wins = [value for value in outcomes if value > 0]
    losses = [value for value in outcomes if value < 0]
    gross_wins, gross_losses = math.fsum(wins), -math.fsum(losses)
    total = math.fsum(outcomes)
    return {
        "trades": len(trades), "wins": len(wins), "losses": len(losses),
        "breakeven": len(trades) - len(wins) - len(losses),
        "win_rate": len(wins) / len(trades) if trades else None,
        "average_net_win": gross_wins / len(wins) if wins else None,
        "average_net_loss": -gross_losses / len(losses) if losses else None,
        "net_profit": total,
        "net_expectancy_per_trade": total / len(trades) if trades else None,
        "profit_factor": gross_wins / gross_losses if gross_losses else None,
        "net_winning_profit": gross_wins, "net_losing_profit_absolute": gross_losses,
    }


def equity_drawdown(path: Path | None, trades: list[dict]) -> dict | None:
    if path is None:
        return None
    points = []
    for line, row in enumerate(rows(path, {"timestamp", "equity"}), start=2):
        when = timestamp(row["timestamp"], f"{path}:{line} timestamp")
        value = number(row["equity"], f"{path}:{line} equity")
        if points and when <= points[-1][0]:
            raise ValueError(f"{path}:{line}: equity timestamps must strictly increase")
        points.append((when, value))
    if len(points) < 2 or points[0][1] <= 0:
        raise ValueError(f"{path}: equity needs at least two samples and positive initial equity")
    if trades and (points[0][0] > min(t["entry_time"] for t in trades)
                   or points[-1][0] < max(t["exit_time"] for t in trades)):
        raise ValueError(f"{path}: equity observations do not span all closed positions")
    peak, max_cash, max_fraction = points[0][1], 0.0, 0.0
    for _, value in points:
        peak = max(peak, value)
        max_cash = max(max_cash, peak - value)
        max_fraction = max(max_fraction, (peak - value) / peak)
    return {
        "basis": "observed equity samples; unobserved intraperiod troughs are unknown",
        "samples": len(points), "start": points[0][0].isoformat(),
        "end": points[-1][0].isoformat(), "maximum_cash": max_cash,
        "maximum_fraction": max_fraction,
        "external_cash_flows_adjusted": False,
    }


def evaluate(trade_path: Path, *, currency: str, phase: str,
             equity_path: Path | None = None) -> dict:
    if not currency.strip() or phase not in PHASES:
        raise ValueError("an account currency and valid evaluation phase are required")
    trades = load_trades(trade_path)
    by_day, by_session = defaultdict(list), {name: [] for name in SESSIONS}
    for trade in trades:
        entered = trade["entry_time"]
        by_day[entered.date().isoformat()].append(trade)
        session = next(name for name, (lo, hi) in SESSIONS.items() if lo <= entered.hour < hi)
        by_session[session].append(trade)
    with_risk = [t for t in trades if t["initial_risk"] is not None]
    return {
        "schema_version": 1, "phase": phase, "account_currency": currency.upper(),
        "status": "completed_closed_position_analysis" if trades else "no_trades",
        "trade_input": str(trade_path), "equity_input": str(equity_path) if equity_path else None,
        "summary": summary(trades),
        "costs": {key: math.fsum(t[key] for t in trades)
                  for key in ("gross_profit", "commission", "swap", "fee")},
        "initial_risk_coverage": len(with_risk),
        "average_net_R": math.fsum(t["net_profit"] / t["initial_risk"] for t in with_risk) / len(trades)
                         if trades and len(with_risk) == len(trades) else None,
        "maximum_equity_drawdown": equity_drawdown(equity_path, trades),
        "by_entry_date_UTC": {day: summary(group) for day, group in sorted(by_day.items())},
        "by_entry_session_UTC": {name: summary(group) for name, group in by_session.items()},
        "limitations": [
            "Statistics describe supplied closed positions; they do not validate missing trades or executions.",
            "Entry-date/session tables omit dates without entries; no per-calendar-day trade rate is inferred.",
            "Sessions are fixed UTC research buckets, not DST-adjusted exchange or broker sessions.",
            "No costs were estimated; signed commission, swap and fee must be supplied explicitly.",
            "Profit factor is null when no losing positions exist; net loss is negative and win rate is a fraction.",
            "Equity drawdown is unavailable without independent equity observations; cash flows can distort it.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trades", type=Path)
    parser.add_argument("--currency", required=True, help="actual account currency, e.g. GBP or USD")
    parser.add_argument("--phase", required=True, choices=PHASES)
    parser.add_argument("--equity", type=Path, help="optional timestamp,equity CSV")
    parser.add_argument("--output", type=Path, help="otherwise JSON is printed to stdout")
    args = parser.parse_args()
    try:
        report = evaluate(args.trades, currency=args.currency, phase=args.phase, equity_path=args.equity)
        encoded = json.dumps(report, indent=2, allow_nan=False) + "\n"
        if args.output:
            args.output.write_text(encoded, encoding="utf-8")
        else:
            sys.stdout.write(encoded)
        return 0
    except (OSError, ValueError, OverflowError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
