# MarvGoldScalper research

FxPro MT5 `GOLD` demo EA research. V06.1 is a source repair candidate, not an
MT5-compiled, backtested or profitable release. Orders default off; live accounts
are blocked. No Gemini integration or live deployment is included in this pass.

- [Source audit and development history](docs/v061-audit.md)
- [V06.1 changes, installation and test instructions](docs/v061-install-and-test.md)
- [Validation protocol](docs/validation-plan.md)
- [Trade exports and evaluator](docs/trade-export-format.md)
- [Unrun experiment manifest](presets/experiment_manifest.csv)
- [Proposed AI architecture, deferred](docs/ai-mt5-design.md)

Original uploaded V02–V06 sources are preserved in `research/originals/`.
V01, raw historical reports, journals and tick data were not supplied.
Handover-reported results are not independently verified performance.

Run local policy/evaluator tests with Python 3 and g++:

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
```

These execute pure MQL-compatible policy functions through a C++ harness and
Python analysis fixtures. They do not compile the EA or test MT5 broker events.
